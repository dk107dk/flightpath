
class Response:
    pass


