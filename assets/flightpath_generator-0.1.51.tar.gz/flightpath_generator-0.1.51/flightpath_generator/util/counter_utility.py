import os
import json
import sqlite3
from pathlib import Path


from flightpath_generator.util.config import Config

class CounterUtility:
    """cheap and cheerful counter for reasonably stateful, reasonably threadsafe for
    simple uses. keeps its sqllite db in a file called "flightpath-increment.db" in the
    config dir of the current project identified in .flightpath, if that info is
    available; otherwise in "flightpath-increment.db".
    """

    @classmethod
    def dbname(cls, counterdb=None) -> str:
        """
        returns the name of the file. if passed in on counterdb, expecting a .db extension
        """
        if counterdb is None:
            fp = Path.home() / ".flightpath"
            if os.path.exists(fp):
                with open( str(fp), "r") as file:
                    js = json.load(file)
                    if "projects_home" in js and "current_project" in js:
                        projects = js["projects_home"]
                        proj = js["current_project"]
                        counterdb = Path.home() / projects / proj / "config" / "increment"
            if counterdb is None:
                counterdb = Path.home() / "flightpath-increment"
            counterdb = str(counterdb)
            f"{counterdb}.db"
        return counterdb

    @classmethod
    def increment(cls, *, counterdb=None) -> int:
        counterdb = cls.dbname(counterdb)
        return cls.next(dbid=counterdb, identifier="increment")

    @classmethod
    def next(cls, *, dbid="increment", identifier: str) -> int:
        cls.assure_table(dbid=dbid, identifier=identifier)
        sql = sqlite3.connect(dbid)
        sql.isolation_level = None
        c = sql.cursor()
        c.execute("begin exclusive transaction")
        try:
            i = 0
            c.execute(f" SELECT count FROM {identifier} where ROWID = 1")
            row = c.fetchone()
            if row is None:
                c.execute(f" INSERT INTO {identifier}(count) VALUES(0)")
            else:
                i = row[0]
            i += 1
            c.execute(f" UPDATE {identifier} SET count={i} WHERE rowid = 1")
            c.execute("commit")
            return i
        except sql.Error as e:
            c.execute("rollback")
            c.close()
            sql.close()
            raise e
        finally:
            c.close()
            sql.close()

    @classmethod
    def assure_table(cls, *, dbid, identifier: str) -> None:
        sql = sqlite3.connect(dbid)
        sql.isolation_level = None
        c = sql.cursor()
        s = f"CREATE TABLE IF NOT EXISTS {identifier}( count INTEGER );"
        c.execute(s)
        c.close()
        sql.close()
