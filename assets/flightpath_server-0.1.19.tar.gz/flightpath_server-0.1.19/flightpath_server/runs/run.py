import json
from datetime import datetime
from uuid import UUID
from typing import Optional, List
from pydantic import BaseModel, ConfigDict
from csvpath import CsvPaths


class Run(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    run_uuid: str
    start_time: Optional[datetime]
    end_time: Optional[datetime]
    csvpaths: Optional[CsvPaths]
    run_method: str
    pathsname: str
    filename: str
    template: Optional[str]
    api_key: str
    result_reference: Optional[str]
    project_name: str
    config_path: str
    run_summary_path: Optional[str] = None

    def __str__(self) -> str:
        return f"""
    run_uuid: {self.run_uuid}
    start_time: {self.start_time}
    end_time: {self.end_time}
    csvpaths: {self.csvpaths}
    run_method: {self.run_method}
    pathsname: {self.pathsname}
    filename: {self.filename}
    template: {self.template}
    api_key: {self.api_key}
    result_reference: {self.result_reference}
    project_name: {self.project_name}
    config_path: {self.config_path}
    run_summary_path: {self.run_summary_path}"""
