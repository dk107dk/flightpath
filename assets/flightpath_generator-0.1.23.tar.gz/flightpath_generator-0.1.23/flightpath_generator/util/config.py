import os
from os import environ
import datetime
from configparser import RawConfigParser

from csvpath import CsvPath
from csvpath.util.config import Config as CsvPathConfig
from .exceptions import ConfigurationException


class Config:
    CONFIG: str = "config/generator.ini"
    GENERATOR_CONFIG_FILE_ENV: str = "GENERATOR_CONFIG_PATH"

    DEFAULT_CONFIG = """
[storage]
root = config/storage/dev

[version]
#
# context 8, template 1 is for answering questions about CsvPath
#
question.context = 11
question.prompt_template = 1
#
# context 9, template 3 testdata is for creating test data matching a csvpath
#
testdata.context = 10
testdata.prompt_template = 3
#
# context 7, template 2 is the go-to-market for full generation of sample-file validation
#
validation.context = 12
validation.prompt_template = 2

[generations]
limit = 20
turns_limit = 6
call_limit = 20
call_limit_time_block = 600

    """

    #
    # if configpath is None we'll get configpath as the same dir as the
    # csvpath config. if csvpath config is none we'll create a CsvPath
    # and use its config. that means that the csvpath config will be in
    # its default location.
    #
    def __init__(self, *, cfg:CsvPathConfig=None, configpath:str=None):
        if cfg is None:
            cfg = CsvPath().config
        self._cfg:CsvPathConfig = cfg
        self._configpath = None
        self._log_file = None
        self._load_time = None
        self._config = None

        self.set_configpath(cfg=cfg, configpath=configpath)
        self.set_logpath(cfg=cfg)
        self.load()

    @property
    def csvpath_config(self) -> CsvPathConfig:
        return self._cfg

    @property
    def configpath(self) -> str:
        return self._configpath

    @configpath.setter
    def configpath(self, path: str) -> None:
        self._configpath = path

    def set_logpath(self, cfg:CsvPathConfig) -> None:
        _ = self.csvpath_config.get(section="logging", name="log_file")
        _ = os.path.dirname(_)
        self._log_file = os.path.join(_, "generator.log")

    @property
    def log_file(self) -> str:
        return self._log_file

    def set_configpath(self, *, cfg:CsvPathConfig, configpath:str=None) -> None:
        if cfg is None and configpath is None:
            raise ValueError("CsvPath config object cannot be None if configpath is None")
        if configpath:
            self._configpath = configpath
            return
        #
        # check the env
        #
        self._configpath = cfg.get(section=None, name=Config.GENERATOR_CONFIG_FILE_ENV)
        if self._configpath and self._configpath != Config.GENERATOR_CONFIG_FILE_ENV:
            return
        #
        # put into the same dir as csvpath's
        #
        _ = cfg.configpath
        _ = os.path.dirname(_)
        _ = os.path.join(_, "generator.ini")
        self._configpath = _

    def __str__(self) -> str:
        return f"""Config(path: {self._configpath}, log: {self.log_file}, loaded at: {self._load_time}, prod: {self.get('env', 'prod')} root: {self.get('storage', 'root')})
"""

    def dump_config_info(self) -> None:
        print(f"{self}")

    def load(self):
        self._config = RawConfigParser()
        if not os.path.exists(self._configpath):
            os.makedirs(os.path.dirname(self._configpath), exist_ok=True)
            with open(self._configpath, "w") as file:
                file.write(Config.DEFAULT_CONFIG)
        self._load_config()

    def set_config_path_and_reload(self, path: str) -> None:
        self._configpath = path
        self.load()

    def get(self, section: str, name: str, default: str = None):
        if self._config is None:
            raise ConfigurationException("No config object available")
        try:
            s = self._config[section][name]
            s = s.strip()
            ret = None
            if s.find(",") > -1:
                ret = [s.strip() for s in s.split(",")]
            else:
                ret = s
            return ret
        except KeyError:
            return default

    def _load_config(self):
        if not os.path.exists(self._configpath):
            raise ValueError(f"No config found at {self._configpath}")
        self._config.read(self._configpath)
        self._log_file = self.get("logging", "log_file", self._log_file)
        self._load_time = datetime.datetime.now()

    # ======================================


