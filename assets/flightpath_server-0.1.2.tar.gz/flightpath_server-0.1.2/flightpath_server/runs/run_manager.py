import os
import json
from datetime import datetime, timezone
from uuid import UUID, uuid4
from typing import Optional, Any

from pydantic import ValidationError

from csvpath import CsvPaths
from csvpath.util.nos import Nos
from flightpath_server.keys.key import Key
from flightpath_server.keys.key_manager import KeyManager
from flightpath_server.config.app_config import AppConfig
from .run import Run


class RunManager:
    HISTORY_DIR = "history"

    def __init__(self, app_config: AppConfig) -> None:
        os.makedirs(RunManager.HISTORY_DIR, exist_ok=True)
        self.app_config = app_config
        self.key_manager = KeyManager(app_config=app_config)
        self._runs_in_progress: dict[str, Any] = {}

    @property
    def today(self) -> None:
        today = datetime.now(timezone.utc)
        return today.strftime("%Y-%m-%d")

    def path_for_run(self, run: Run) -> str:
        today = self.today
        path = os.path.join(self.HISTORY_DIR, today)
        os.makedirs(path, exist_ok=True)
        path = os.path.join(path, f"{run.run_uuid}.json")
        run.run_summary_path = path
        self.app_config.logger.debug(f"Path for run {run.run_uuid} is {path}")
        return path

    #
    # this will create dup files if a day ends before a run ends. atm, that's
    # not a problem, because this isn't a long-term solution to logging runs.
    #
    def update_runs_in_progress(self, run: Run) -> None:
        path = self.path_for_run(run)
        csvpaths = run.csvpaths
        run.csvpaths = None
        with open(path, "w") as file:
            json.dump(run.model_dump_json(indent=2), file, indent=2)
        if run.end_time is None:
            self._runs_in_progress[run.run_uuid] = run
        else:
            del self._runs_in_progress[run.run_uuid]
        run.csvpaths = csvpaths
        self.app_config.logger.info(f"Added run {run.run_uuid} to the runs in progress")

    def new_run(
        self,
        *,
        csvpaths: CsvPaths,
        run_method: str,
        pathsname: str,
        filename: str,
        template: str,
        api_key: str,  # this is the actual key uuid. we hash it below.
        project_name: str,
    ) -> Run:
        new_uuid = uuid4()
        new_run = Run(
            run_uuid=str(new_uuid),
            end_time=None,
            start_time=None,
            csvpaths=csvpaths,
            run_method=run_method,
            pathsname=pathsname,
            filename=filename,
            template=template,
            api_key=self.key_manager.hash_key(api_key),
            result_reference=None,
            project_name=project_name,
            config_path=csvpaths.config.config_path,
        )
        self.update_runs_in_progress(new_run)
        self.app_config.logger.debug(
            f"Created run {new_run.run_uuid}: {run_method}, paths: {pathsname}, file: {filename}, key: {api_key}"
        )
        return new_run

    def do_run(self, run: Run) -> dict[str, Any]:
        if run is None:
            raise ValueError("Run cannot be None")
        self.app_config.logger.info("Starting run", extra={"run": run})
        try:
            method = None
            if run.run_method == "fast_forward_paths":
                method = run.csvpaths.fast_forward_paths
            elif run.run_method == "collect_paths":
                method = run.csvpaths.collect_paths
            elif run.run_method == "collect_by_line":
                method = run.csvpaths.collect_by_line
            elif run.run_method == "fast_forward_by_line":
                method = run.csvpaths.fast_forward_by_line
            else:
                raise ValueError(f"Run method {run.run_method} is not available")
            #
            # overwrite the run .json here to capture the start and any changes
            #
            run.start_time = datetime.now(timezone.utc)
            self.update_runs_in_progress(run)
            ref = method(
                pathsname=run.pathsname, filename=run.filename, template=run.template
            )
            self.app_config.logger.debug(
                f"Run {run.run_uuid} completed: {run.run_method}, paths: {run.pathsname}, file: {run.filename}, key: {run.api_key}"
            )
            run.result_reference = ref
            run.end_time = datetime.now(timezone.utc)
            ret = {"success": True, "reference": ref}
            self.update_runs_in_progress(run)
            return ret
        except Exception as e:
            import traceback

            print(traceback.format_exc())
            run.end_time = datetime.now()
            self.app_config.logger.error(f"Error in run {run.run_uuid}: {e}")
            return {"success": False, "errors": [traceback.format_exc()]}

    def get_runs(
        self,
        *,
        api_key: Optional[str] = None,
        run_uuid_str: Optional[str] = None,
        pathsname: Optional[str] = None,
        filename: Optional[str] = None,
    ) -> list[Run]:
        runs = self._runs_in_progress
        if run_uuid_str is not None:
            for k, v in runs.items():
                if k == run_uuid_str:
                    return [v]
        lst = [r for k, r in runs.items()]
        if api_key is not None:
            api_key = self.key_manager.hash_key(api_key)
            lst = [r for r in lst if r.api_key == api_key]
        if pathsname is not None:
            lst = [r for r in lst if r.paths_name == pathsname]
        if filename is not None:
            lst = [r for r in lst if r.file_name == filename]
        return lst
