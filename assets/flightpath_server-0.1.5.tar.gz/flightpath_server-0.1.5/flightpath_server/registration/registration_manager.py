import traceback
from typing import Any, Optional
from csvpath import CsvPaths
from csvpath.util.nos import Nos
from csvpath.util.file_readers import DataFileReader
from csvpath.util.references.reference_parser import ReferenceParser
from csvpath.util.references.files_reference_finder_2 import (
    FilesReferenceFinder2 as FilesReferenceFinder,
)
from flightpath_server.config.app_config import AppConfig


class RegistrationManager:
    def __init__(self, *, csvpaths: CsvPaths, app_config: AppConfig):
        self.csvpaths = csvpaths
        self.app_config = app_config

    #
    # this is a blanket restriction across the API. CsvPaths will also
    # check more specifically for the ability to register local and http.
    #
    def check_file_location(self, file_location: str) -> None:
        v = self.app_config.get(
            section="security", name="localhost_files_allowed", default="False"
        )
        localhost_files_allowed = v and v.strip().lower() == "true"
        is_plain_filesystem_path = not any(
            file_location.startswith(prefix)
            for prefix in [
                "http://",
                "https://",
                "s3://",
                "sftp://",
                "azure://",
                "gcs://",
            ]
        )
        if localhost_files_allowed is not True and is_plain_filesystem_path:
            raise ValueError(
                "Registration of local filesystem paths is not allowed by configuration in this server"
            )

    def register_file(
        self,
        *,
        named_file_name: str,
        file_location: str,
        template: Optional[str] = None,
    ) -> dict[str, Any]:
        try:
            self.check_file_location(file_location)
            if not self.csvpaths.paths_manager.can_load(file_location):
                raise ValueError(
                    f"Registration of local filesystem paths is not allowed by configuration in this project. See: {self.csvpaths.config.configpath}."
                )

            if Nos(file_location).exists():
                ref = self.csvpaths.file_manager.add_named_file(
                    name=named_file_name, path=file_location, template=template
                )
                if ref is None:
                    raise RuntimeError("Registration reference cannot be None")
                return {
                    "success": True,
                    "message": f"File '{named_file_name}' registered successfully.",
                    "reference": ref,
                }
            self.app_config.logger.error(
                f"There is no file to register at {file_location}"
            )
            return {
                "success": False,
                "errors": [
                    f"File not accessible at '{file_location}'. Please check the path or your configuration."
                ],
            }
        except Exception as e:
            print(traceback.format_exc())
            self.app_config.logger.error(traceback.format_exc())
            return {"success": False, "errors": [str(e)]}

    def register_csvpath_group(
        self,
        named_paths_name: str,
        file_location: str,
        template: Optional[str] = None,
        append: bool = False,
    ) -> dict[str, Any]:
        try:
            self.check_file_location(file_location)
            ret = None

            if not self.csvpaths.paths_manager.can_load(file_location):
                raise ValueError(
                    "Registration of local filesystem paths is not allowed by configuration in this project"
                )

            if Nos(file_location).exists():
                ref = self.csvpaths.paths_manager.add_named_paths_from_file(
                    name=named_paths_name,
                    file_path=file_location,
                    template=template,
                    append=append,
                )
                if ref is None:
                    raise RuntimeError("Registration reference cannot be None")
                ret = {
                    "success": True,
                    "message": f"Path '{named_paths_name}' registered successfully.",
                    "reference": ref,
                }
            else:
                self.app_config.logger.error(
                    f"There is no file to register at {file_location}"
                )
                ret = {
                    "success": False,
                    "errors": [
                        f"File not accessible at '{file_location}'. Please check the path or your configuration."
                    ],
                }
            return ret
        except Exception as e:
            print(traceback.format_exc())
            self.app_config.logger.error(traceback.format_exc())
            return {"success": False, "errors": [str(e)]}

    def find_files(self, reference: str) -> dict[str, Any]:
        try:
            ref = ReferenceParser(reference, csvpaths=self.csvpaths)
            finder = FilesReferenceFinder(self.csvpaths, ref=ref)
            files = finder.resolve()
            if files is None:
                self.app_config.logger.info(f"No files found for {reference}")
                return {"success": False, "message": "No files found"}
            return {"success": True, "files": files}
        except Exception as e:
            print(traceback.format_exc())
            self.app_config.logger.error(traceback.format_exc())
            return {"success": False, "errors": [str(e)]}

    def get_file(self, reference: str) -> dict[str, Any]:
        try:
            path = self.csvpaths.file_manager.get_named_file(reference)
            if path is None:
                return {"success": False, "message": "No file found"}
            if isinstance(path, list):
                if len(path) > 1:
                    self.app_config.logger.info(f"Multiple files found for {reference}")
                    return {
                        "success": False,
                        "message": "Reference must point to 1 file",
                    }
            path = path[0] if isinstance(path, list) else path
            nos = Nos(path)
            if not nos.exists():
                self.app_config.logger.info(f"No file found for {reference}")
                return {
                    "success": False,
                    "message": "Reference pointed to a file but there was no data",
                }
            with DataFileReader(path, mode="rb") as file:
                return {"success": True, "file": file.read()}
        except Exception as e:
            print(traceback.format_exc())
            self.app_config.logger.error(traceback.format_exc())
            return {"success": False, "errors": [str(e)]}
