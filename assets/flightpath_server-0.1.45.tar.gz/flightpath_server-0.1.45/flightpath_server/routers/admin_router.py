from typing import Optional
import os
import signal
from datetime import datetime
from pydantic import BaseModel
from fastapi import APIRouter, Depends

from flightpath_server.keys.key_manager import KeyManager
from flightpath_server.keys.key import Key
from flightpath_server.config.app_config import AppConfig


from flightpath_server.runs.run_manager import RunManager
from flightpath_server.dependencies import require_admin_key
from flightpath_server.dependencies import get_app_config
from flightpath_server.dependencies import get_key_manager, get_optional_api_key

admin_router = APIRouter()


class NewKeyRequest(BaseModel):
    key_name: str
    key_owner_name: str
    key_owner_contact: str


class MakeAdminRequest(BaseModel):
    api_key: str


class NewKeyResponse(BaseModel):
    api_key: str


class SuccessResponse(BaseModel):
    message: str


class RunInfo(BaseModel):
    run_uuid: str
    start_time: Optional[datetime]
    end_time: Optional[datetime]
    run_method: str
    pathsname: str
    filename: str
    template: Optional[str]
    api_key: str
    result_reference: Optional[str]
    project_name: str
    config_path: str
    run_summary_path: Optional[str] = None


class ActiveRunsResponse(BaseModel):
    runs: list[RunInfo]


@admin_router.post("/new_key")
async def new_key(
    request: NewKeyRequest,
    key_manager: KeyManager = Depends(get_key_manager),
    api_key: str | None = Depends(get_optional_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> NewKeyResponse:
    """
    Creates a new key. When any keys have been made this request requires an API header.
    When no keys have been made, the request creates and returns the server's admin key.
    Any user can create a new key. Keys are a way of grouping and protecting projects. They
    are not an individual user security capability.
    """
    _ = os.getenv(AppConfig.FLIGHTPATH_SERVER_CONFIG)
    if key_manager.has_keys() and not api_key:
        raise app_config.http_error(
            name=__name__,
            code=401,
            msg="An API Key is required to create new keys when keys already exist.",
        )
    # The admin flag is set by the key_manager, so we don't include it here.
    key = Key(
        key_name=request.key_name,
        key_owner_name=request.key_owner_name,
        key_owner_contact=request.key_owner_contact,
        config_file_paths={},
    )
    new_api_key = key_manager.create_key(key=key, api_key=api_key)
    return {"api_key": new_api_key}


@admin_router.get("/active_runs", dependencies=[Depends(require_admin_key)])
def get_active_runs(
    app_config: AppConfig = Depends(get_app_config),
) -> ActiveRunsResponse:
    """Returns information on any runs that are currently in progress."""
    runs = RunManager(app_config=app_config).get_active_runs()
    return {"runs": [run.model_dump(exclude={"csvpaths"}) for run in runs]}


@admin_router.get("/shutdown", dependencies=[Depends(require_admin_key)])
async def shutdown():
    """
    Shuts down the server. Use with care. There is no cooling down period; sessions and runs will be immediately terminated.
    """
    print("Shutdown command received. Shutting down server.")
    os.kill(os.getpid(), signal.SIGTERM)
    return {"message": "Server is shutting down."}


@admin_router.post("/make_admin_key", dependencies=[Depends(require_admin_key)])
async def make_admin_key(
    request: MakeAdminRequest, key_manager: KeyManager = Depends(get_key_manager)
) -> SuccessResponse:
    """
    Sets a key to be an admin key. Requires an admin key in the header.
    """
    try:
        key_manager.set_admin_status(api_key=request.api_key, is_admin=True)
        return {"message": f"Key {request.api_key} has been made an admin key."}
    except ValueError as e:
        key_manager.app_config.dump_info_if(api_key=request.api_key)
        raise key_manager.app_config.http_error(name=__name__, code=404, msg=str(e))
