import hashlib
import os
import uuid
import json
from abc import ABC, abstractmethod
from filelock import FileLock
from flightpath_server.config.app_config import AppConfig
from .key import Key


class KeyStore(ABC):
    @abstractmethod
    def is_admin(self, api_key: str) -> bool: ...

    @abstractmethod
    def add_key(self, key: Key) -> str: ...

    @abstractmethod
    def get_key_data(self, api_key: str) -> Key | None: ...

    @abstractmethod
    def delete_key(self, api_key: str) -> bool: ...

    @abstractmethod
    def update_key_data(self, api_key: str, key: Key) -> bool: ...

    @abstractmethod
    def has_keys(self) -> bool: ...

    @abstractmethod
    def load_all_keys(self) -> dict: ...


class FileKeyStore(KeyStore):
    def __init__(self, app_config: AppConfig) -> None:
        self._app_config = app_config
        self._key_file: str = None
        self.key_file  # resolves path and creates the file if absent
        self._lock = FileLock(self._key_file + ".lock")

    @property
    def app_config(self) -> AppConfig:
        return self._app_config

    @property
    def key_file(self) -> str:
        if self._key_file is None:
            key_file_path = self.app_config.get(
                section="security", name="key_file_path"
            )
            if key_file_path and key_file_path.strip() == "" or not key_file_path:
                self.app_config.logger.debug("No key file in app_config.ini")
                key_file_path = None
            if key_file_path is None and "FLIGHTPATH_API_KEY_FILE" in os.environ:
                self.app_config.logger.debug("Checking for key file in os.environ")
                key_file_path = os.environ["FLIGHTPATH_API_KEY_FILE"]
            if key_file_path and key_file_path.strip() == "" or not key_file_path:
                self.app_config.logger.debug("No key file in os.environ")
                key_file_path = None
            if key_file_path and key_file_path.strip() == "" or not key_file_path:
                self.app_config.logger.debug(
                    "No key file in config or env; using default: ~/FlightPathServer/config/keys.json"
                )
                key_file_path = os.path.expanduser(
                    "~/FlightPathServer/config/keys.json"
                )
            self._key_file = key_file_path
            self.app_config.logger.debug("Assuring key file at %s", key_file_path)
            self.assure_key_file()
        if self._key_file is None:
            raise ValueError("Key file path cannot be None")
        return self._key_file

    @key_file.setter
    def key_file(self, file: str) -> None:
        self._key_file = file

    def assure_key_file(self) -> None:
        key_file = self._key_file
        if key_file is None or key_file.strip() == "":
            raise ValueError("Key file path cannot be None")
        if not os.path.exists(key_file):
            key_dir = os.path.dirname(key_file)
            if key_dir and not os.path.exists(key_dir):
                os.makedirs(key_dir)
            with open(key_file, "w") as file:
                self.app_config.logger.debug("Writing empty key file at %s", key_file)
                file.write("{}")

    # ------------------------------------------------------------------
    # Private helpers — callers must already hold self._lock
    # ------------------------------------------------------------------

    def _load_keys(self) -> dict:
        with open(self.key_file, "r") as f:
            return json.load(f)

    def _save_keys(self, keys: dict) -> None:
        with open(self.key_file, "w") as f:
            json.dump(keys, f, indent=2)

    def _key_index_path(self) -> str:
        index = os.path.join(os.path.dirname(self._key_file), "key_index.json")
        if not os.path.exists(index):
            with open(index, "w") as file:
                file.write("{}")
        return index

    def _index_key_if(self, *, api_key: str, hash_key: str) -> None:
        if api_key is None or hash_key is None:
            raise ValueError("API key and hash key must both have values")
        setting = self._app_config.get(section="security", name="key_index", default="yes")
        if setting in ["on", "yes"]:
            index = self._key_index_path()
            with open(index, "r") as file:
                idx = json.load(file)
            idx[hash_key] = api_key
            with open(index, "w") as file:
                json.dump(idx, file, indent=4)
        else:
            self.app_config.logger.debug("Not indexing keys; key_index config: %s", setting)

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def hash_key(self, api_key: str) -> str:
        return hashlib.sha256(api_key.encode()).hexdigest()

    def has_keys(self) -> bool:
        with self._lock:
            return len(self._load_keys()) > 0

    def load_all_keys(self) -> dict:
        with self._lock:
            return self._load_keys()

    def is_admin(self, api_key: str) -> bool:
        data = self.get_key_data(api_key)
        if data is None:
            raise ValueError("Key data cannot be None")
        return data.admin

    def add_key(self, key: Key) -> str:
        api_key = str(uuid.uuid4())
        hashed_key = self.hash_key(api_key)
        with self._lock:
            keys = self._load_keys()
            keys[hashed_key] = key.model_dump()
            self._save_keys(keys)
            self.app_config.logger.debug("Added key with hash %s", hashed_key)
            self._index_key_if(api_key=api_key, hash_key=hashed_key)
        return api_key

    def get_key_data(self, api_key: str) -> Key | None:
        if not api_key:
            raise ValueError("Api key cannot be None")
        hashed_key = self.hash_key(api_key)
        with self._lock:
            keys = self._load_keys()
        key_data = keys.get(hashed_key)
        return Key(**key_data) if key_data else None

    def delete_key(self, api_key: str) -> bool:
        if not api_key:
            raise ValueError("Api key cannot be None")
        hashed_key = self.hash_key(api_key)
        with self._lock:
            keys = self._load_keys()
            if hashed_key not in keys:
                self.app_config.logger.debug("Cannot delete unknown key hash %s", hashed_key)
                return False
            del keys[hashed_key]
            self._save_keys(keys)
        return True

    def update_key_data(self, api_key: str, key: Key) -> bool:
        if not api_key:
            raise ValueError("Api key cannot be None")
        hashed_key = self.hash_key(api_key)
        with self._lock:
            keys = self._load_keys()
            if hashed_key not in keys:
                self.app_config.logger.debug("Cannot update unknown key hash %s", hashed_key)
                return False
            keys[hashed_key] = key.model_dump()
            self._save_keys(keys)
        return True
