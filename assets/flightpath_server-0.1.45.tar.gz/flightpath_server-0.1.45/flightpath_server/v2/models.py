from datetime import datetime
from typing import Any, Optional
from pydantic import BaseModel


class MessageResponse(BaseModel):
    message: str


class ErrorResponse(BaseModel):
    error: str


class ValueResponse(BaseModel):
    value: str


class NamesResponse(BaseModel):
    names: list[str]


class ReferenceResponse(BaseModel):
    reference: str


class FilesResponse(BaseModel):
    files: list[str]


class PathsResponse(BaseModel):
    paths: list[str]


class RunAcceptedResponse(BaseModel):
    run_uuid: str
    registration_reference: Optional[str] = None


class RunStatusResponse(BaseModel):
    run_uuid: str
    project_name: str
    validation_name: str
    file_name: str
    run_method: str
    start_time: Optional[datetime]
    end_time: Optional[datetime]
    result_reference: Optional[str]


class RunsResponse(BaseModel):
    runs: list[RunStatusResponse]


class NewKeyResponse(BaseModel):
    api_key: str


class ErrorsResponse(BaseModel):
    errors: list[Any]


class MetaResponse(BaseModel):
    meta: dict[str, Any]


class VariablesResponse(BaseModel):
    variables: dict[str, Any]
