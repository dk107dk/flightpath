import base64
import json
import os
from typing import Any, Optional

from fastapi import APIRouter, Depends

from flightpath_server.v2.models import (
    ErrorsResponse,
    MetaResponse,
    NamesResponse,
    VariablesResponse,
    ValueResponse,
)
from flightpath_server.routers.framework_context import fm_context as _fm
from flightpath_server.config.app_config import AppConfig
from flightpath_server.dependencies import get_api_key, get_app_config

archive_router = APIRouter()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _ref(name: str, run_dir: str = None) -> str:
    return f"${name}.results" if run_dir is None else f"${name}.results.{run_dir}"


def _resolve_csvpath_dir(
    api_key: str,
    project_name: str,
    name: str,
    run_dir: str,
    csvpath_id: str,
    app_config: AppConfig,
) -> str:
    """Returns the result directory for the given csvpath_id within a run, or raises 404."""
    with _fm(api_key, project_name, app_config) as fm:
        ret = fm.find_results(_ref(name, run_dir))
    if not ret.get("success"):
        raise app_config.http_error(
            name=__name__,
            code=404,
            msg=ret.get("message") or f"Run '{run_dir}' not found for '{name}'",
        )
    for path in (ret.get("results") or []):
        if os.path.basename(os.path.dirname(path)) == csvpath_id:
            return os.path.dirname(path)
    raise app_config.http_error(
        name=__name__,
        code=404,
        msg=f"Csvpath '{csvpath_id}' not found in run '{run_dir}'",
    )


def _read_json(path: str, fallback: Any) -> Any:
    if not os.path.exists(path):
        return fallback
    with open(path) as f:
        return json.load(f)


def _read_b64(path: str) -> Optional[str]:
    if not os.path.exists(path):
        return None
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@archive_router.get("")
def list_named_results(
    project_name: str,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> NamesResponse:
    """Returns the names of all named-results groups for the project."""
    with _fm(api_key, project_name, app_config) as fm:
        ret = fm.list_result_names()
        if ret.get("success") is True:
            return NamesResponse(names=ret.get("names") or [])
        raise RuntimeError(",".join(ret.get("errors") or ["Unknown error"]))


@archive_router.get("/{name}")
def list_runs(
    name: str,
    project_name: str,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> NamesResponse:
    """Lists run_dirs for a named-paths group (most recent first)."""
    with _fm(api_key, project_name, app_config) as fm:
        ret = fm.find_completed_runs(_ref(name))
    if ret.get("success"):
        runs = ret.get("runs") or []
        return NamesResponse(names=[os.path.basename(r) for r in runs])
    raise RuntimeError(",".join(ret.get("errors") or ["Unknown error"]))


@archive_router.get("/{name}/{run_dir}")
def list_csvpath_ids(
    name: str,
    run_dir: str,
    project_name: str,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> NamesResponse:
    """Lists the csvpath IDs that produced results in a specific run."""
    with _fm(api_key, project_name, app_config) as fm:
        ret = fm.find_results(_ref(name, run_dir))
    if ret.get("success"):
        paths = ret.get("results") or []
        ids = [os.path.basename(os.path.dirname(p)) for p in paths]
        return NamesResponse(names=ids)
    raise app_config.http_error(
        name=__name__,
        code=404,
        msg=ret.get("message") or f"Run '{run_dir}' not found for '{name}'",
    )


@archive_router.get("/{name}/{run_dir}/{csvpath_id}/errors")
def get_errors(
    name: str,
    run_dir: str,
    csvpath_id: str,
    project_name: str,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> ErrorsResponse:
    """Returns errors recorded during this csvpath's run. Returns an empty list if no errors occurred."""
    d = _resolve_csvpath_dir(api_key, project_name, name, run_dir, csvpath_id, app_config)
    errors = _read_json(os.path.join(d, "errors.json"), [])
    return ErrorsResponse(errors=errors if isinstance(errors, list) else [])


@archive_router.get("/{name}/{run_dir}/{csvpath_id}/meta")
def get_meta(
    name: str,
    run_dir: str,
    csvpath_id: str,
    project_name: str,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> MetaResponse:
    """Returns the metadata recorded during this csvpath's run."""
    d = _resolve_csvpath_dir(api_key, project_name, name, run_dir, csvpath_id, app_config)
    meta = _read_json(os.path.join(d, "meta.json"), {})
    return MetaResponse(meta=meta if isinstance(meta, dict) else {})


@archive_router.get("/{name}/{run_dir}/{csvpath_id}/variables")
def get_variables(
    name: str,
    run_dir: str,
    csvpath_id: str,
    project_name: str,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> VariablesResponse:
    """Returns the variables set during this csvpath's run."""
    d = _resolve_csvpath_dir(api_key, project_name, name, run_dir, csvpath_id, app_config)
    variables = _read_json(os.path.join(d, "vars.json"), {})
    return VariablesResponse(variables=variables if isinstance(variables, dict) else {})


@archive_router.get("/{name}/{run_dir}/{csvpath_id}/data")
def get_data(
    name: str,
    run_dir: str,
    csvpath_id: str,
    project_name: str,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> ValueResponse:
    """Returns the base64-encoded content of data.csv (the matched rows) for this csvpath's run."""
    d = _resolve_csvpath_dir(api_key, project_name, name, run_dir, csvpath_id, app_config)
    content = _read_b64(os.path.join(d, "data.csv"))
    if content is None:
        raise app_config.http_error(
            name=__name__, code=404, msg="data.csv not found for this run"
        )
    return ValueResponse(value=content)


@archive_router.get("/{name}/{run_dir}/{csvpath_id}/unmatched")
def get_unmatched(
    name: str,
    run_dir: str,
    csvpath_id: str,
    project_name: str,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> ValueResponse:
    """Returns the base64-encoded content of unmatched.csv (the non-matching rows) for this csvpath's run."""
    d = _resolve_csvpath_dir(api_key, project_name, name, run_dir, csvpath_id, app_config)
    content = _read_b64(os.path.join(d, "unmatched.csv"))
    if content is None:
        raise app_config.http_error(
            name=__name__, code=404, msg="unmatched.csv not found for this run"
        )
    return ValueResponse(value=content)


@archive_router.get("/{name}/{run_dir}/{csvpath_id}/printouts")
def get_printouts(
    name: str,
    run_dir: str,
    csvpath_id: str,
    project_name: str,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> ValueResponse:
    """Returns the base64-encoded printouts for this csvpath's run."""
    d = _resolve_csvpath_dir(api_key, project_name, name, run_dir, csvpath_id, app_config)
    content = _read_b64(os.path.join(d, "printouts.txt"))
    if content is None:
        raise app_config.http_error(
            name=__name__, code=404, msg="printouts.txt not found for this run"
        )
    return ValueResponse(value=content)
