import base64
from typing import Optional
from fastapi import APIRouter, Depends, status
from pydantic import BaseModel

from flightpath_server.v2.models import MessageResponse, NamesResponse, ValueResponse
from flightpath_server.exceptions import NotFoundError
from flightpath_server.projects.project_manager import ProjectManager
from flightpath_server.keys.key_manager import KeyManager
from flightpath_server.config.app_config import AppConfig
from flightpath_server.dependencies import get_api_key, get_app_config, get_key_manager

projects_router = APIRouter()


class CreateProjectRequest(BaseModel):
    name: str
    config_str: Optional[str] = None


class SetValueRequest(BaseModel):
    value: str


def _pm(app_config: AppConfig, key_manager: KeyManager) -> ProjectManager:
    return ProjectManager(app_config=app_config, key_manager=key_manager)


@projects_router.get("")
def list_projects(
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
    key_manager: KeyManager = Depends(get_key_manager),
) -> NamesResponse:
    """Returns the names of all projects associated with the calling API key."""
    try:
        result = _pm(app_config, key_manager).get_project_names(api_key)
        return NamesResponse(names=result["names"])
    except ValueError as e:
        app_config.dump_info_if(api_key=api_key)
        raise app_config.http_error(name=__name__, code=400, msg=str(e))


@projects_router.post("", status_code=status.HTTP_201_CREATED)
def create_project(
    request: CreateProjectRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
    key_manager: KeyManager = Depends(get_key_manager),
) -> MessageResponse:
    """Creates a new project associated with the calling API key."""
    try:
        _pm(app_config, key_manager).create_new_project(
            api_key=api_key, name=request.name, config_str=request.config_str
        )
        return MessageResponse(message=f"Project '{request.name}' created.")
    except ValueError as e:
        app_config.dump_info_if(project_name=request.name, api_key=api_key)
        raise app_config.http_error(name=__name__, code=400, msg=str(e))


@projects_router.delete("/{name}")
def delete_project(
    name: str,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
    key_manager: KeyManager = Depends(get_key_manager),
) -> MessageResponse:
    """Permanently deletes a project with no recovery possible."""
    try:
        _pm(app_config, key_manager).delete_project(api_key=api_key, name=name)
        return MessageResponse(message=f"Project '{name}' deleted.")
    except NotFoundError as e:
        app_config.dump_info_if(project_name=name, api_key=api_key)
        raise app_config.http_error(name=__name__, code=404, msg=str(e))
    except ValueError as e:
        app_config.dump_info_if(project_name=name, api_key=api_key)
        raise app_config.http_error(name=__name__, code=400, msg=str(e))


@projects_router.get("/{name}/config")
def get_config(
    name: str,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
    key_manager: KeyManager = Depends(get_key_manager),
) -> ValueResponse:
    """Returns the CsvPath Framework config.ini for the named project."""
    try:
        value = _pm(app_config, key_manager).get_project_config(api_key, name)
        return ValueResponse(value=value)
    except NotFoundError as e:
        app_config.dump_info_if(project_name=name, api_key=api_key)
        raise app_config.http_error(name=__name__, code=404, msg=str(e))
    except ValueError as e:
        app_config.dump_info_if(project_name=name, api_key=api_key)
        raise app_config.http_error(name=__name__, code=400, msg=str(e))


@projects_router.put("/{name}/config")
def set_config(
    name: str,
    request: SetValueRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
    key_manager: KeyManager = Depends(get_key_manager),
) -> MessageResponse:
    """Sets the CsvPath Framework config.ini for the named project. FlightPath Server modifies the uploaded config to enforce server-safe settings."""
    try:
        _pm(app_config, key_manager).set_project_config(api_key, name, request.value)
        return MessageResponse(message=f"Config for project '{name}' updated.")
    except ValueError as e:
        app_config.dump_info_if(project_name=name, api_key=api_key)
        raise app_config.http_error(name=__name__, code=400, msg=str(e))


@projects_router.get("/{name}/config/{section}/{field}")
def get_config_field(
    name: str,
    section: str,
    field: str,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
    key_manager: KeyManager = Depends(get_key_manager),
) -> ValueResponse:
    """Returns a single field from the project's config.ini."""
    try:
        value = _pm(app_config, key_manager).get_project_config_field(
            api_key=api_key, project_name=name, section=section, field=field
        )
        return ValueResponse(value=value)
    except NotFoundError as e:
        app_config.dump_info_if(project_name=name, api_key=api_key)
        raise app_config.http_error(name=__name__, code=404, msg=str(e))
    except ValueError as e:
        app_config.dump_info_if(project_name=name, api_key=api_key)
        raise app_config.http_error(name=__name__, code=400, msg=str(e))


@projects_router.put("/{name}/config/{section}/{field}")
def set_config_field(
    name: str,
    section: str,
    field: str,
    request: SetValueRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
    key_manager: KeyManager = Depends(get_key_manager),
) -> MessageResponse:
    """Sets a single field in the project's config.ini. Server-managed fields are rejected with 400."""
    try:
        _pm(app_config, key_manager).set_project_config_field(
            api_key=api_key, project_name=name, section=section, field=field, value=request.value
        )
        return MessageResponse(message=f"Config field '{section}.{field}' updated for project '{name}'.")
    except NotFoundError as e:
        app_config.dump_info_if(project_name=name, api_key=api_key)
        raise app_config.http_error(name=__name__, code=404, msg=str(e))
    except ValueError as e:
        app_config.dump_info_if(project_name=name, api_key=api_key)
        raise app_config.http_error(name=__name__, code=400, msg=str(e))


@projects_router.get("/{name}/env")
def get_env(
    name: str,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
    key_manager: KeyManager = Depends(get_key_manager),
) -> ValueResponse:
    """Returns the env.json file for the named project."""
    try:
        value = _pm(app_config, key_manager).get_env_file(api_key, name)
        return ValueResponse(value=value)
    except NotFoundError as e:
        app_config.dump_info_if(project_name=name, api_key=api_key)
        raise app_config.http_error(name=__name__, code=404, msg=str(e))
    except ValueError as e:
        app_config.dump_info_if(project_name=name, api_key=api_key)
        raise app_config.http_error(name=__name__, code=400, msg=str(e))


@projects_router.put("/{name}/env")
def set_env(
    name: str,
    request: SetValueRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
    key_manager: KeyManager = Depends(get_key_manager),
) -> MessageResponse:
    """Replaces the env.json file for the named project. env.json holds values used in place of OS environment variables within the project."""
    try:
        _pm(app_config, key_manager).set_env_file(api_key, name, request.value)
        return MessageResponse(message=f"Environment file for project '{name}' updated.")
    except ValueError as e:
        app_config.dump_info_if(project_name=name, api_key=api_key)
        raise app_config.http_error(name=__name__, code=400, msg=str(e))


@projects_router.patch("/{name}/env/{env_key}")
def set_env_key(
    name: str,
    env_key: str,
    request: SetValueRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
    key_manager: KeyManager = Depends(get_key_manager),
) -> MessageResponse:
    """Sets a single variable in the project's env.json. Creates the key if it does not exist."""
    try:
        _pm(app_config, key_manager).set_env_key(api_key, name, env_key, request.value)
        return MessageResponse(message=f"Environment key '{env_key}' set for project '{name}'.")
    except ValueError as e:
        app_config.dump_info_if(project_name=name, api_key=api_key)
        raise app_config.http_error(name=__name__, code=400, msg=str(e))


@projects_router.get("/{name}/files/{file_path:path}")
def get_file(
    name: str,
    file_path: str,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
    key_manager: KeyManager = Depends(get_key_manager),
) -> ValueResponse:
    """Returns a base64-encoded file from the project. Config files (config.ini, env.json) are not accessible via this endpoint."""
    try:
        content = _pm(app_config, key_manager).get_file(api_key, name, file_path)
        return ValueResponse(value=base64.b64encode(content).decode("utf-8"))
    except NotFoundError as e:
        app_config.dump_info_if(project_name=name, api_key=api_key)
        raise app_config.http_error(name=__name__, code=404, msg=str(e))
    except ValueError as e:
        app_config.dump_info_if(project_name=name, api_key=api_key)
        raise app_config.http_error(name=__name__, code=400, msg=str(e))
    except Exception as e:
        app_config.dump_info_if(project_name=name, api_key=api_key)
        raise app_config.http_error(name=__name__, code=500, msg=str(e))


@projects_router.put("/{name}/files/{file_path:path}")
def put_file(
    name: str,
    file_path: str,
    request: SetValueRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
    key_manager: KeyManager = Depends(get_key_manager),
) -> MessageResponse:
    """Stores a base64-encoded file in the project at the given path. Config files cannot be overwritten via this endpoint."""
    try:
        content = base64.b64decode(request.value)
        _pm(app_config, key_manager).add_file(api_key, name, file_path, content)
        return MessageResponse(message=f"File '{file_path}' stored in project '{name}'.")
    except ValueError as e:
        app_config.dump_info_if(project_name=name, api_key=api_key)
        raise app_config.http_error(name=__name__, code=400, msg=str(e))
    except Exception as e:
        app_config.dump_info_if(project_name=name, api_key=api_key)
        raise app_config.http_error(name=__name__, code=500, msg=str(e))
