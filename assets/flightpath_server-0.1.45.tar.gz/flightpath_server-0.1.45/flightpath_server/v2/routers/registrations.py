import base64
from typing import Optional
from fastapi import APIRouter, Depends, Query, status
from pydantic import BaseModel

from flightpath_server.v2.models import FilesResponse, NamesResponse, ReferenceResponse, ValueResponse
from flightpath_server.routers.framework_context import fm_context as _fm
from flightpath_server.config.app_config import AppConfig
from flightpath_server.dependencies import get_api_key, get_app_config

registrations_router = APIRouter()


class RegisterFileRequest(BaseModel):
    project_name: str
    file_location: str
    template: Optional[str] = None


def _name_from_reference(reference: str) -> str:
    """Extracts the named-file name from a reference string.

    Reference format: $name[#worksheet].files.<tokens>
    e.g. $orders.files.2026-04-12:last  →  orders
         $invoices#Sheet1.files.last    →  invoices
    """
    s = reference.lstrip("$")
    name_part = s.split(".files.")[0]
    return name_part.split("#")[0]


def _assert_reference_name(name: str, reference: str, app_config: AppConfig) -> None:
    ref_name = _name_from_reference(reference)
    if ref_name != name:
        raise app_config.http_error(
            name=__name__,
            code=400,
            msg=f"Reference name '{ref_name}' does not match path name '{name}'",
        )


@registrations_router.get("")
def list_registrations(
    project_name: str,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> NamesResponse:
    """Returns the names of all registered named-files for the project."""
    with _fm(api_key, project_name, app_config) as fm:
        ret = fm.list_file_names()
        if ret.get("success") is True:
            return NamesResponse(names=ret.get("names") or [])
        raise RuntimeError(",".join(ret.get("errors") or ["Unknown error"]))


@registrations_router.post("/{name}", status_code=status.HTTP_201_CREATED)
def register_file(
    name: str,
    request: RegisterFileRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> ReferenceResponse:
    """Registers a new version of a named file. Returns a reference that identifies this version."""
    with _fm(api_key, request.project_name, app_config) as fm:
        ret = fm.register_file(
            named_file_name=name,
            file_location=request.file_location,
            template=request.template,
        )
        if ret.get("success") is True:
            return ReferenceResponse(reference=ret.get("reference"))
        raise RuntimeError(",".join(ret.get("errors") or ["Registration failed"]))


@registrations_router.get("/{name}")
def find_files(
    name: str,
    project_name: str,
    reference: Optional[str] = Query(default=None),
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> FilesResponse:
    """Returns the paths of registered named-file versions matching the reference. Omitting reference returns all versions of the most recent file (equivalent to $name.files.:last)."""
    if reference is not None:
        _assert_reference_name(name, reference, app_config)
    with _fm(api_key, project_name, app_config) as fm:
        ret = fm.find_registered_files(reference=reference or name)
        if ret.get("success") is True:
            return FilesResponse(files=ret.get("files") or [])
        raise RuntimeError(",".join(ret.get("errors") or [ret.get("message")] or ["Unknown error"]))


@registrations_router.get("/{name}/content")
def get_file_content(
    name: str,
    project_name: str,
    reference: Optional[str] = Query(default=None),
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> ValueResponse:
    """Returns the base64-encoded content of the registered file identified by the reference. Omitting reference returns the most recent file. The reference must resolve to exactly one file."""
    if reference is not None:
        _assert_reference_name(name, reference, app_config)
    with _fm(api_key, project_name, app_config) as fm:
        ret = fm.get_registered_file(reference=reference or name)
        if ret.get("success") is True:
            file = ret.get("file")
            if not isinstance(file, bytes):
                file = file.encode("utf-8")
            return ValueResponse(value=base64.b64encode(file).decode("utf-8"))
        raise RuntimeError(ret.get("message") or ",".join(ret.get("errors") or ["Unknown error"]))
