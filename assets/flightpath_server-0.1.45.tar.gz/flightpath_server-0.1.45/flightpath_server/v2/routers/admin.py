import os
import signal
from fastapi import APIRouter, Depends, status
from pydantic import BaseModel

from flightpath_server.keys.key_manager import KeyManager
from flightpath_server.keys.key import Key
from flightpath_server.projects.project_manager import ProjectManager
from flightpath_server.runs.run_manager import RunManager
from flightpath_server.util.config_updater import ConfigUpdater
from flightpath_server.v2.models import MessageResponse, NewKeyResponse, RunsResponse
from flightpath_server.v2.routers.runs import _run_to_status
from flightpath_server.config.app_config import AppConfig
from flightpath_server.dependencies import (
    get_app_config,
    get_key_manager,
    get_optional_api_key,
    require_admin_key,
)

admin_router = APIRouter()


class CreateKeyRequest(BaseModel):
    key_name: str
    key_owner_name: str
    key_owner_contact: str


class PromoteKeyRequest(BaseModel):
    api_key: str


class SetLocalFilesRequest(BaseModel):
    allowed: bool


def _server_local_files_allowed(app_config: AppConfig) -> bool:
    val = app_config.get(section="security", name="localhost_files_allowed", default="no")
    return str(val).strip().lower() in ("yes", "true", "on")


@admin_router.post("/keys", status_code=status.HTTP_201_CREATED)
async def create_key(
    request: CreateKeyRequest,
    key_manager: KeyManager = Depends(get_key_manager),
    api_key: str | None = Depends(get_optional_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> NewKeyResponse:
    """Creates a new API key. When keys already exist, a valid API key header is required. When no keys exist, this endpoint is unauthenticated — it creates the server's first (admin) key."""
    if key_manager.has_keys() and not api_key:
        raise app_config.http_error(
            name=__name__,
            code=401,
            msg="An API key is required to create new keys when keys already exist.",
        )
    key = Key(
        key_name=request.key_name,
        key_owner_name=request.key_owner_name,
        key_owner_contact=request.key_owner_contact,
        config_file_paths={},
    )
    new_api_key = key_manager.create_key(key=key, api_key=api_key)
    return NewKeyResponse(api_key=new_api_key)


@admin_router.post("/keys/admin", dependencies=[Depends(require_admin_key)])
async def promote_key(
    request: PromoteKeyRequest,
    key_manager: KeyManager = Depends(get_key_manager),
    app_config: AppConfig = Depends(get_app_config),
) -> MessageResponse:
    """Promotes an existing key to admin status. Requires an admin key in the request header."""
    try:
        key_manager.set_admin_status(api_key=request.api_key, is_admin=True)
        return MessageResponse(message="Key promoted to admin status.")
    except ValueError as e:
        raise app_config.http_error(name=__name__, code=404, msg=str(e))


@admin_router.get("/runs", dependencies=[Depends(require_admin_key)])
def list_all_active_runs(
    app_config: AppConfig = Depends(get_app_config),
) -> RunsResponse:
    """Returns all active runs across all API keys. Admin access only."""
    runs = RunManager(app_config=app_config).get_active_runs()
    return RunsResponse(runs=[_run_to_status(r) for r in runs])


@admin_router.post("/shutdown", dependencies=[Depends(require_admin_key)])
async def shutdown() -> MessageResponse:
    """Shuts down the server immediately. Active runs will be terminated. Admin access only."""
    print("Shutdown command received. Shutting down server.")
    os.kill(os.getpid(), signal.SIGTERM)
    return MessageResponse(message="Server is shutting down.")


@admin_router.put("/local-files", dependencies=[Depends(require_admin_key)])
def set_server_local_files(
    request: SetLocalFilesRequest,
    key_manager: KeyManager = Depends(get_key_manager),
    app_config: AppConfig = Depends(get_app_config),
) -> MessageResponse:
    """Sets localhost_files_allowed on the server. Disabling cascades to every project, setting allow_local_files = no on each."""
    value = "yes" if request.allowed else "no"
    ConfigUpdater.update(
        path=app_config.configpath,
        section="security",
        name="localhost_files_allowed",
        value=value,
    )
    app_config.reload()
    if not request.allowed:
        pm = ProjectManager(app_config=app_config, key_manager=key_manager)
        for config_path in pm.get_all_project_config_paths():
            ConfigUpdater.update(
                path=config_path,
                section="inputs",
                name="allow_local_files",
                value="no",
            )
    state = "enabled" if request.allowed else "disabled"
    return MessageResponse(message=f"Server local files {state}.")


@admin_router.put("/projects/{project_name}/local-files", dependencies=[Depends(require_admin_key)])
def enable_project_local_files(
    project_name: str,
    key_manager: KeyManager = Depends(get_key_manager),
    app_config: AppConfig = Depends(get_app_config),
) -> MessageResponse:
    """Enables local file access for a specific project. Server must have localhost_files_allowed = yes."""
    if not _server_local_files_allowed(app_config):
        raise app_config.http_error(
            name=__name__,
            code=403,
            msg="Server does not permit local files. Set localhost_files_allowed = yes first.",
        )
    pm = ProjectManager(app_config=app_config, key_manager=key_manager)
    config_path = pm.find_project_config_path(project_name)
    if config_path is None:
        raise app_config.http_error(
            name=__name__,
            code=404,
            msg=f"Project '{project_name}' not found.",
        )
    ConfigUpdater.update(
        path=config_path,
        section="inputs",
        name="allow_local_files",
        value="yes",
    )
    return MessageResponse(message=f"Local files enabled for project '{project_name}'.")
