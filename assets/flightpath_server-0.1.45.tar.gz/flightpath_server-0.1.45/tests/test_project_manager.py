import pytest
import os
import io
import configparser
from configparser import ConfigParser
from unittest.mock import MagicMock
from flightpath_server.keys.key_manager import KeyManager
from flightpath_server.projects.project_manager import ProjectManager, _SERVER_MANAGED_FIELDS
from flightpath_server.keys.key import Key
from flightpath_server.config.app_config import AppConfig
from flightpath_server.exceptions import NotFoundError


@pytest.fixture
def app_config():
    path = os.path.join(
        "tests",
        "test_resources",
        "config",
        "app_config",
        "project_manager_app_config.ini",
    )
    app_config = AppConfig(path)
    return app_config


@pytest.fixture
def key_manager():
    path = os.path.join(
        "tests",
        "test_resources",
        "config",
        "app_config",
        "project_manager_app_config.ini",
    )
    app_config = AppConfig(path)
    key_file = app_config.get(section="security", name="key_file_path")

    if os.path.exists(key_file):
        os.remove(key_file)
    key_manager = KeyManager(app_config=app_config)
    key_data = {
        "key_name": "test user",
        "key_owner_name": "dk",
        "key_owner_contact": "foo",
        "admin": False,
        "config_file_paths": {},
    }
    user_uuid = key_manager.create_key(key=Key(**key_data))
    return user_uuid, key_manager

    # a test api key:
    # a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11
    # 0aca198ee7979a67105e1a1f69ddbff10f82c7d8d2f69a2a41a15d75ac2d1146


"""
def test_remove_common_prefix(key_manager, app_config):
    s = os.sep
    path1 = f"a{s}b{s}c{s}e"
    path2 = f"{s}a{s}b{s}c{s}e"
    a = f"{s}a{s}b{s}c{s}d"
    b = f"{s}a{s}b{s}f"
    c = f"{s}a{s}b{s}c{s}e"
    d = f"{s}x{s}y{s}z"
    mgr = ProjectManager(app_config=app_config, key_manager=key_manager)
    assert "" == mgr._get_common_prefix(path1, [a, b])

    assert f"a{s}b" == mgr._get_common_prefix(path2, [a, b])
    assert f"c{s}e" == mgr._remove_common_prefix(path2, [a, b])

    assert f"a{s}b" == mgr._get_common_prefix(path2, [a, b])

    assert f"a{s}b{s}c" == mgr._get_common_prefix(path2, [a])

    assert f"a{s}b" == mgr._get_common_prefix(path2, [b])

    assert f"a{s}b{s}c{s}e" == mgr._get_common_prefix(path2, [c])

    assert "" == mgr._get_common_prefix(path2, [d])
    assert f"{s}a{s}b{s}c{s}e" == mgr._remove_common_prefix(path2, [d])
"""


def test_is_relative():
    with pytest.raises(ValueError):
        ProjectManager._is_relative("ALL_CAPS")
    with pytest.raises(ValueError):
        ProjectManager._is_relative("../fish")
    with pytest.raises(ValueError):
        ProjectManager._is_relative("..\\fish")
    with pytest.raises(ValueError):
        ProjectManager._is_relative("bugs\\..\\fish")
    with pytest.raises(ValueError):
        ProjectManager._is_relative("bugs/../fish")
    with pytest.raises(ValueError):
        ProjectManager._is_relative("$[*][no()]")
    with pytest.raises(ValueError):
        ProjectManager._is_relative("~mdata~ $[*][no()]")
    assert not ProjectManager._is_relative("sftp://x/y/z")
    assert not ProjectManager._is_relative("c:\\x\\y\\z")
    assert not ProjectManager._is_relative("\\\\share\\x\\y\\z")
    assert not ProjectManager._is_relative("/x/y/z")
    assert ProjectManager._is_relative("x/y/z")
    assert ProjectManager._is_relative("x\\y\\z")


def test_inputs_and_archive(key_manager, app_config):
    s = os.sep
    sp = "c:\\" if s == "\\" else s
    sftp = "sftp://127.0.0.1:2022/a/b/c"
    config_str = f"""

[inputs]
files = {sftp}
csvpaths = d{s}e{s}f

[results]
archive = {sp}g{s}h{s}i
transfers = {sp}projects{s}xyz{s}foo{s}a{s}b{s}c

"""
    print(f"configss: {config_str}")
    app_config.set(section="security", name="localhost_files_allowed", value="no")
    config = ConfigParser()
    config.read_string(config_str)
    string_buffer = io.StringIO()
    config.write(string_buffer)
    config_str = string_buffer.getvalue()

    mgr = ProjectManager(app_config=app_config, key_manager=key_manager)

    config_str = mgr._update_inputs_and_results_paths(
        config_str=config_str,
        projects_dir=f"{sp}projects",
        hash_key="xyz",
        project_name="foo",
    )

    config = ConfigParser()
    config.read_string(config_str)
    assert config["inputs"]["files"] == sftp
    assert config["inputs"]["csvpaths"] == f"{sp}projects{s}xyz{s}foo{s}d{s}e{s}f"
    assert config["results"]["archive"] == f"{sp}projects{s}xyz{s}foo{s}i"
    assert config["results"]["transfers"] == f"{sp}projects{s}xyz{s}foo{s}a{s}b{s}c"


def test_create_new_project(key_manager, app_config):
    api_key = key_manager[0]
    key_manager = key_manager[1]
    proj_manager = ProjectManager(app_config=app_config, key_manager=key_manager)
    projects = os.path.expanduser("~/FlightPathServer/projects")
    project_name = "my-new-config"
    config_str = """
                 [test]
                 key=value
                 [inputs]
                 files =
                 csvpaths =
                 [results]
                 archive =
                 transfers =
                 [config]
                 path =
                 """
    key_data = key_manager.get_key_data(api_key)
    assert len(key_data.config_file_paths) == 0

    proj_manager.create_new_project(
        api_key=api_key, name=project_name, config_str=config_str
    )
    hash_key = key_manager.hash_key(api_key)
    path = os.path.join(projects, hash_key, project_name, "config", "config.ini")
    assert os.path.exists(path)

    key_data = key_manager.get_key_data(api_key)
    assert len(key_data.config_file_paths) == 1
    assert key_data.config_file_paths[project_name] == path
    _check_config_path_matches_path(path)


def _check_config_path_matches_path(path: str) -> None:
    config = configparser.ConfigParser()
    with open(path, "r") as file:
        config.read_file(file)
    p = config["config"]["path"]
    if p != path:
        raise ValueError(f"Config path must be {path}, not {p}")


def test_create_project_already_exists(key_manager, app_config):
    api_key = key_manager[0]
    key_manager = key_manager[1]
    proj_manager = ProjectManager(app_config=app_config, key_manager=key_manager)
    project_name = "my-new-config"
    config_str = """
                 [test]
                 key=value
                 [inputs]
                 files =
                 csvpaths =
                 [results]
                 archive =
                 transfers =
                 [config]
                 path =
                 """
    key_data = key_manager.get_key_data(api_key)
    assert len(key_data.config_file_paths) == 0
    proj_manager.create_new_project(
        api_key=api_key, name=project_name, config_str=config_str
    )
    with pytest.raises(
        ValueError, match=f"Config '{project_name}' already exists for key"
    ):
        proj_manager.create_new_project(
            api_key=api_key, name=project_name, config_str=config_str
        )


def test_delete_project(key_manager, app_config):
    api_key = key_manager[0]
    key_manager = key_manager[1]
    proj_manager = ProjectManager(app_config=app_config, key_manager=key_manager)
    projects = os.path.expanduser("~/FlightPathServer/projects")
    project_name = "my-new-config"
    config_str = """
                 [test]
                 key=value
                 [inputs]
                 files =
                 csvpaths =
                 [results]
                 archive =
                 transfers =
                 [config]
                 path =
                 [cache]
                 [logging]
                 """
    key_data = key_manager.get_key_data(api_key)
    assert len(key_data.config_file_paths) == 0
    hash_key = key_manager.hash_key(api_key)
    path = os.path.join(projects, hash_key, project_name, "config", "config.ini")

    proj_manager.create_new_project(
        api_key=api_key, name=project_name, config_str=config_str
    )
    assert os.path.exists(path)

    key_data = key_manager.get_key_data(api_key)
    assert len(key_data.config_file_paths) == 1
    assert key_data.config_file_paths[project_name] == path

    proj_manager.delete_project(api_key=api_key, name=project_name)

    key_data = key_manager.get_key_data(api_key)
    assert len(key_data.config_file_paths) == 0
    assert not os.path.exists(path)
    path = os.path.join("tests", "test_resources", projects, hash_key, project_name)
    assert not os.path.exists(path)


def test_set_var_source_bug(app_config):
    # This test is designed to catch a regression of a bug where _set_var_source
    # was called without the required keyword arguments.
    mock_key_manager = MagicMock(spec=KeyManager)
    proj_manager = ProjectManager(app_config=app_config, key_manager=mock_key_manager)
    config_str = "[config]\nallow_var_sub=no\nvar_sub_source="

    # Before the fix, this call would fail with a NameError because projects_dir,
    # hash_key, and project_name were not defined in the scope of _set_var_source.
    # Now, it should run without raising an exception.
    try:
        proj_manager._set_var_source(
            config_str=config_str,
            projects_dir="/tmp",
            hash_key="some_hash",
            project_name="some_project",
        )
    except NameError as e:
        pytest.fail(f"_set_var_source raised a NameError: {e}")
    except TypeError as e:
        pytest.fail(
            f"Caught a TypeError, which likely means the method signature is wrong again: {e}"
        )


def test_set_config_key(app_config, key_manager):
    api_key = key_manager[0]
    key_manager = key_manager[1]
    proj_manager = ProjectManager(app_config=app_config, key_manager=key_manager)
    project_name = "my-new-config"
    try:
        proj_manager.delete_project(api_key=api_key, name=project_name)
    except Exception:
        ...

    config_str = """
                 [test]
                 key=value
                 [inputs]
                 files =
                 csvpaths =
                 [results]
                 archive =
                 transfers =
                 [config]
                 path =
                 [cache]
                 [logging]
                 """
    key_data = key_manager.get_key_data(api_key)
    assert len(key_data.config_file_paths) == 0
    proj_manager.create_new_project(
        api_key=api_key, name=project_name, config_str=config_str
    )

    path = proj_manager.get_project_home(api_key=api_key, project_name=project_name)
    assert os.path.exists(path)

    proj_manager.set_config_key(
        api_key=api_key,
        project_name=project_name,
        section="sftp",
        name="username",
        value="bluejay",
    )
    newcfg = proj_manager.get_project_config(api_key, project_name)
    assert newcfg
    assert newcfg != config_str
    assert newcfg.find("bluejay") > -1


# ---------------------------------------------------------------------------
# NotFoundError
# ---------------------------------------------------------------------------

def test_get_config_unknown_project_raises_not_found(key_manager, app_config):
    api_key, km = key_manager
    pm = ProjectManager(app_config=app_config, key_manager=km)
    with pytest.raises(NotFoundError):
        pm.get_project_config(api_key, "nonexistent")


def test_delete_unknown_project_raises_not_found(key_manager, app_config):
    api_key, km = key_manager
    pm = ProjectManager(app_config=app_config, key_manager=km)
    with pytest.raises(NotFoundError):
        pm.delete_project(api_key=api_key, name="nonexistent")


def test_get_file_nonexistent_raises_not_found(key_manager, app_config):
    api_key, km = key_manager
    pm = ProjectManager(app_config=app_config, key_manager=km)
    with pytest.raises(NotFoundError):
        pm.get_file(api_key, "nonexistent", "data/file.csv")


# ---------------------------------------------------------------------------
# get_project_config_field / set_project_config_field
# ---------------------------------------------------------------------------

def _pm_with_config_file(tmp_path, config_content: str):
    """Returns (pm, api_key) with a mock key_manager pointing to a real config file."""
    config_file = tmp_path / "config.ini"
    config_file.write_text(config_content)
    mock_key = MagicMock()
    mock_key.config_file_paths = {"my-project": str(config_file)}
    key_manager = MagicMock()
    key_manager.get_key_data.return_value = mock_key
    app_config = MagicMock()
    app_config.logger = MagicMock()
    pm = ProjectManager(app_config=app_config, key_manager=key_manager)
    return pm, "test-api-key"


_SAMPLE_CONFIG = """\
[errors]
csvpath = collect, fail, print
csvpaths = print, collect

[logging]
csvpath = info
log_file = /server/managed/path.log

[sql]
dialect = postgres
connection_string = postgresql://localhost/mydb
"""


def test_get_project_config_field_success(tmp_path):
    pm, api_key = _pm_with_config_file(tmp_path, _SAMPLE_CONFIG)
    value = pm.get_project_config_field(
        api_key=api_key, project_name="my-project", section="errors", field="csvpath"
    )
    assert value == "collect, fail, print"


def test_get_project_config_field_unknown_field(tmp_path):
    pm, api_key = _pm_with_config_file(tmp_path, _SAMPLE_CONFIG)
    with pytest.raises(NotFoundError):
        pm.get_project_config_field(
            api_key=api_key, project_name="my-project", section="errors", field="nonexistent"
        )


def test_get_project_config_field_unknown_project():
    mock_key = MagicMock()
    mock_key.config_file_paths = {}
    key_manager = MagicMock()
    key_manager.get_key_data.return_value = mock_key
    pm = ProjectManager(app_config=MagicMock(), key_manager=key_manager)
    with pytest.raises(NotFoundError):
        pm.get_project_config_field(
            api_key="key", project_name="unknown", section="errors", field="csvpath"
        )


def test_set_project_config_field_success(tmp_path):
    pm, api_key = _pm_with_config_file(tmp_path, _SAMPLE_CONFIG)
    pm.set_project_config_field(
        api_key=api_key, project_name="my-project", section="errors", field="csvpath", value="fail"
    )
    config = ConfigParser()
    config.read(str(tmp_path / "config.ini"))
    assert config["errors"]["csvpath"] == "fail"


def test_set_project_config_field_rejects_server_managed(tmp_path):
    pm, api_key = _pm_with_config_file(tmp_path, _SAMPLE_CONFIG)
    for section, field in _SERVER_MANAGED_FIELDS:
        with pytest.raises(ValueError, match="managed by the server"):
            pm.set_project_config_field(
                api_key=api_key, project_name="my-project",
                section=section, field=field, value="anything"
            )


def test_set_project_config_field_rejects_sqlite_dialect(tmp_path):
    pm, api_key = _pm_with_config_file(tmp_path, _SAMPLE_CONFIG)
    with pytest.raises(ValueError, match="sqlite dialect is not permitted"):
        pm.set_project_config_field(
            api_key=api_key, project_name="my-project",
            section="sql", field="dialect", value="sqlite"
        )


def test_set_project_config_field_allows_non_sqlite_dialect(tmp_path):
    pm, api_key = _pm_with_config_file(tmp_path, _SAMPLE_CONFIG)
    pm.set_project_config_field(
        api_key=api_key, project_name="my-project", section="sql", field="dialect", value="mysql"
    )
    config = ConfigParser()
    config.read(str(tmp_path / "config.ini"))
    assert config["sql"]["dialect"] == "mysql"


def test_set_project_config_field_unknown_project():
    mock_key = MagicMock()
    mock_key.config_file_paths = {}
    key_manager = MagicMock()
    key_manager.get_key_data.return_value = mock_key
    pm = ProjectManager(app_config=MagicMock(), key_manager=key_manager)
    with pytest.raises(NotFoundError):
        pm.set_project_config_field(
            api_key="key", project_name="unknown",
            section="errors", field="csvpath", value="fail"
        )
