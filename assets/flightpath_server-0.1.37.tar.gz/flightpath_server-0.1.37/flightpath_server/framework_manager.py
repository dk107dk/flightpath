from typing import Any, Optional
from fastapi.concurrency import run_in_threadpool
from csvpath import CsvPaths
from csvpath.util.box import Box
from flightpath_server.registration.registration_manager import RegistrationManager
from flightpath_server.keys.key_manager import KeyManager
from flightpath_server.runs.run_manager import RunManager
from flightpath_server.runs.results_manager import ResultsManager
from flightpath_server.util.csvpaths_loader import CsvPathsLoader
from flightpath_server.config.app_config import AppConfig

"""
this facade encapsulates use of CsvPath Framework in a multi-threaded env.
"""


class FrameworkManager:
    def __init__(
        self,
        *,
        api_key: str,
        app_config: AppConfig,
        project_name: Optional[str] = None,
        # csvpaths: Optional[CsvPaths] = None,
    ) -> None:
        #
        # this should blow up!
        #
        # lout.config_logger(config=None, name=None, level=None)
        #
        # first thing we do is get and clear the box. box is thread local, so we
        # just need to be sure we're not using stuff from a prior transaction setup
        # on the same thread.
        #
        Box().empty_my_stuff()
        #
        #
        #
        self._app_config = app_config
        self.api_key: str = api_key
        self.key_manager = KeyManager(app_config=app_config)
        self.run_manager = RunManager(app_config=app_config)
        self.results_manager = ResultsManager(app_config=app_config)
        self.key_data = self.key_manager.get_key_data(api_key)
        if not self.key_data:
            raise ValueError(f"Invalid API Key {self.key_data}")
        self.project_name = project_name
        app_config.logger.info(
            f"Setting up FrameworkManager for project {project_name} and key {self.key_data.key_name}"
        )
        self.csvpaths = None
        if self.project_name is None:
            raise ValueError(
                "You must pass a project name if a CsvPaths is not provided"
            )
        self.csvpaths: CsvPaths = CsvPathsLoader.get_csvpaths(
            app_config=app_config, api_key=api_key, project_name=project_name
        )
        self.registration_manager = RegistrationManager(
            csvpaths=self.csvpaths, app_config=app_config
        )
        app_config.logger.debug(
            f"FrameworkManager is ready for project {project_name} and key {self.key_data.key_name}"
        )

    def _cleanup(self) -> None:
        Box().empty_my_stuff()

    @property
    def app_config(self) -> AppConfig:
        return self._app_config

    async def register_file(
        self,
        *,
        named_file_name: str,
        file_location: str,
        template: Optional[str] = None,
    ) -> dict[str, Any]:
        self.app_config.logger.info(
            f"Registering file at {file_location} as {named_file_name} for project {self.project_name} and key {self.key_data.key_name}"
        )
        try:
            return await run_in_threadpool(
                self.registration_manager.register_file,
                named_file_name=named_file_name,
                file_location=file_location,
                template=template,
            )
        finally:
            self._cleanup()

    async def register_csvpath_group(
        self,
        *,
        named_paths_name: str,
        file_location: str,
        template: Optional[str] = None,
        append: bool = False,
    ) -> dict[str, Any]:
        self.app_config.logger.info(
            f"Registering csvpaths at {file_location} as {named_paths_name} for project {self.project_name} and key {self.key_data.key_name}"
        )
        try:
            return await run_in_threadpool(
                self.registration_manager.register_csvpath_group,
                named_paths_name=named_paths_name,
                file_location=file_location,
                template=template,
                append=append,
            )
        finally:
            self._cleanup()

    #
    # need to take a method parameter that is one of: fast_forward_paths, collect_paths, collect_by_line or fast_forward_by_line
    #
    async def run(
        self,
        *,
        named_file_name: str,
        named_paths_name: str,
        method: str,
        override_template: Optional[str] = None,
    ) -> dict[str, Any]:
        try:
            new_run = self.run_manager.new_run(
                csvpaths=self.csvpaths,
                run_method=method,
                pathsname=named_paths_name,
                filename=named_file_name,
                template=override_template,
                api_key=self.api_key,
                project_name=self.project_name,
            )
            self.app_config.logger.info(
                f"Doing a new run of {named_paths_name} against {named_file_name} for project {self.project_name} and key {self.key_data.key_name}"
            )
            return await run_in_threadpool(self.run_manager.do_run, new_run)
        finally:
            self._cleanup()

    async def get_run_path(self, run_reference: str) -> dict[str, Any]:
        self.app_config.logger.info(
            f"Getting run path for {run_reference} for project {self.project_name} and key {self.key_data.key_name}"
        )
        try:
            return await run_in_threadpool(
                self.results_manager.get_run_path,
                run_reference=run_reference,
                api_key=self.api_key,
                project_name=self.project_name,
            )
        finally:
            self._cleanup()

    async def find_completed_runs(self, run_reference: str) -> dict[str, list[str]]:
        self.app_config.logger.info(
            f"Getting runs for {run_reference} for project {self.project_name} and key {self.key_data.key_name}"
        )
        try:
            return await run_in_threadpool(
                self.results_manager.find_completed_runs,
                run_reference=run_reference,
                api_key=self.api_key,
                project_name=self.project_name,
            )
        finally:
            self._cleanup()

    async def get_run_errors(self, run_reference: str) -> dict[str, Any]:
        self.app_config.logger.info(
            f"Getting run errors for {run_reference} for project {self.project_name} and key {self.key_data.key_name}"
        )
        try:
            return await run_in_threadpool(
                self.results_manager.get_run_errors,
                run_reference=run_reference,
                api_key=self.api_key,
                project_name=self.project_name,
            )
        finally:
            self._cleanup()

    async def get_run_metadata(self, run_reference: str) -> dict[str, Any]:
        self.app_config.logger.info(
            f"Getting run metadata for {run_reference} for project {self.project_name} and key {self.key_data.key_name}"
        )
        try:
            return await run_in_threadpool(
                self.results_manager.get_run_metadata,
                run_reference=run_reference,
                api_key=self.api_key,
                project_name=self.project_name,
            )
        finally:
            self._cleanup()

    async def get_run_variables(self, run_reference: str) -> dict[str, Any]:
        self.app_config.logger.info(
            f"Getting run vars for {run_reference} for project {self.project_name} and key {self.key_data.key_name}"
        )
        try:
            return await run_in_threadpool(
                self.results_manager.get_run_variables,
                run_reference=run_reference,
                api_key=self.api_key,
                project_name=self.project_name,
            )
        finally:
            self._cleanup()

    async def get_run_printouts(
        self, *, run_reference: str, printstream: Optional[str] = None
    ) -> dict[str, Any]:
        self.app_config.logger.info(
            f"Getting run printouts for {run_reference} for project {self.project_name} and key {self.key_data.key_name}"
        )
        try:
            return await run_in_threadpool(
                self.results_manager.get_run_printouts,
                run_reference=run_reference,
                api_key=self.api_key,
                project_name=self.project_name,
                printstream=printstream,
            )
        finally:
            self._cleanup()

    async def find_registered_files(self, reference: str) -> dict[str, Any]:
        self.app_config.logger.info(
            f"Finding registered files with path: {reference} for project {self.project_name} and key {self.key_data.key_name}"
        )
        try:
            return await run_in_threadpool(
                self.registration_manager.find_files, reference=reference
            )
        finally:
            self._cleanup()

    async def get_registered_file(self, reference: str) -> dict[str, Any]:
        self.app_config.logger.info(
            f"Getting registered file with id: {reference} for project {self.project_name} and key {self.key_data.key_name}"
        )
        try:
            return await run_in_threadpool(
                self.registration_manager.get_file, reference=reference
            )
        finally:
            self._cleanup()

    async def find_results(self, reference: str) -> dict[str, Any]:
        self.app_config.logger.info(
            f"Finding runs with reference: {reference} for project {self.project_name} and key {self.key_data.key_name}"
        )
        try:
            return await run_in_threadpool(
                self.results_manager.find_results,
                api_key=self.api_key,
                project_name=self.project_name,
                reference=reference,
            )
        finally:
            self._cleanup()

    async def get_result(self, reference: str) -> dict[str, Any]:
        self.app_config.logger.info(
            f"Getting run with id: {reference} for project {self.project_name} and key {self.key_data.key_name}"
        )
        try:
            return await run_in_threadpool(
                self.results_manager.get_result,
                api_key=self.api_key,
                project_name=self.project_name,
                reference=reference,
            )
        finally:
            self._cleanup()
