from typing import List
import os
import signal
from datetime import datetime
from pydantic import BaseModel
from fastapi import HTTPException
from fastapi import APIRouter, Depends

from flightpath_server.keys.key_manager import KeyManager
from flightpath_server.keys.key import Key
from flightpath_server.config.app_config import AppConfig


from flightpath_server.runs.run_manager import RunManager
from flightpath_server.dependencies import require_admin_key
from flightpath_server.dependencies import get_app_config
from flightpath_server.dependencies import get_key_manager, get_optional_api_key

admin_router = APIRouter()

class NewKeyRequest(BaseModel):
    key_name: str
    key_owner_name: str
    key_owner_contact: str

class MakeAdminRequest(BaseModel):
    api_key: str

@admin_router.post("/new_key")
async def new_key(
    request: NewKeyRequest,
    key_manager: KeyManager = Depends(get_key_manager),
    api_key: str | None = Depends(get_optional_api_key),
    app_config: AppConfig = Depends(get_app_config)
) -> dict:
    _ = os.getenv(AppConfig.FLIGHTPATH_SERVER_CONFIG)
    if key_manager.has_keys() and not api_key:
        raise app_config.http_error(name=__name__, code=401, msg="An API Key is required to create new keys when keys already exist.")
        #raise HTTPException(status_code=401, detail="An API Key is required to create new keys when keys already exist.")

    # The admin flag is set by the key_manager, so we don't include it here.
    key = Key(
        key_name=request.key_name,
        key_owner_name=request.key_owner_name,
        key_owner_contact=request.key_owner_contact,
        config_file_paths={}
    )
    new_api_key = key_manager.create_key(key=key, api_key=api_key)
    return {"api_key": new_api_key}

@admin_router.get("/active_runs", dependencies=[Depends(require_admin_key)])
def get_active_runs(app_config: AppConfig = Depends(get_app_config)) -> dict:
    runs = RunManager(app_config=app_config).get_runs()
    return {
        "runs": [run.model_dump_json(exclude={'csvpaths'}) for run in runs]
    }

@admin_router.get("/shutdown", dependencies=[Depends(require_admin_key)])
async def shutdown():
    """
    Shuts down the server.
    """
    print("Shutdown command received. Shutting down server.")
    os.kill(os.getpid(), signal.SIGTERM)
    return {"message": "Server is shutting down."}

@admin_router.post("/make_admin_key", dependencies=[Depends(require_admin_key)])
async def make_admin_key(
    request: MakeAdminRequest,
    key_manager: KeyManager = Depends(get_key_manager)
) -> dict:
    """
    Sets a key to be an admin key.
    """
    try:
        key_manager.set_admin_status(api_key=request.api_key, is_admin=True)
        return {"message": f"Key {request.api_key} has been made an admin key."}
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))

