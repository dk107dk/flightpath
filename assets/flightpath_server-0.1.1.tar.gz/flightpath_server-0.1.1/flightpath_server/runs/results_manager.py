from typing import Any
import os

from csvpath.util.references.reference_parser import ReferenceParser
from csvpath.util.file_readers import DataFileReader
from csvpath.util.nos import Nos

from flightpath_server.keys.key_manager import KeyManager
from flightpath_server.config.app_config import AppConfig
from flightpath_server.runs.csvpaths_loader import CsvPathsLoader

class ResultsManager:

    def __init__(self, app_config:AppConfig):
        if app_config is None:
            raise ValueError("App config cannot be None")
        self.app_config = app_config
        self.key_manager = KeyManager(app_config=app_config)

    def get_run_path(self, *, api_key:str, project_name:str, run_reference: str) -> dict[str, Any]:
        try:
            csvpaths = CsvPathsLoader.get_csvpaths(app_config=self.app_config, api_key=api_key, project_name=project_name)
            ref = ReferenceParser(string=run_reference, csvpaths=csvpaths)
            name = ref.root_major
            home = csvpaths.results_manager.get_named_results_home(name)
            if home is None:
                raise ValueError(f"No results for reference {run_reference}")
            archive = csvpaths.config.get(section="results", name="archive")
            path = os.path.join(archive, home)
            return {"success": True, "path": path}
        except Exception as e:
            import traceback
            print(traceback.format_exc())
            self.app_config.logger.error(str(e))
            return {"success": False, "errors": [str(e)]}

    def get_run_errors(self, *, api_key:str, project_name:str, run_reference: str) -> dict[str, Any]:
        if run_reference is None:
            raise ValueError("Run reference cannot be None")
        csvpaths = CsvPathsLoader.get_csvpaths(app_config=self.app_config, api_key=api_key, project_name=project_name)
        try:
            errors = csvpaths.results_manager.get_errors(run_reference)
            if len(errors) == 0:
                #
                # results manager is currently too forgiving so we need to double check
                #
                if csvpaths.results_manager.get_named_results(run_reference) is None:
                    raise ValueError(f"{run_reference} does not point to results")
            es = [e.to_json() for e in errors]
            return {"success": True, "errors": es}
        except Exception as e:
            import traceback
            print(traceback.format_exc())
            self.app_config.logger.error(str(e))
            return {"success": False, "errors": [str(e)]}

    def get_run_metadata(self, api_key:str, project_name:str, run_reference: str) -> dict[str, Any]:
        if run_reference is None:
            raise ValueError("Run reference cannot be None")
        csvpaths = CsvPathsLoader.get_csvpaths(app_config=self.app_config, api_key=api_key, project_name=project_name)
        try:
            metadata: dict[str, Any] = csvpaths.results_manager.get_metadata(run_reference)
            if len(metadata) == 0:
                #
                # results manager is currently too forgiving so we need to double check
                #
                if csvpaths.results_manager.get_named_results(run_reference) is None:
                    raise ValueError(f"{run_reference} does not point to results")
            return {"success": True, "metadata": metadata}
        except Exception as e:
            self.app_config.logger.error(str(e))
            return {"success": False, "errors": [str(e)]}

    def get_run_variables(self, api_key:str, project_name:str, run_reference: str) -> dict[str, Any]:
        if run_reference is None:
            raise ValueError("Run reference cannot be None")
        csvpaths = CsvPathsLoader.get_csvpaths(app_config=self.app_config, api_key=api_key, project_name=project_name)
        try:
            variables: dict[str, Any] = csvpaths.results_manager.get_variables(run_reference)
            if len(variables) == 0:
                #
                # results manager is currently too forgiving so we need to double check
                #
                if csvpaths.results_manager.get_named_results(run_reference) is None:
                    raise ValueError(f"{run_reference} does not point to results")
            return {"success": True, "variables": variables}
        except Exception as e:
            self.app_config.logger.error(str(e))
            return {"success": False, "errors": [str(e)]}

    def get_run_printouts(self, api_key:str, project_name:str, run_reference: str, printstream:str=None) -> dict[str, Any]:
        if run_reference is None:
            raise ValueError("Run reference cannot be None")
        if printstream is None:
            printstream = "default"
        csvpaths = CsvPathsLoader.get_csvpaths(app_config=self.app_config, api_key=api_key, project_name=project_name)
        try:
            printouts = csvpaths.results_manager.get_printouts(run_reference)
            if len(printouts) == 0:
                #
                # results manager is currently too forgiving so we need to double check
                #
                if csvpaths.results_manager.get_named_results(run_reference) is None:
                    raise ValueError(f"{run_reference} does not point to results")
            return {"success": True, "printouts": printouts}
        except Exception as e:
            self.app_config.logger.error(str(e))
            return {"success": False, "errors": [str(e)]}

    def find_results(self, api_key:str, project_name:str, reference: str) -> dict[str, Any]:
        try:
            csvpaths = CsvPathsLoader.get_csvpaths(app_config=self.app_config, api_key=api_key, project_name=project_name)
            results = csvpaths.results_manager.get_named_results(reference)
            if results is None:
                raise ValueError(f"Results returned None for {reference}")
            if len(results) == 0:
                return {"success": False, "message": "No results found"}
            if not isinstance(results, list):
                results = [results]
            lst = []
            for result in results:
                lst.append(result.data_file_path)
            return {"success": True, "results": lst}
        except Exception as e:
            import traceback
            print(traceback.format_exc())
            self.app_config.logger.error(str(e))
            return {"success": False, "errors": [str(e)]}

    def get_result(self, api_key:str, project_name:str, reference: str) -> dict[str, Any]:
        try:
            csvpaths = CsvPathsLoader.get_csvpaths(app_config=self.app_config, api_key=api_key, project_name=project_name)
            results = csvpaths.results_manager.get_named_results(reference)
            if results is None:
                raise ValueError(f"Results returned None for {reference}")
            if len(results) == 0:
                return {"success": False, "message": "No results found"}
            if isinstance(results, list):
                if len(results) > 1:
                    return {"success": False, "message": "Reference must point to 1 csvpath instance from a run"}
                results = results[0]
            path = results.data_file_path
            nos = Nos(path)
            if not nos.exists():
                return {"success": False, "message": "Reference pointed to run results but there is no data"}
            with DataFileReader(path) as file:
                return {"success": True, "result": file.read() }
        except Exception as e:
            import traceback
            print(traceback.format_exc())
            self.app_config.logger.error(str(e))
            return {"success": False, "errors": [str(e)]}

    """
    #
    # we need to be able to pull the metadata manifest.json for the run
    # we need to be able to pull the metadata manifest.json for each instance
    # we need to be able to pull the runtime metadata (csvpaths reference datatype) for each instance
    #
    """



