import os
import json
from datetime import datetime
from uuid import UUID, uuid4
from csvpath import CsvPaths
from flightpath_server.keys.key_manager import KeyManager
from flightpath_server.config.app_config import AppConfig

class CsvPathsLoader:

    @classmethod
    def get_csvpaths(self, *, app_config:AppConfig, api_key:str, project_name:str) -> CsvPaths:
        if app_config is None:
            raise ValueError("App config cannot be None")
        if api_key is None:
            raise ValueError("Api key cannot be None")
        if project_name is None:
            raise ValueError("Project name cannot be None")
        self.key_manager = KeyManager(app_config=app_config)
        key_data = self.key_manager.get_key_data(api_key)
        if key_data is None:
            raise ValueError("Invalid key")
        if project_name not in key_data.config_file_paths:
            raise ValueError("Unknown project name")
        config_path = key_data.config_file_paths[project_name]
        csvpaths = CsvPaths()
        csvpaths.config.set_config_path_and_reload(config_path)
        return csvpaths


