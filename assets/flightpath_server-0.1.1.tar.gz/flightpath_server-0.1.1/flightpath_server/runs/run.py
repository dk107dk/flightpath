from datetime import datetime
from uuid import UUID
from typing import Optional, List
from pydantic import BaseModel, ConfigDict
from csvpath import CsvPaths

class Run(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    run_uuid: str
    start_time: Optional[datetime]
    end_time: Optional[datetime]
    csvpaths: Optional[CsvPaths]
    run_method: str
    pathsname: str
    filename: str
    template: Optional[str]
    api_key: str
    result_reference: Optional[str]
    project_name: str
    config_path: str
    run_summary_path: Optional[str] = None
