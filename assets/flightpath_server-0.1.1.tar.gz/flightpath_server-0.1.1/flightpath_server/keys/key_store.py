import hashlib
import os
import uuid
import json
from abc import ABC, abstractmethod
from typing import Optional
from flightpath_server.config.app_config import AppConfig
from .key import Key

class KeyStore(ABC):

    @abstractmethod
    def is_admin(self, api_key:str) -> bool:
        ...

    @abstractmethod
    def add_key(self, key:Key) -> str:
        ...

    @abstractmethod
    def get_key_data(self, api_key:str) -> Key | None:
        ...

    @abstractmethod
    def delete_key(self, api_key:str) -> bool:
        ...

    @abstractmethod
    def update_key_data(self, api_key:str, key:Key) -> bool:
        ...

    @abstractmethod
    def has_keys(self) -> bool:
        ...

class FileKeyStore(KeyStore):

    def __init__(self, app_config: AppConfig) -> None:
        self._app_config = app_config
        self._keys: dict | None = None
        self._key_file:str = None
        #
        # make sure we have/init a key file
        #
        self.key_file

    @property
    def app_config(self) -> AppConfig:
        return self._app_config

    @property
    def key_file(self) -> str:
        if self._key_file is None:
            #
            # app config will sub an ALL_CAPS name with an env var
            #
            key_file_path = self.app_config.get(section="security", name="key_file_path")
            if key_file_path and key_file_path.strip() == "" or not key_file_path:
                self.app_config.logger.info("No key file in app_config.ini")
                key_file_path = None
            if key_file_path is None and 'FLIGHTPATH_API_KEY_FILE' in os.environ:
                key_file_path = os.environ['FLIGHTPATH_API_KEY_FILE']
            if key_file_path and key_file_path.strip() == "" or not key_file_path:
                self.app_config.logger.info("Key file found in env var is None")
                key_file_path = None
            if key_file_path and key_file_path.strip() == "" or not key_file_path:
                self.app_config.logger.info(f"FlightPath Server: no key file in config and no FLIGHTPATH_API_KEY_FILE env var. Using default: ~/FlightPathServer/config/keys.json")
                key_file_path = os.path.expanduser('~/FlightPathServer/config/keys.json')
            self._key_file = key_file_path
            self.assure_key_file()
        if self._key_file is None:
            raise ValueError("Key file path cannot be None")
        return self._key_file

    def assure_key_file(self) -> None:
        key_file = self._key_file
        if key_file is None or key_file.strip() == "":
            raise ValueError("Key file path cannot be None")
        if not os.path.exists(key_file):
            key_dir = os.path.dirname(key_file)
            if key_dir and not os.path.exists(key_dir):
                os.makedirs(key_dir)
            with open(key_file, "w") as file:
                file.write("{}")

    @key_file.setter
    def key_file(self, file:str) -> None:
        self._key_file = file

    @property
    def keys(self) -> dict:
        if self._keys is None:
            with open(self.key_file, "r") as f:
                self._keys = json.load(f)
        return self._keys

    def is_admin(self, api_key:str) -> bool:
        data = self.get_key_data(api_key)
        if data is None:
            raise ValueError("Key data cannot be None")
        return data.admin

    def has_keys(self) -> bool:
        return len(self.keys) > 0

    def hash_key(self, api_key: str) -> str:
        h = hashlib.sha256(api_key.encode()).hexdigest()
        return h

    def add_key(self, key:Key) -> str:
        api_key = str(uuid.uuid4())
        hashed_key = self.hash_key(api_key)
        self.keys[hashed_key] = key.model_dump()
        with open(self.key_file, "w") as f:
            json.dump(self.keys, f, indent=2)
        return api_key

    def get_key_data(self, api_key:str) -> Key | None:
        if not api_key:
            raise ValueError(f"Api key cannot be None")
        hashed_key = self.hash_key(api_key)
        key_data = self.keys.get(hashed_key)
        return Key(**key_data) if key_data else None

    def delete_key(self, api_key:str) -> bool:
        if not api_key:
            return False
        hashed_key = self.hash_key(api_key)
        if hashed_key in self.keys:
            del self.keys[hashed_key]
            with open(self.key_file, "w") as f:
                json.dump(self.keys, f, indent=2)
            return True
        return False

    def update_key_data(self, api_key:str, key:Key) -> bool:
        if not api_key:
            return False
        hashed_key = self.hash_key(api_key)
        if hashed_key in self.keys:
            self.keys[hashed_key] = key.model_dump()
            with open(self.key_file, "w") as f:
                json.dump(self.keys, f, indent=2)
            return True
        return False



