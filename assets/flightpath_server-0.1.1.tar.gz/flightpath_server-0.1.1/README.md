# FlightPath Server

This project creates an API for FlightPath and other clients to collaborate with.

The goal is to expose end points that can be called by MFT (managed file transfer) servers and workflow tools like Airflow or FlowForce. In particular, the use case is allowing CsvPath Framework to be activated with a simple HTTP request by the MFT server when a new file arrives via SFTP.


## Running Locally

To run the API locally, follow these steps:

1.  **Install dependencies:**
    ```bash
    poetry install
    ```

2.  **Run the Api:**
    ```bash
        FLIGHTPATH_API_KEY_FILE=assets/keys.json poetry run uvicorn flightpath_server.main:app --reload
    ```


    If `FLIGHTPATH_API_KEY_FILE` is not set, it defaults to `keys.json` in the project root.

    The API will be available at `http://127.0.0.1:8000`.

    Your requests must have an 'access_token' header with your API key (a UUID). Your key file will have the key data under the hash of the key.

    Most requests are POST with JSON in the body. E.g. to register a named-file do:
        http://127.0.0.1:8000/csvpath/register_file?
        {
            "config_path_name":"man test proj",
            "name": "test",
            "path":"tests/test_resources/test_projects/man_test_proj/Lottery_Mega_Millions_Winning_Numbers__Beginning_2002.csv"
        }
    where the access_token header is set and the server is started with:
        FLIGHTPATH_API_KEY_FILE=config/keys.json poetry run uvicorn csvpath_api.main:app --reload

    GET the root / to print the key file path

    Use /docs in a browser to see OpenAPI/Swagger

The API configuration is loaded from `config/api_config.ini` at startup.

Project config lives in each project's config/config.ini and config/env.json.

## Running Tests

To run the unit tests, use the following command:

```bash
poetry run pytest
```
