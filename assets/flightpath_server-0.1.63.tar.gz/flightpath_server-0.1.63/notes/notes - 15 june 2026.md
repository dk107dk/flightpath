
1. Version in OpenAPI

Add version=“…” from version("flightpath-server") to server startup metadata so the version is correct in OpenAPI docs at /docs.


2. Run reference available given run caller's UUID

/v2/runs cannot return the run reference because it is asynchronous and CsvPath doesn't reserve the reference before starting the run. (There are timing issues that need to be addressed in the library, but we'll set that aside for now).

We get a UUID on start. We can look up an active run by UUID, but that still doesn't give us the permanent run_dir reference. We have two options, as I see it:

- Create a UUID to reference index that clients can use to look up their runs
- Update CsvPath Framework to allow the caller to pass in metadata that will be captured in the run manifest.json and have a v2 API method for looking up a reference by UUID pass in and persisted in the manifest

The drawbacks of the former are that we need to maintain the index indefinitely. Doable, but a pain.

The drawbacks of the latter are:
- Lookups will be relatively slow because of the need to crawl the archive in some way (e.g. using named-results name + UUID)
- We have to modify CsvPath Framework. (Not a big deal, but work and surface area)
- An arbitrary caller defined metadata JSON added to the manifest.json makes storage in SQL db by the SQL listener harder, or the metadata is just not stored in the db. This is a serious drawback. It can be addressed by creating a new listener that stores the manifest in a fielded inverted tree index. (e.g. Whoosh). Which I want to offer, but it is lot of surface area and I'd prefer to not do it now, supporting this FlightPath release, given priorities.

A way to address all these drawbacks of the caller passing in metadata, might be to simply keep that metadata in a separate file with a known name. We could also mandate that the metadata passed in be a dict[str,str] to allow us to drop it in the run manifest.json easily, and then just have the SQL listener not store it -- a clumsy but quick fix.

Fwiw, allowing the caller to pass arbitrary metadata into a run has been a nice-to-have feature in the backlog, so it scratches an itch, as well as helping solve for this async run identification issue.

Thoughts?



