
# Encourage consistency in checking "on", "yes", "true" in bool config settings

Create or use a utility class to check for booleans in config. E.g. move code like:

    if setting in ["on", "yes"]:

to something like:

    buul.yes(setting)

Where buul.yes(setting) is an alias for something like:

    BoolUtility.yes(cls, setting:str|int) -> bool:
        ...

After lowercasing, the utility method should treat the following as true: "on", "yes", "true"


# Make v1 and v2 more consistent

The API v2 is separated from the v1 code in a flightpath_server/v2 module. Move v1 into a flightpath_server v1 module. Make the two versions as structurally the same as practical.


# Defensive against missing server-level config values

In main.py, we are careful to check ssl_keyfile, ssl_certificate, etc. for None. We should do the same for all necessary server config values. E.g. workers, port, etc.

When a config value is not found we should log that with a clear message so the user knows of the missed opportunity and can correct it. And if the missing value were to be critical to correct operations, we should shut down, rather than raise an exception. The critical main.py values currently have sensible defaults or aren't critical, so missing them wouldn't require a shutdown, but if that changes, shutting down would be the approach.


# FrameworkManager __init__ order of operations

This is little stuff, but would it make sense to change the order at the top so that:

        self._app_config = app_config
        self.key_manager = KeyManager(app_config=app_config)
        self.key_data = self.key_manager.get_key_data(api_key)
        if not self.key_data:
            raise ValueError(f"Invalid API Key {api_key}")
        self.api_key: str = api_key

And only then continue with:

        self.run_manager = RunManager(app_config=app_config)
        self.results_manager = ResultsManager(app_config=app_config)

Secondarily, do we necessarily need run_manager and results_manager? Not all operations will use them. Can we defer until we know we need them? I understand it's not a big performance win or anything, so just asking.


# Project manager: set config key

ProjectManager says:
    #
    # untested! do not use yet.
    #
    def set_config_key(
        self, *, api_key: str, project_name: str, section: str, name: str, value: str
    ) -> None:

Our API endpoint uses
    def set_project_config_field(self, *, api_key: str, project_name: str, section: str, field: str, value: str) -> None:

This seems duplicative. If you agree please delete the old untested/unused method.


# Use ReferenceParser

In RegisterFileRequest we have:

    def _name_from_reference(reference: str) -> str:
        ... string parsing here ...

In CsvPath Framework we use ReferenceParser from csvpath.util.references.reference_parser.

Using ReferenceParser to do the same would be like:

    def _name_from_reference(reference: str) -> str:
        ref = ReferenceParser(name) # csvpaths arg probably not required, but we have one if needed
        return ref.root_major

ReferenceParser is a much heavier-weight approach, but it would be most "standard" and we would (be forced to) change in sync with CsvPath Framework. References need a v3 rebuild because their functionality is imperfect and the design of what a reference is (as a DSL) is not ideal. So they are not a stable area and I think that makes it more important to stick with the framework's version. But I could be wrong. What do you think is best here?


# Consolidate models

validations.py has RegisterValidationRequest. Shouldn't that class go into models.py? If so, please move it, and also double check if there are any other pydantic models that should live together with the others.


# Printouts

ResultsManager gives access to printouts.txt with this method:

    def get_run_printouts(
        self,
        api_key: str,
        project_name: str,
        run_reference: str,
        printstream: str = None,
    ) -> dict[str, Any]:

The printstreams will all be in the same file by default. However, a csvpath statement may declare `print-mode:separate` to have the framework separate the printstreams into their own files, each named for the printstream plus `.txt`.

We need to use that `printstream` argument as an indicator that we should look for a printouts file with that name. E.g., if my csvpath statement does:

   print("I'm on line $.csvpath.line_number", "report")

we would accept a `printstream="report"` or `printstream="report.txt"` to mean return a file with that name. Otherwise, return "printouts.txt".

For this endpoint to work well, we need a fully qualified reference to an instance (a csvpath with an identity, either a name or an index). Without that we would have to concatenate printouts.txt files. I think we should insist on the fully qualified name. A fully qualified name looks like:

    $myresultsname.results.file/path/to.myinstancename

Where:
- `myresultsname` is the named-results name (identical to the named-paths name)
- `.results.` is the data type
- `path/to/results` is the run_dir, optionally prefixed with a path defined by a template
- `myinstancename` is the identity of the csvpath statement that generated the printout


# All results files may be non-local

The following endpoints are implemented as if they were always going to be local files. This is definitely not correct. Results can be stored in any backend -- i.e. local, sftp, s3, google cloud storage, azure blobs.

@archive_router.get("/{name}/{run_dir}/{csvpath_id}/errors")
@archive_router.get("/{name}/{run_dir}/{csvpath_id}/meta")
@archive_router.get("/{name}/{run_dir}/{csvpath_id}/variables")
@archive_router.get("/{name}/{run_dir}/{csvpath_id}/data")
@archive_router.get("/{name}/{run_dir}/{csvpath_id}/unmatched")
@archive_router.get("/{name}/{run_dir}/{csvpath_id}/printouts")

Fixing this is easy. We need to use DataFileReader and construct the paths using Nos. Both classes are in the CsvPath Framework's util module. DataFileReader is a context manager that acts as a factory for backend implementations. Nos give you the correct path separator with Nos(path).sep[0].

As noted above, we need to adjust printouts to account for printout files optionally having the name of their printstreams, rather than printouts.txt.

We also need a generic result file getting endpoint that can get any file in the run_dir. This will account for Parquet files generated by the run, along with any other future file-type capabilities.





