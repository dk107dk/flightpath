
find . -name "*.pyc" -exec rm -f {} \;
find . -name "__pycache__" -exec rm -Rf {} \;

rm -Rf ./archive
rm -Rf ./cache
rm -Rf ./config/config.ini
rm -Rf ./inputs
rm -Rf ./logs
rm -Rf ./transfers


rm -Rf ./tests/test_resources/dummy_project/transfers
rm -Rf ./tests/test_resources/dummy_project/inputs
rm -Rf ./tests/test_resources/dummy_project/archive

rm -Rf ./history
rm -Rf ./projects_root

