from datetime import datetime
from enum import Enum
from typing import Any, Optional
from pydantic import BaseModel


# ---------------------------------------------------------------------------
# Request models
# ---------------------------------------------------------------------------

class NewKeyRequest(BaseModel):
    key_name: str
    key_owner_name: str
    key_owner_contact: str


class MakeAdminRequest(BaseModel):
    api_key: str


class NewProjectRequest(BaseModel):
    name: str
    config_str: Optional[str] = None


class DeleteProjectRequest(BaseModel):
    name: str


class SetProjectConfigRequest(BaseModel):
    name: str
    config_str: str


class GetProjectConfigRequest(BaseModel):
    name: str


class SetEnvFileRequest(BaseModel):
    name: str
    env_str: str


class GetEnvFileRequest(BaseModel):
    name: str


class SetEnvKeyRequest(BaseModel):
    name: str
    key: str
    value: str


class AddFileRequest(BaseModel):
    name: str
    file_path: str
    file_content: str


class GetFileRequest(BaseModel):
    name: str
    file_path: str


class Method(str, Enum):
    fast_forward_paths = "fast_forward_paths"
    collect_paths = "collect_paths"
    fast_forward_by_line = "fast_forward_by_line"
    collect_by_line = "collect_by_line"


class RegisterFileRequest(BaseModel):
    project_name: str
    name: str
    file_location: str
    template: Optional[str] = None


class RegisterCsvpathsRequest(BaseModel):
    project_name: str
    name: str
    file_location: str
    append: Optional[bool] = False
    template: Optional[str] = None


class RunRequest(BaseModel):
    project_name: str
    file_name: str
    path_name: str
    method: Optional[Method] = Method.collect_paths
    template: Optional[str] = None


class RegisterAndRunRequest(BaseModel):
    project_name: str
    file_location: str
    file_name: str
    csvpaths_group_name: str
    method: Optional[Method] = Method.collect_paths
    file_template: Optional[str] = None
    run_template: Optional[str] = None


class RunReferenceRequest(BaseModel):
    project_name: str
    run_reference: str


class RunReferencePrintRequest(BaseModel):
    project_name: str
    run_reference: str
    printstream: Optional[str] = None


class RunPathRequest(BaseModel):
    project_name: str
    run_reference: str


class FindRequest(BaseModel):
    project_name: str
    reference: str


class GetResultRequest(BaseModel):
    project_name: str
    reference: str


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------

class NewKeyResponse(BaseModel):
    api_key: str


class SuccessResponse(BaseModel):
    message: str


class RunInfo(BaseModel):
    run_uuid: str
    start_time: Optional[datetime]
    end_time: Optional[datetime]
    run_method: str
    pathsname: str
    filename: str
    template: Optional[str]
    api_key: str
    result_reference: Optional[str]
    project_name: str
    config_path: str
    run_summary_path: Optional[str] = None


class ActiveRunsResponse(BaseModel):
    runs: list[RunInfo]


class ReferenceResponse(BaseModel):
    reference: str


class ReferencesResponse(BaseModel):
    message: str
    run_reference: str
    register_reference: str


class PathResponse(BaseModel):
    path: str


class ErrorsResponse(BaseModel):
    errors: list[dict]


class MetadataResponse(BaseModel):
    metadata: dict[str, Any]


class VariablesResponse(BaseModel):
    variables: dict[str, Any]


class PrintoutsResponse(BaseModel):
    printouts: list[str]


class FileResponse(BaseModel):
    file_content: str


class ProjectNamesResponse(BaseModel):
    names: list[str]


class FindFilesResponse(BaseModel):
    files: list[str]


class FindFileResponse(BaseModel):
    file: str


class FindResultsResponse(BaseModel):
    results: list[str]


class FindRunsResponse(BaseModel):
    runs: list[str]


class FindResultResponse(BaseModel):
    result: str
