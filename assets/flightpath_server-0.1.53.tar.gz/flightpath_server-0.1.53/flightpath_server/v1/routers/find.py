import base64

from fastapi import APIRouter, Depends

from flightpath_server.routers.framework_context import fm_context as _fm
from flightpath_server.dependencies import get_api_key, get_app_config
from flightpath_server.config.app_config import AppConfig
from flightpath_server.v1.models import (
    FindFileResponse,
    FindFilesResponse,
    FindRequest,
    FindResultResponse,
    FindResultsResponse,
    FindRunsResponse,
    GetResultRequest,
)

find_router = APIRouter()


@find_router.api_route("/find_files", methods=["GET", "POST"])
def find_files(
    request: FindRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> FindFilesResponse:
    """Finds the paths of registered named-files based on a reference. References pick out files within the named-file based on arrival time, ordinal position, hash fingerprint, and/or file path."""
    with _fm(api_key, request.project_name, app_config) as fm:
        ret = fm.find_registered_files(reference=request.reference)
        if ret.get("success") is True:
            return {"files": ret.get("files")}
        raise RuntimeError(",".join(ret.get("errors") or [ret.get("message")] or ["Unknown server error"]))


@find_router.api_route("/get_file", methods=["GET", "POST"])
def get_file(
    request: FindRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> FindFileResponse:
    """Returns the base64 encoded content of a file found by a named-file reference."""
    with _fm(api_key, request.project_name, app_config) as fm:
        ret = fm.get_registered_file(reference=request.reference)
        if ret.get("success") is True:
            file = ret.get("file")
            if not isinstance(file, bytes):
                file = file.encode("utf-8")
            return {"file": base64.b64encode(file).decode("utf-8")}
        raise RuntimeError(",".join(ret.get("errors") or [ret.get("message")] or ["Unknown server error"]))


@find_router.api_route("/find_completed_runs", methods=["GET", "POST"])
def find_completed_runs(
    request: FindRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> FindRunsResponse:
    """Returns paths to all the runs matching a reference. Each run found will have its own set of csvpath statement results."""
    with _fm(api_key, request.project_name, app_config) as fm:
        result = fm.find_completed_runs(request.reference)
        if result.get("success"):
            return {"runs": result.get("runs")}
        raise RuntimeError(result.get("errors"))


@find_router.api_route("/find_results", methods=["GET", "POST"])
def find_results(
    request: FindRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> FindResultsResponse:
    """Returns a single set of results found within the archive under a specific named-results name. Each
    result in the set represents the output of one csvpath within the named-paths group.
    (Named-results are named the same as the named-paths group that generated them.)
    Runs are identified by run date, ordinal position, and/or partial or exact file system path.
    Each result is a path to the data.csv output of a csvpath in the group from that run. In this case you
    cannot use a reference that points specifically to the data.csv or unmatched.csv files generated during
    a run. If your reference points to more than one run the first run found is the one results are returned for."""
    with _fm(api_key, request.project_name, app_config) as fm:
        ret = fm.find_results(reference=request.reference)
        if ret.get("success") is True:
            return {"results": ret.get("results")}
        raise RuntimeError(",".join(ret.get("errors") or [ret.get("message")] or ["Unknown server error"]))


@find_router.api_route("/get_result", methods=["GET", "POST"])
def get_result(
    request: GetResultRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> FindResultResponse:
    """Returns the content of a run data file result based on a reference to the run. The content returned is the set of matching lines from the run. (Or, if so configured, the unmatched lines)."""
    with _fm(api_key, request.project_name, app_config) as fm:
        ret = fm.get_result(reference=request.reference)
        if ret.get("success") is True:
            return {"result": ret.get("result")}
        raise RuntimeError(",".join(ret.get("errors") or [ret.get("message")] or ["Unknown server error"]))
