from fastapi import APIRouter, Depends

from flightpath_server.routers.framework_context import fm_context as _fm
from flightpath_server.dependencies import get_api_key, get_app_config
from flightpath_server.config.app_config import AppConfig
from flightpath_server.v1.models import (
    ErrorsResponse,
    MetadataResponse,
    PathResponse,
    PrintoutsResponse,
    ReferenceResponse,
    ReferencesResponse,
    RegisterAndRunRequest,
    RegisterCsvpathsRequest,
    RegisterFileRequest,
    RunPathRequest,
    RunReferenceRequest,
    RunReferencePrintRequest,
    RunRequest,
    VariablesResponse,
)

csvpath_router = APIRouter()


@csvpath_router.post("/register_file")
def register_file(
    request: RegisterFileRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> ReferenceResponse:
    """Registers a new version of a named file. In CsvPath Framework terms, this is CsvPaths.FileManager.add_named_file()."""
    with _fm(api_key, request.project_name, app_config) as fm:
        ret = fm.register_file(
            named_file_name=request.name,
            file_location=request.file_location,
            template=request.template,
        )
        if ret.get("success") is True:
            return {"reference": ret.get("reference")}
        raise RuntimeError(",".join(ret.get("errors") or ["Unknown server error"]))


@csvpath_router.post("/register_csvpath_group")
def register_csvpath_group(
    request: RegisterCsvpathsRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> ReferenceResponse:
    """Registers a named-paths group, creating a new version if the named-paths group already exists. In CsvPath Framework terms, this is CsvPaths.PathsManager.add_named_paths()."""
    with _fm(api_key, request.project_name, app_config) as fm:
        ret = fm.register_csvpath_group(
            named_paths_name=request.name,
            file_location=request.file_location,
            template=request.template,
            append=request.append,
        )
        if ret.get("success") is True:
            return {"reference": ret.get("reference")}
        raise RuntimeError(",".join(ret.get("errors") or ["Unknown server error"]))


@csvpath_router.post("/run")
def run(
    request: RunRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> ReferenceResponse:
    """Runs a named-file through a named-paths group. In CsvPath Framework terms, this is one of the following:
    <ul>
        <li> CsvPaths.collect_paths()
        <li> CsvPaths.fast_forward_paths()
        <li> CsvPaths.collect_by_line()
        <li> CsvPaths.fast_forward_by_line()
    </ul>
    """
    with _fm(api_key, request.project_name, app_config) as fm:
        ret = fm.run(
            named_file_name=request.file_name,
            named_paths_name=request.path_name,
            method=request.method,
            override_template=request.template,
        )
        if ret and ret.get("success") is True:
            return {"reference": ret.get("reference")}
        raise RuntimeError(",".join(ret.get("errors") or ["Unknown server error"]))


@csvpath_router.post("/register_and_run", tags=["register", "run"])
def register_and_run(
    request: RegisterAndRunRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> ReferencesResponse:
    """Registers a new version of a named-file and then runs it through a named-paths group. This endpoint can be used by MFT servers or other file arrival-watching tools to both collect a file and start a run in one action."""
    with _fm(api_key, request.project_name, app_config) as fm:
        register_result = fm.register_file(
            named_file_name=request.file_name,
            file_location=request.file_location,
            template=request.file_template,
        )
        if not register_result or not register_result.get("success"):
            raise RuntimeError(",".join(register_result.get("errors") or ["Register failed"]))
        #
        # this needs to take the result of the register -- an absolute named-file reference --
        # to use as the file name. sadly, CsvPath doesn't provide that yet. until the next
        # release we can only do :last, which is implied by just using the simple name. :/
        #
        run_result = fm.run(
            named_file_name=request.file_name,
            named_paths_name=request.csvpaths_group_name,
            method=request.method,
            override_template=request.run_template,
        )
        if not run_result or not run_result.get("success"):
            raise RuntimeError(",".join(run_result.get("errors") or ["Run failed"]))
        return {
            "message": "File registered and run initiated successfully",
            "run_reference": run_result.get("reference"),
            "register_reference": register_result.get("reference"),
        }


@csvpath_router.api_route("/get_run_path", methods=["GET", "POST"])
def get_run_path(
    request: RunPathRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> PathResponse:
    """Returns the path to a run's `run_dir`. `run_dir` is the name of the directory where a runs results live. It is a date-stamp name below the named-paths name in the form YYYY-MM_DD_HH-MM-SS."""
    with _fm(api_key, request.project_name, app_config) as fm:
        result = fm.get_run_path(request.run_reference)
        if result and result.get("success"):
            return {"path": result.get("path")}
        raise RuntimeError(result.get("errors"))


@csvpath_router.api_route("/get_run_errors", methods=["GET", "POST"])
def get_run_errors(
    request: RunReferenceRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> ErrorsResponse:
    """Returns the contents of all the errors.json files generated during a run. Each csvpath in a named-paths group has its own errors.json file, if errors happened during the run. This endpoint aggregates them."""
    with _fm(api_key, request.project_name, app_config) as fm:
        result = fm.get_run_errors(request.run_reference)
        if result and result.get("success"):
            return {"errors": result.get("errors")}
        raise RuntimeError(result.get("errors"))


@csvpath_router.api_route("/get_run_metadata", methods=["GET", "POST"])
def get_run_metadata(
    request: RunReferenceRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> MetadataResponse:
    """Returns the metadata fields and runtime data generated during the run. Metadata fields are settings and user-defined content embedded in comments of a csvpath. Runtime data tracks validity, lines matched, headers, and other metadata that is generated as the run happens. This endpoint aggregates the metadata of all csvpaths within the named-paths group that was run."""
    with _fm(api_key, request.project_name, app_config) as fm:
        result = fm.get_run_metadata(request.run_reference)
        if result and result.get("success"):
            return {"metadata": result.get("metadata")}
        raise RuntimeError(result.get("errors"))


@csvpath_router.api_route("/get_run_variables", methods=["GET", "POST"])
def get_run_variables(
    request: RunReferenceRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> VariablesResponse:
    """Returns the run variables. Run variables are user-defined values set within csvpaths, line-by-line. This endpoint aggregates the variables.json files of each of the csvpaths in the named-paths group that was run."""
    with _fm(api_key, request.project_name, app_config) as fm:
        result = fm.get_run_variables(request.run_reference)
        if result and result.get("success"):
            return {"variables": result.get("variables")}
        raise RuntimeError(result.get("errors"))


@csvpath_router.api_route("/get_run_printouts", methods=["GET", "POST"])
def get_run_printouts(
    request: RunReferencePrintRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> PrintoutsResponse:
    """Returns the printouts of a printstream, aggregated from all the csvpaths in the named-paths group that was run."""
    with _fm(api_key, request.project_name, app_config) as fm:
        result = fm.get_run_printouts(
            run_reference=request.run_reference, printstream=request.printstream
        )
        if result and result.get("success"):
            return {"printouts": result.get("printouts")}
        raise RuntimeError(result.get("errors"))
