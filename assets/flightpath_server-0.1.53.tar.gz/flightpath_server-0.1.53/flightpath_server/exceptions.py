class NotFoundError(ValueError):
    """Raised when a requested resource does not exist."""
