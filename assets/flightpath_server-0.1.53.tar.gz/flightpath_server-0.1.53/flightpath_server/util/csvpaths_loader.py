from csvpath import CsvPaths

from flightpath_server.keys.key_manager import KeyManager
from flightpath_server.config.app_config import AppConfig


class CsvPathsLoader:
    @classmethod
    def get_csvpaths(
        cls, *, app_config: AppConfig, api_key: str, project_name: str
    ) -> CsvPaths:
        if app_config is None:
            raise ValueError("App config cannot be None")
        if api_key is None:
            raise ValueError("Api key cannot be None")
        if project_name is None:
            raise ValueError("Project name cannot be None")
        key_manager = KeyManager(app_config=app_config)
        key_data = key_manager.get_key_data(api_key)
        if key_data is None:
            raise ValueError("Invalid key")
        if project_name not in key_data.config_file_paths:
            raise ValueError("Unknown project name")
        config_path = key_data.config_file_paths[project_name]
        csvpaths = CsvPaths(
            project=project_name,
            project_context=key_manager.hash_key(api_key),
        )
        #
        # this will reset the logger to the right log level for this project.
        # not that it is this class's problem, but the csvpaths init should handle
        # this fine, esp. when project name and ctx are passed in but since in that case
        # resetting the logger is just a dict check its better to be sure
        #
        csvpaths.set_config_path_and_reload(config_path)
        csvpaths.logger.info(
            f"CsvPathsLoader: log path: {csvpaths.config.get(section='logging', name='log_file')}"
        )
        app_config.logger.info(csvpaths.info_dump_string)
        if app_config.verbose():
            print(csvpaths.info_dump_string)
        return csvpaths
