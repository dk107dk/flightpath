class BoolUtility:
    @classmethod
    def yes(cls, setting: str | int | None) -> bool:
        if setting is None:
            return False
        if isinstance(setting, int):
            return setting == 1
        return str(setting).strip().lower() in ("on", "yes", "true")
