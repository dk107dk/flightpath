from contextlib import contextmanager
from fastapi import HTTPException
from flightpath_server.framework_manager import FrameworkManager
from flightpath_server.config.app_config import AppConfig


@contextmanager
def fm_context(api_key: str, project_name: str, app_config: AppConfig):
    fm = None
    try:
        fm = FrameworkManager(api_key=api_key, project_name=project_name, app_config=app_config)
        yield fm
    except HTTPException:
        raise
    except ValueError as e:
        app_config.dump_info_if(
            project_name=project_name,
            csvpaths=fm.csvpaths if fm else None,
            api_key=api_key,
        )
        raise app_config.http_error(name=__name__, code=403, msg=str(e))
    except Exception as e:
        app_config.dump_info_if(
            project_name=project_name,
            csvpaths=fm.csvpaths if fm else None,
            api_key=api_key,
        )
        raise app_config.http_error(name=__name__, code=500, msg=str(e))
