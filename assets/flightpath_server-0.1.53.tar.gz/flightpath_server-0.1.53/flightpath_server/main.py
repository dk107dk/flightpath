import os
import uvicorn
from datetime import datetime
from fastapi import FastAPI
from importlib.metadata import version, PackageNotFoundError
import traceback
from flightpath_server.v1.routers.projects import project_router
from flightpath_server.v1.routers.csvpath import csvpath_router
from flightpath_server.v1.routers.admin import admin_router
from flightpath_server.v1.routers.find import find_router
from flightpath_server.v2.routers.projects import projects_router as v2_projects_router
from flightpath_server.v2.routers.registrations import registrations_router as v2_registrations_router
from flightpath_server.v2.routers.validations import validations_router as v2_validations_router
from flightpath_server.v2.routers.runs import runs_router as v2_runs_router
from flightpath_server.v2.routers.archive import archive_router as v2_archive_router
from flightpath_server.v2.routers.admin import admin_router as v2_admin_router
from flightpath_server.config.app_config import AppConfig
from flightpath_server.lifespan import lifespan
from flightpath_server.util.bool_utility import BoolUtility as bout


try:
    _server_version = version("flightpath-server")
except PackageNotFoundError:
    _server_version = "unknown"


def _parse_enabled_versions(raw) -> set:
    if isinstance(raw, list):
        return {v.strip() for v in raw if v.strip()}
    if isinstance(raw, str) and raw.strip():
        return {v.strip() for v in raw.split(",") if v.strip()}
    return {"v1", "v2"}


try:
    _early_config = AppConfig.me()
    _enabled = _parse_enabled_versions(
        _early_config.get(section="api", name="enabled_versions", default=["v1", "v2"])
    )
    _deprecated_docs = bout.yes(_early_config.get(section="api", name="deprecated_docs", default="no"))
except Exception:
    _enabled = {"v1", "v2"}
    _deprecated_docs = False


app = FastAPI(
    title="FlightPath Server",
    description="The automation backend for <a href='https://www.flightpathdata.com'>FlightPath Data</a> ingestion projects built on <a href='https://www.csvpath.org'>CsvPath Framework</a>.",
    contact={
        "Support": "FlightPath Support",
        "url": "https://www.csvpath.org/getting-started/a-helping-hand",
        "email": "info@csvpath.org",
    },
    lifespan=lambda app: lifespan(app, config_path=None),
)

if "v1" in _enabled:
    _v1_tag = ["v1 (deprecated)"]
    app.include_router(project_router, prefix="/projects", tags=_v1_tag, include_in_schema=_deprecated_docs)
    app.include_router(csvpath_router, prefix="/csvpath", tags=_v1_tag, include_in_schema=_deprecated_docs)
    app.include_router(admin_router, prefix="/admin", tags=_v1_tag, include_in_schema=_deprecated_docs)
    app.include_router(find_router, prefix="/find", tags=_v1_tag, include_in_schema=_deprecated_docs)

if "v2" in _enabled:
    app.include_router(v2_projects_router, prefix="/v2/projects", tags=["v2:projects"])
    app.include_router(v2_registrations_router, prefix="/v2/registrations", tags=["v2:registrations"])
    app.include_router(v2_validations_router, prefix="/v2/validations", tags=["v2:validations"])
    app.include_router(v2_runs_router, prefix="/v2/runs", tags=["v2:runs"])
    app.include_router(v2_archive_router, prefix="/v2/archive", tags=["v2:archive"])
    app.include_router(v2_admin_router, prefix="/v2/admin", tags=["v2:admin"])

LIVE_SINCE = datetime.now()


@app.get("/")
async def root() -> dict:
    kp = app.state.app_config.get(
        section="security", name="key_file_path", default="default"
    )
    kp = "default location" if (kp is None or kp.strip() == "") else kp
    return {
        "message": {
            "name": "FlightPath Server",
            "version": _server_version,
            "started": LIVE_SINCE,
            "cwd": os.getcwd(),
            "config": app.state.app_config.configpath,
            "keyfile": kp,
            "api_versions": sorted(_enabled),
        }
    }


class Main:
    def serve(self):
        try:
            app_config = AppConfig.me()
            logger = app_config.logger

            port = app_config.get(section="server", name="port")
            if port is None:
                logger.info("Config: server.port not set, defaulting to 8000")
                port = 8000

            host = app_config.get(section="server", name="host")
            if host is None:
                logger.info("Config: server.host not set, defaulting to localhost")
                host = "localhost"

            workers = app_config.get(section="server", name="workers")
            if workers is None:
                logger.info("Config: server.workers not set, defaulting to 1")
                workers = 1

            workers = int(workers) if workers else 1
            args = {}
            args["host"] = host
            args["port"] = int(port)
            args["workers"] = workers

            ssl_keyfile = app_config.get(section="security", name="ssl_keyfile")
            if ssl_keyfile and str(ssl_keyfile).strip() != "":
                args["ssl_keyfile"] = ssl_keyfile

            ssl_certfile = app_config.get(section="security", name="ssl_certfile")
            if ssl_certfile and str(ssl_certfile).strip() != "":
                args["ssl_certfile"] = ssl_certfile

            ssl_keyfile_password = app_config.get(
                section="security", name="ssl_keyfile_password"
            )
            if ssl_keyfile_password and str(ssl_keyfile_password).strip() != "":
                args["ssl_keyfile_password"] = ssl_keyfile_password

            ssl_version = app_config.get(section="security", name="ssl_version")
            if ssl_version and not str(ssl_version).strip() == "":
                args["ssl_version"] = int(ssl_version)

            print(f"Config file: {app_config.configpath}")
            print(f"Active API versions: {sorted(_enabled)}")
            print(f"FlightPath Server: args: {args}")
            uvicorn.run("flightpath_server.main:app", **args)
        except Exception:
            print(traceback.format_exc())


def run():
    main = Main()
    main.serve()


if __name__ == "__main__":
    run()
