import os
import json
from datetime import datetime, timezone
from uuid import uuid4
from typing import Optional, Any


from csvpath import CsvPaths
from flightpath_server.keys.key_manager import KeyManager
from flightpath_server.config.app_config import AppConfig
from .run import Run


class RunManager:
    HISTORY_DIR = "history"

    def __init__(self, app_config: AppConfig, history_dir: str = None) -> None:
        self.app_config = app_config
        self.history_dir = history_dir if history_dir is not None else RunManager.HISTORY_DIR
        os.makedirs(self.history_dir, exist_ok=True)
        self.key_manager = KeyManager(app_config=app_config)

    @property
    def today(self) -> None:
        today = datetime.now(timezone.utc)
        return today.strftime("%Y-%m-%d")

    def path_for_run(self, run: Run) -> str:
        today = self.today
        path = os.path.join(self.history_dir, today)
        os.makedirs(path, exist_ok=True)
        path = os.path.join(path, f"{run.run_uuid}.json")
        run.run_summary_path = path
        self.app_config.logger.debug(f"Path for run {run.run_uuid} is {path}")
        return path

    #
    # this will create dup files if a day ends before a run ends. atm, that's
    # not a problem, because this isn't a long-term solution to logging runs.
    #
    def update_runs_in_progress(self, run: Run) -> None:
        path = self.path_for_run(run)
        csvpaths = run.csvpaths
        run.csvpaths = None
        with open(path, "w") as file:
            json.dump(run.model_dump(mode="json"), file, indent=2)
        run.csvpaths = csvpaths
        self.app_config.logger.info(f"Updated run {run.run_uuid} on disk")

    def find_run(self, run_uuid: str) -> Optional["Run"]:
        """Finds a run by UUID across all history, active or completed."""
        if not os.path.exists(self.history_dir):
            return None
        for date_dir in os.listdir(self.history_dir):
            date_path = os.path.join(self.history_dir, date_dir)
            if not os.path.isdir(date_path):
                continue
            for fname in os.listdir(date_path):
                if not fname.endswith(".json"):
                    continue
                fpath = os.path.join(date_path, fname)
                try:
                    with open(fpath, "r") as f:
                        data = json.load(f)
                    if data.get("run_uuid") == run_uuid:
                        return Run(**data)
                except Exception:
                    pass
        return None

    def new_run(
        self,
        *,
        csvpaths: CsvPaths,
        run_method: str,
        pathsname: str,
        filename: str,
        template: str,
        api_key: str,  # this is the actual key uuid. we hash it below.
        project_name: str,
        run_uuid: Optional[str] = None,
    ) -> Run:
        new_uuid = uuid4() if run_uuid is None else run_uuid
        new_run = Run(
            run_uuid=str(new_uuid),
            end_time=None,
            start_time=None,
            csvpaths=csvpaths,
            run_method=run_method,
            pathsname=pathsname,
            filename=filename,
            template=template,
            api_key=self.key_manager.hash_key(api_key),
            result_reference=None,
            project_name=project_name,
            config_path=csvpaths.config.config_path,
        )
        self.update_runs_in_progress(new_run)
        self.app_config.logger.debug(
            f"Created run {new_run.run_uuid}: {run_method}, paths: {pathsname}, file: {filename}, key: {api_key}"
        )
        return new_run

    def do_run(self, run: Run) -> dict[str, Any]:
        if run is None:
            raise ValueError("Run cannot be None")
        self.app_config.logger.info("Starting run", extra={"run": run})
        try:
            method = None
            if run.run_method == "fast_forward_paths":
                method = run.csvpaths.fast_forward_paths
            elif run.run_method == "collect_paths":
                method = run.csvpaths.collect_paths
            elif run.run_method == "collect_by_line":
                method = run.csvpaths.collect_by_line
            elif run.run_method == "fast_forward_by_line":
                method = run.csvpaths.fast_forward_by_line
            else:
                raise ValueError(f"Run method {run.run_method} is not available")
            #
            # overwrite the run .json here to capture the start and any changes
            #
            run.start_time = datetime.now(timezone.utc)
            self.update_runs_in_progress(run)
            ref = method(
                pathsname=run.pathsname, filename=run.filename, template=run.template
            )
            self.app_config.logger.debug(
                f"Run {run.run_uuid} completed: {run.run_method}, paths: {run.pathsname}, file: {run.filename}, key: {run.api_key}"
            )
            run.result_reference = ref
            run.end_time = datetime.now(timezone.utc)
            ret = {"success": True, "reference": ref}
            self.update_runs_in_progress(run)
            return ret
        except Exception as e:
            run.end_time = datetime.now(timezone.utc)
            self.app_config.logger.exception("Error in run %s: %s", run.run_uuid, e)
            self.update_runs_in_progress(run)
            return {"success": False, "errors": [str(e)]}

    def _scan_active_runs(self) -> list[Run]:
        active = []
        if not os.path.exists(self.history_dir):
            return active
        for date_dir in os.listdir(self.history_dir):
            date_path = os.path.join(self.history_dir, date_dir)
            if not os.path.isdir(date_path):
                continue
            for fname in os.listdir(date_path):
                if not fname.endswith(".json"):
                    continue
                fpath = os.path.join(date_path, fname)
                try:
                    with open(fpath, "r") as f:
                        data = json.load(f)
                    if data.get("end_time") is None:
                        active.append(Run(**data))
                except Exception:
                    pass
        return active

    def get_active_runs(
        self,
        *,
        api_key: Optional[str] = None,
        run_uuid_str: Optional[str] = None,
        pathsname: Optional[str] = None,
        filename: Optional[str] = None,
    ) -> list[Run]:
        runs = self._scan_active_runs()
        if run_uuid_str is not None:
            runs = [r for r in runs if r.run_uuid == run_uuid_str]
            if runs:
                return [runs[0]]
            return []
        if api_key is not None:
            api_key = self.key_manager.hash_key(api_key)
            runs = [r for r in runs if r.api_key == api_key]
        if pathsname is not None:
            runs = [r for r in runs if r.pathsname == pathsname]
        if filename is not None:
            runs = [r for r in runs if r.filename == filename]
        return runs
