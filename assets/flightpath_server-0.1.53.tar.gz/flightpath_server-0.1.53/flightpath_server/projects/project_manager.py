import os
import io
import shutil
import json
import traceback
from configparser import ConfigParser
from filelock import FileLock
from csvpath.util.nos import Nos
from csvpath.util.config import Config
from csvpath.util.file_writers import DataFileWriter

from flightpath_server.keys.key_manager import KeyManager
from flightpath_server.config.app_config import AppConfig
from flightpath_server.exceptions import NotFoundError
from flightpath_server.util.bool_utility import BoolUtility as bout
from flightpath_server.util.config_updater import ConfigUpdater

# Fields controlled by _modify_config — projects may not set these via the API.
_SERVER_MANAGED_FIELDS: frozenset[tuple[str, str]] = frozenset({
    ("config", "path"),
    ("config", "allow_var_sub"),
    ("config", "var_sub_source"),
    ("inputs", "allow_http_files"),
    ("inputs", "allow_local_files"),
    ("logging", "log_file"),
    ("cache", "use_cache"),
    ("cache", "path"),
    ("scripts", "run_scripts"),
    ("functions", "imports"),
    ("sqlite", "db"),
})


class ProjectManager:
    @staticmethod
    def config_from_str(config_str: str) -> ConfigParser:
        config = ConfigParser()
        config.read_string(config_str)
        return config

    @staticmethod
    def config_to_str(config: ConfigParser) -> str:
        string_buffer = io.StringIO()
        config.write(string_buffer)
        config_str = string_buffer.getvalue()
        return config_str

    def __init__(
        self, *, app_config: AppConfig, key_manager: KeyManager = None
    ) -> None:
        if app_config is None:
            raise ValueError("App config cannot be None")
        self.app_config: AppConfig = app_config
        if key_manager is None:
            key_manager = KeyManager(app_config=app_config)
        self.key_manager = key_manager

    @property
    def projects_dir(self) -> str:
        return os.path.expanduser("~/FlightPathServer/projects")

    def get_project_home(
        self, *, project_name, api_key, must_exist: bool = True
    ) -> str:
        projects_dir = self.projects_dir
        key = self.key_manager.get_key_data(api_key)
        if not key:
            raise ValueError("Invalid API Key")
        hash_key = self.key_manager.hash_key(api_key)
        path = os.path.join(projects_dir, hash_key, project_name)
        if must_exist and not os.path.exists(path):
            raise NotFoundError(
                f"Cannot find project home for {project_name} and hash key: {hash_key}"
            )
        return path

    # deprecated. use get_project_home()
    def get_project_path(self, api_key: str, project_name: str) -> str:
        return self.get_project_home(
            project_name=project_name, api_key=api_key, must_exist=False
        )

    def create_new_project(self, *, api_key: str, name: str, config_str: str) -> str:
        if api_key is None:
            raise ValueError("API key cannot be None")
        key = self.key_manager.get_key_data(api_key)
        if not key:
            raise ValueError("Invalid API Key")
        config_file_paths = key.config_file_paths
        if name in config_file_paths:
            raise ValueError(f"Config '{name}' already exists for key")
        if config_str is None:
            config_str = Config.DEFAULT_CONFIG

        hash_key = self.key_manager.hash_key(api_key)
        new_config_path = os.path.join(
            self.get_project_path(project_name=name, api_key=api_key),
            "config",
            "config.ini",
        )
        os.makedirs(os.path.dirname(new_config_path), exist_ok=True)
        self.app_config.logger.info(
            f"Create new project {name}. Config path: {new_config_path}"
        )
        #
        # we have exist_ok but it shouldn't be needed. if we delete a project we clean up the filesystem.
        # if a project is in the key an error is thrown. projects are namespaced by key hash(uuid) so
        # there won't be conflicts.
        #
        os.makedirs(os.path.dirname(new_config_path), exist_ok=True)
        projects_dir = self.projects_dir
        #
        # config has several settings that must be managed in a server context
        #
        config_str = self._modify_config(
            config_str=config_str,
            config_path=new_config_path,
            project_name=name,
            projects_dir=projects_dir,
            hash_key=hash_key,
        )
        with open(new_config_path, "w") as f:
            f.write(config_str)
        self.app_config.logger.debug(f"Wrote {name} config with len {len(config_str)}")
        config_file_paths[name] = new_config_path
        self.key_manager.update_key_data(api_key, key)
        return new_config_path

    def _modify_config(
        self,
        *,
        config_str: str,
        config_path: str,
        project_name: str,
        projects_dir: str,
        hash_key: str,
    ) -> str:
        #
        # we modify these config keys both defensively and to give access to the correct project
        # context.
        #
        self.app_config.logger.info(f"Moding {project_name} config at {config_path}")
        config_str = self._update_config_path(
            config_str=config_str, target_config_path=config_path
        )
        config_str = self._update_inputs_and_results_paths(
            config_str=config_str,
            projects_dir=projects_dir,
            hash_key=hash_key,
            project_name=project_name,
        )
        config_str = self._update_log_path(
            config_str=config_str,
            projects_dir=projects_dir,
            hash_key=hash_key,
            project_name=project_name,
        )
        config_str = self._set_no_local_no_http(config_str=config_str)
        config_str = self._set_cache_no_imports_no_scripts(
            config_str=config_str,
            projects_dir=projects_dir,
            hash_key=hash_key,
            project_name=project_name,
        )
        config_str = self._set_no_sqlite_dialect(
            config_str=config_str,
            projects_dir=projects_dir,
            hash_key=hash_key,
            project_name=project_name,
        )
        #
        # we allow var subbing and set the source to a local config/env.json file. the contents of the file
        # will need to be settable by API
        #
        config_str = self._set_var_source(
            config_str=config_str,
            projects_dir=projects_dir,
            hash_key=hash_key,
            project_name=project_name,
        )
        self.app_config.logger.debug(f"Modded {project_name} config at {config_path}")
        return config_str

    def _set_var_source(
        self, *, config_str: str, projects_dir: str, hash_key: str, project_name: str
    ) -> str:
        config = ConfigParser()
        config.read_string(config_str)
        try:
            config["config"]["allow_var_sub"] = "yes"
        except Exception:
            ...
        try:
            path = os.path.join(
                projects_dir, hash_key, project_name, "config", "env.json"
            )
            config["config"]["var_sub_source"] = path
            nos = Nos(path)
            if not nos.exists():
                with DataFileWriter(path=path) as file:
                    json.dump({}, file.sink, indent=4)
            self.app_config.logger.debug(
                f"Var source config: {project_name} source path {path}"
            )
        except Exception:
            print(traceback.format_exc())
        string_buffer = io.StringIO()
        config.write(string_buffer)
        config_str = string_buffer.getvalue()
        return config_str

    def _set_cache_no_imports_no_scripts(
        self, *, config_str: str, projects_dir: str, hash_key: str, project_name: str
    ) -> str:
        config = ConfigParser()
        config.read_string(config_str)
        #
        # there shouldn't be a time when these sections don't exist.
        #
        try:
            config["cache"]["use_cache"] = "yes"
            config["cache"]["path"] = os.path.join(
                projects_dir, hash_key, project_name, "cache"
            )
        except Exception:
            print(traceback.format_exc())
        try:
            config["scripts"]["run_scripts"] = "no"
        except KeyError:
            ...
        except Exception:
            print(traceback.format_exc())
        try:
            config["functions"]["imports"] = ""
        except KeyError:
            ...
        except Exception:
            print(traceback.format_exc())
        string_buffer = io.StringIO()
        config.write(string_buffer)
        config_str = string_buffer.getvalue()
        return config_str

    def _set_no_sqlite_dialect(
        self, *, config_str: str, projects_dir: str, hash_key: str, project_name: str
    ) -> str:
        config = ConfigParser()
        config.read_string(config_str)
        #
        # we don't allow SQL integration to use sqlite because that is typically
        # local filesystem, presenting security problems.
        #
        try:
            if config["sql"]["dialect"] == "sqlite":
                config["sql"]["dialect"] = ""
        except KeyError:
            ...
        except Exception:
            print(traceback.format_exc())
        #
        # set the sqlite path regardless of if sqlite is enabled. easy to do, no harm.
        #
        try:
            path = os.path.join(projects_dir, hash_key, project_name, "archive")
            nos = Nos(os.path.dirname(path))
            if not nos.exists():
                nos.makedirs()
            path = os.path.join(path, "csvpath.db")
            config["sqlite"]["db"] = path
            self.app_config.logger.debug(
                f"Var source config: {project_name} sqlite path {path}"
            )
        except KeyError:
            ...
        except Exception:
            print(traceback.format_exc())
        string_buffer = io.StringIO()
        config.write(string_buffer)
        config_str = string_buffer.getvalue()
        return config_str

    def _set_no_local_no_http(self, config_str: str) -> str:
        config = ConfigParser()
        config.read_string(config_str)
        #
        # we never allow http loading. too risky.
        #
        config["inputs"]["allow_http_files"] = "no"
        #
        # by default we don't allow local file loading. allowing local files is not a great idea unless you're
        # just using FlightPath Server for a small workgroup.
        #
        if not bout.yes(self.app_config.get(section="security", name="localhost_files_allowed", default="no")):
            config["inputs"]["allow_local_files"] = "no"
        string_buffer = io.StringIO()
        config.write(string_buffer)
        config_str = string_buffer.getvalue()
        return config_str

    def _update_log_path(
        self, *, config_str: str, projects_dir: str, hash_key: str, project_name: str
    ) -> str:
        config = ConfigParser()
        config.read_string(config_str)
        try:
            file = os.path.join(
                projects_dir, hash_key, project_name, "logs", "csvpath.log"
            )
            config["logging"]["log_file"] = file
            self.app_config.logger.debug(f"Log file: {project_name} file {file}")
        except Exception:
            print(traceback.format_exc())
        string_buffer = io.StringIO()
        config.write(string_buffer)
        config_str = string_buffer.getvalue()
        return config_str

    def _update_inputs_and_results_paths(
        self, *, config_str: str, projects_dir: str, hash_key: str, project_name: str
    ) -> str:
        config = ConfigParser()
        config.read_string(config_str)

        archive = config["results"]["archive"]
        transfers = config["results"]["transfers"]
        files = config["inputs"]["files"]
        paths = config["inputs"]["csvpaths"]

        config["results"]["archive"] = self._rewrite_path(
            projects_dir, hash_key, project_name, archive
        )
        config["results"]["transfers"] = self._rewrite_path(
            projects_dir, hash_key, project_name, transfers
        )
        config["inputs"]["files"] = self._rewrite_path(
            projects_dir, hash_key, project_name, files
        )
        config["inputs"]["csvpaths"] = self._rewrite_path(
            projects_dir, hash_key, project_name, paths
        )

        self.app_config.logger.debug(
            f"update_inputs_and_results_paths: {project_name}: archive {archive}, transfers {transfers}, files: {files}, paths: {paths}"
        )
        string_buffer = io.StringIO()
        config.write(string_buffer)
        config_str = string_buffer.getvalue()
        return config_str

    @staticmethod
    def _is_relative(path: str) -> bool:
        if path is None:
            return False
        path = str(path)
        path = path.strip()
        if path == "":
            return False
        if path.find(":\\") > -1:
            #
            # covers c:\ and c:\\ (should that appear for some reason)
            #
            return False
        if path.startswith("/"):
            #
            # covers /x/y/z and //x/y/z (should that really be a thing
            #
            return False
        if path.find("://") > -1:
            #
            # covers s3://..., sftp://... and similar
            #
            return False
        if path.startswith("\\\\"):
            #
            # covers shares in for \\share\x\y\z
            #
            return False
        if path.isupper():
            raise ValueError("Variable substitution is not available in path settings")
        if path[0] == "./" or path[0] == ".\\":
            #
            # covers .\x\y\z and ./x/y/z
            #
            return True
        if path.find("../") > -1 or path.find("..\\") > -1:
            raise ValueError(
                "Relative paths cannot have ../ upward references. Check {path}."
            )
        if (
            path[0]
            in "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_-+="
        ):
            # there are more concise and possibly more performant ways to do this, but this is
            # super explicit and obvious, and we're not in a time crunch here. that said, it does
            # put some higher constraints than OSs may. e.g. paths can have $ chars, but we don't
            # love that because csvpaths start with $ chars and because why would you want $ in
            # your paths? that is not operationally awesome, in our opinion. let's see if people
            # complain
            return True
        #
        # a path like \x\y\z would hit this error. we don't expect to see windows paths starting with \.
        #
        raise ValueError(f"Paths {path} does not appear to be a valid path")

    def _rewrite_path(
        self, projects_dir: str, hash_key: str, project_name: str, path: str
    ) -> str:
        #
        # relative paths:
        #   inputs\files -> [project dir]\inputs\files
        #
        # paths within the project dir:
        #   [project dir]\... -> [project dir]\...
        #
        # remote backends:
        #   ...://... -> ...://...
        #
        # absolute paths if local files are Ok:
        #   c:\mydir\inputs\files -> c:\mydir\inputs\files
        #
        # absolute paths if local files are NOT Ok:
        #   c:\mydir\inputs\files -> [project dir]\files
        #
        ret = None
        if path.startswith(os.path.join(projects_dir, hash_key, project_name)):
            ret = path
        elif path.find("://") > -1:
            ret = path
        elif ProjectManager._is_relative(path):
            ret = os.path.join(projects_dir, hash_key, project_name, path)
        else:
            a = self.app_config.get(
                section="security", name="localhost_files_allowed", default="yes"
            )
            if bout.yes(a):
                ret = path
            else:
                ret = os.path.join(
                    projects_dir, hash_key, project_name, os.path.basename(path)
                )
        return ret

    def _update_config_path(self, *, config_str: str, target_config_path: str) -> str:
        config = ConfigParser()
        config.read_string(config_str)
        #
        # set the configpath value to target_config_path
        #
        config["config"]["path"] = target_config_path
        self.app_config.logger.debug(f"Config path: path {target_config_path}")
        #
        # write the configpath to string
        #
        string_buffer = io.StringIO()
        config.write(string_buffer)
        config_str = string_buffer.getvalue()
        return config_str

    def get_all_project_config_paths(self) -> list[str]:
        """Returns every project config path across all API keys. Admin-only use."""
        all_keys = self.key_manager.key_store.load_all_keys()
        paths = []
        for key_data in all_keys.values():
            paths.extend(key_data.get("config_file_paths", {}).values())
        return paths

    def find_project_config_path(self, project_name: str) -> str | None:
        """Finds a project config path by name, searching across all API keys."""
        all_keys = self.key_manager.key_store.load_all_keys()
        for key_data in all_keys.values():
            cfp = key_data.get("config_file_paths", {})
            if project_name in cfp:
                return cfp[project_name]
        return None

    def delete_project(self, *, api_key: str, name: str) -> None:
        if api_key is None:
            raise ValueError("API key cannot be None")
        if name is None:
            raise ValueError("Project name cannot be None")
        self.app_config.logger.info(f"Delete proj: {name}: key {api_key}")

        key = self.key_manager.get_key_data(api_key)
        if not key:
            raise ValueError("Invalid API key")
        config_file_paths = key.config_file_paths
        if name not in config_file_paths:
            raise NotFoundError(f"Config '{name}' not found.")

        config_file_path = config_file_paths[name]
        project_path_to_delete = os.path.dirname(os.path.dirname(config_file_path))
        self.app_config.logger.info(f"Delete proj: {name}: config {config_file_path}")
        #
        # TODO: save a last backup zip of the project
        #
        if os.path.isdir(project_path_to_delete):
            shutil.rmtree(project_path_to_delete)
        del config_file_paths[name]
        self.key_manager.update_key_data(api_key, key)
        self.app_config.logger.info(f"Delete proj: {name} complete")

    def get_project_names(self, api_key: str) -> list[str]:
        if api_key is None:
            raise ValueError("API key cannot be None")
        key = self.key_manager.get_key_data(api_key)
        if not key:
            raise ValueError("Invalid API Key")
        return {"names": list(key.config_file_paths.keys())}

    def get_project_config_path(self, *, api_key: str, project_name: str) -> str:
        if not api_key:
            raise ValueError("API key cannot be None")
        if not project_name:
            raise ValueError("Project name cannot be None")
        key = self.key_manager.get_key_data(api_key)
        if not key:
            raise ValueError("Invalid API Key")
        config_file_paths = key.config_file_paths
        if project_name not in config_file_paths:
            raise NotFoundError(f"Project '{project_name}' not found.")
        return config_file_paths[project_name]

    def set_project_config(self, api_key: str, name: str, config_str: str) -> None:
        if api_key is None:
            raise ValueError("API key cannot be None")
        if name is None:
            raise ValueError("Project name cannot be None")
        if config_str is None:
            raise ValueError("Project config cannot be None")
        key = self.key_manager.get_key_data(api_key)
        if not key:
            raise ValueError("Invalid API Key")
        config_path = self.get_project_config_path(project_name=name, api_key=api_key)
        projects_dir = self.projects_dir
        hash_key = self.key_manager.hash_key(api_key)
        config_str = self._modify_config(
            config_str=config_str,
            config_path=config_path,
            project_name=name,
            projects_dir=projects_dir,
            hash_key=hash_key,
        )
        with open(config_path, "w") as f:
            f.write(config_str)
        self.key_manager.update_key_data(api_key, key)
        self.app_config.logger.debug(
            f"Set proj config: name {name}, config {config_path}"
        )

    def get_project_config(self, api_key: str, name: str) -> str:
        if api_key is None:
            raise ValueError("API key cannot be None")
        if name is None:
            raise ValueError("Project name cannot be None")
        key = self.key_manager.get_key_data(api_key)
        if not key:
            raise ValueError("Invalid API Key {api_key}")
        config_file_paths = key.config_file_paths
        if name not in config_file_paths:
            raise NotFoundError(f"Config '{name}' not found.")
        p = config_file_paths[name]
        if not Nos(p).exists():
            raise NotFoundError(f"Config not found at project path {p}")
        with open(p, "r") as f:
            return f.read()

    def get_project_config_field(self, *, api_key: str, project_name: str, section: str, field: str) -> str:
        config_path = self.get_project_config_path(api_key=api_key, project_name=project_name)
        config = ConfigParser()
        config.read(config_path)
        try:
            return config[section][field]
        except KeyError:
            raise NotFoundError(f"Field '{section}.{field}' not found in project '{project_name}' config.")

    def set_project_config_field(self, *, api_key: str, project_name: str, section: str, field: str, value: str) -> None:
        key = section.lower()
        name = field.lower()
        if (key, name) in _SERVER_MANAGED_FIELDS:
            raise ValueError(f"Field '{section}.{field}' is managed by the server and cannot be set via the API.")
        if key == "sql" and name == "dialect" and value.strip().lower() == "sqlite":
            raise ValueError("sqlite dialect is not permitted. Use mysql, postgres, or sql_server.")
        config_path = self.get_project_config_path(api_key=api_key, project_name=project_name)
        ConfigUpdater.update(path=config_path, section=section, name=field, value=value)
        self.app_config.logger.info(f"Set config field: {project_name} [{section}] {field}")

    def _get_env_path(self, api_key: str, name: str) -> str:
        key = self.key_manager.get_key_data(api_key)
        if not key:
            raise ValueError("Invalid API Key {api_key}")
        config_file_paths = key.config_file_paths
        if name not in config_file_paths:
            raise NotFoundError(f"Config '{name}' not found.")

        project_dir = os.path.dirname(os.path.dirname(config_file_paths[name]))
        self.app_config.logger.debug(
            f"Env path: {name}, key {api_key}, proj dir {project_dir}"
        )
        return os.path.join(project_dir, "config", "env.json")

    def set_env_file(self, api_key: str, name: str, env_str: str) -> None:
        if env_str is None:
            raise ValueError("Env file content cannot be None")
        env_path = self._get_env_path(api_key, name)
        self.app_config.logger.info(
            f"Set env path: {name}, key {api_key}, env_path {env_path}"
        )
        dirpath = os.path.dirname(env_path)
        nos = Nos(dirpath)
        if not nos.exists():
            nos.makedir()
        with FileLock(env_path + ".lock"):
            with open(env_path, "w") as f:
                f.write(env_str)

    def get_env_file(self, api_key: str, name: str) -> str:
        env_path = self._get_env_path(api_key, name)
        with FileLock(env_path + ".lock"):
            if not os.path.exists(env_path):
                with open(env_path, "w") as file:
                    json.dump({}, file, indent=4)
            self.app_config.logger.debug(
                f"Get env path: {name}, key {api_key}, env_path {env_path}"
            )
            with open(env_path, "r") as f:
                return f.read()

    def set_env_key(self, api_key: str, name: str, key: str, value: str) -> None:
        if key is None:
            raise ValueError("Key cannot be None")
        env_path = self._get_env_path(api_key, name)
        with FileLock(env_path + ".lock"):
            if not os.path.exists(env_path):
                with open(env_path, "w") as file:
                    json.dump({}, file, indent=4)
            with open(env_path, "r") as f:
                data = json.load(f)
            data[key] = value
            self.app_config.logger.info(
                f"Set env key: {name}, key {key}, value {value}, env_path {env_path}"
            )
            with open(env_path, "w") as f:
                json.dump(data, f, indent=4)

    def add_file(
        self, api_key: str, name: str, file_path: str, file_content: bytes
    ) -> None:
        if file_path is None:
            raise ValueError("File path cannot be None")
        if file_content is None:
            raise ValueError("File content cannot be None")

        if file_path in ["config/config.ini", "config/env.json"]:
            raise ValueError(f"Cannot modify protected file: {file_path}")

        max_size_kb = int(
            self.app_config.get(section="server", name="max_file_size_kb", default=1024)
        )
        if len(file_content) > max_size_kb * 1024:
            raise ValueError(f"File size exceeds the limit of {max_size_kb}KB")

        project_path = self.get_project_path(api_key, name)
        full_path = os.path.join(project_path, file_path)

        real_project = os.path.realpath(project_path)
        real_full = os.path.realpath(full_path)
        if not real_full.startswith(real_project + os.sep):
            raise ValueError(f"Invalid file path: {file_path}")

        os.makedirs(os.path.dirname(full_path), exist_ok=True)

        self.app_config.logger.info(
            f"Add proj file: {name}, key {api_key}, full_path {full_path}, file_path {file_path}"
        )
        with open(full_path, "wb") as f:
            f.write(file_content)

    def get_file(self, api_key: str, name: str, file_path: str) -> bytes:
        if file_path is None:
            raise ValueError("File path cannot be None")
        if file_path in ["config/config.ini", "config/env.json"]:
            raise ValueError(f"Cannot access protected file: {file_path}")

        project_path = self.get_project_path(api_key, name)
        full_path = os.path.join(project_path, file_path)

        real_project = os.path.realpath(project_path)
        real_full = os.path.realpath(full_path)
        if not real_full.startswith(real_project + os.sep):
            raise ValueError(f"Invalid file path: {file_path}")

        if not os.path.exists(full_path):
            raise NotFoundError(f"File not found: {file_path}")

        self.app_config.logger.debug(
            f"Get proj file: {name}, key {api_key}, full_path {full_path}, file_path {file_path}"
        )
        with open(full_path, "rb") as f:
            return f.read()
