from release_candidate_maker.release import ReleaseMaker as maker


def run():

    m = maker(new_version_handlers=[], copy_to_paths=[])

    m.main()


if __name__ == "__main__":
    run()
