#!/usr/bin/env python3

import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).parent.resolve()


#####################################


def read_pyproject():
    """Read pyproject.toml file."""
    pyproject_path = Path("./pyproject.toml")
    if not pyproject_path.exists():
        print("Error: pyproject.toml not found in current directory")
        sys.exit(1)
    with open(pyproject_path, "r") as f:
        content = f.read()
    return content


def extract_version(content):
    """Extract version number from pyproject.toml content."""
    match = re.search(r'^version\s*=\s*["\']([^"\']+)["\']', content, re.MULTILINE)
    if not match:
        print("Error: Could not find version in pyproject.toml")
        sys.exit(1)
    return match.group(1)


def increment_version(version):
    """Increment the patch version (third number)."""
    parts = version.split(".")
    if len(parts) != 3:
        print(f"Error: Version format not supported: {version}")
        sys.exit(1)
    try:
        parts[2] = str(int(parts[2]) + 1)
    except ValueError:
        print(f"Error: Cannot increment non-numeric patch version: {parts[2]}")
        sys.exit(1)
    return ".".join(parts)


def update_version_in_content(content, old_version, new_version):
    """Update version in pyproject.toml content."""
    pattern = re.compile(
        r'^(version\s*=\s*["\'])' + re.escape(old_version) + r'(["\'])', re.MULTILINE
    )
    new_content = pattern.sub(r"\g<1>" + new_version + r"\g<2>", content)
    return new_content


def save_pyproject(content):
    """Save updated pyproject.toml."""
    with open("./pyproject.toml", "w") as f:
        f.write(content)


def get_yes_no_input(prompt):
    """Get yes/no input from user."""
    while True:
        response = input(f"{prompt} (y/n): ").lower()
        if response and response.strip().lower() in ["y", "yes"]:
            return True
        elif response and response.strip().lower() in ["n", "no"]:
            return False
        else:
            print("Please enter 'y' or 'n'")


def update_version_if():
    content = read_pyproject()
    current_version = extract_version(content)
    print(f"\nCurrent version: {current_version}")
    new_version = increment_version(current_version)
    if get_yes_no_input(f"Do you want to update the version to {new_version}?"):
        print(f"New version will be: {new_version}")
        content = update_version_in_content(content, current_version, new_version)
        save_pyproject(content)
        print(f"Updated pyproject.toml to version {new_version}")
    else:
        new_version = current_version
        print(f"Keeping current version: {current_version}")


#####################################


def run(cmd: list[str]) -> None:
    """Run a subprocess command, exit on failure."""
    print(f"  $ {' '.join(cmd)}")
    result = subprocess.run(cmd, cwd=ROOT)
    if result.returncode != 0:
        print(
            f"\n[ERROR] Command failed with exit code {result.returncode}: {' '.join(cmd)}"
        )
        sys.exit(result.returncode)


def remove_files(pattern: str, base: Path, description: str) -> None:
    """Glob-remove files matching pattern under base, with a status line."""
    matches = list(base.glob(pattern))
    if matches:
        for f in matches:
            f.unlink()
        print(f"  removed {len(matches)} {description}")
    else:
        print(f"  (no {description} found)")


def clear_pyc_files() -> None:
    print("\n--- Clearing .pyc files ---")
    matches = list(ROOT.rglob("*.pyc"))
    for f in matches:
        f.unlink()
    print(f"  removed {len(matches)} .pyc file(s)")


def clear_logs() -> None:
    print("\n--- Clearing ./logs ---")
    logs_dir = ROOT / "logs"
    if not logs_dir.is_dir():
        print("  [WARN] ./logs directory not found, skipping")
        return
    remove_files("*.log*", logs_dir, ".log file(s)")
    ds = logs_dir / ".DS_Store"
    if ds.exists():
        ds.unlink()
        print("  removed .DS_Store")
    print(
        "  logs dir now contains:",
        [f.name for f in sorted(logs_dir.iterdir())] or "(empty)",
    )


def clear_dist() -> None:
    print("\n--- Clearing ./dist ---")
    dist_dir = ROOT / "dist"
    if not dist_dir.is_dir():
        print("  ./dist not found, will be created by build")
        return
    removed = 0
    for f in dist_dir.iterdir():
        if f.is_file():
            f.unlink()
            removed += 1
    print(f"  removed {removed} file(s) from ./dist")


def build() -> None:
    print("\n--- Building dist ---")
    run(["uv", "sync"])
    run(["uv", "build"])


def copy_artifacts() -> None:
    print("\n--- Copying artifacts ---")
    dist_dir = ROOT / "dist"
    builds_dir = ROOT / "builds"
    builds_dir.mkdir(exist_ok=True)

    flightpath_assets = Path.home() / "dev" / "flightpath" / "assets"

    for pattern, destinations, label in [
        ("*.whl", [builds_dir], ".whl → builds/"),
        (
            "*.tar.gz",
            [builds_dir, flightpath_assets],
            ".tar.gz → builds/ and flightpath assets/",
        ),
    ]:
        files = list(dist_dir.glob(pattern))
        if not files:
            print(f"  [WARN] no {pattern} found in dist/")
            continue
        for src in files:
            for dest in destinations:
                if not dest.is_dir():
                    print(f"  [WARN] destination not found, skipping: {dest}")
                    continue
                shutil.copy2(src, dest / src.name)
            print(f"  {src.name}  →  {label}")


def main() -> None:
    print(f"Working directory: {ROOT}")
    clear_pyc_files()
    clear_logs()
    clear_dist()
    update_version_if()
    build()
    copy_artifacts()
    print("\n--- Done ---")


if __name__ == "__main__":
    main()
