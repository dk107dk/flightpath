import base64
import json
import pytest

from flightpath_server.v2.routers.archive import _read_b64, _read_json, _ref


# ---------------------------------------------------------------------------
# _ref
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("name,run_dir,expected", [
    ("orders", None, "$orders.results"),
    ("invoices", "2026-04-12_14-30-00", "$invoices.results.2026-04-12_14-30-00"),
    ("sales", "2025-01-01_00-00-00", "$sales.results.2025-01-01_00-00-00"),
])
def test_ref(name, run_dir, expected):
    assert _ref(name, run_dir) == expected


# ---------------------------------------------------------------------------
# _read_json
# ---------------------------------------------------------------------------

def test_read_json_missing_file_returns_fallback(tmp_path):
    result = _read_json(str(tmp_path / "nonexistent.json"), {"default": True})
    assert result == {"default": True}


def test_read_json_missing_file_list_fallback(tmp_path):
    result = _read_json(str(tmp_path / "nonexistent.json"), [])
    assert result == []


def test_read_json_existing_file(tmp_path):
    path = tmp_path / "data.json"
    path.write_text(json.dumps([{"error": "bad value"}]))
    result = _read_json(str(path), [])
    assert result == [{"error": "bad value"}]


# ---------------------------------------------------------------------------
# _read_b64
# ---------------------------------------------------------------------------

def test_read_b64_missing_file_returns_none(tmp_path):
    result = _read_b64(str(tmp_path / "nonexistent.csv"))
    assert result is None


def test_read_b64_existing_file(tmp_path):
    content = b"col1,col2\nval1,val2"
    path = tmp_path / "data.csv"
    path.write_bytes(content)
    result = _read_b64(str(path))
    assert result == base64.b64encode(content).decode("utf-8")
