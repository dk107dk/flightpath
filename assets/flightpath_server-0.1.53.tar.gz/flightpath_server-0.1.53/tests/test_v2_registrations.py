import pytest
from unittest.mock import MagicMock
from fastapi import HTTPException

from flightpath_server.v2.routers.registrations import (
    _name_from_reference,
    _assert_reference_name,
)


# ---------------------------------------------------------------------------
# _name_from_reference
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("reference,expected", [
    ("$orders.files.2026-04-12_02-:last", "orders"),
    ("$invoices.files.partners/Acme Inc:all", "invoices"),
    ("$sales.files.yesterday:0", "sales"),
    ("$myfile#Sheet1.files.last", "myfile"),
    ("$data#Summary.files.2026-01-01:first", "data"),
])
def test_name_from_reference(reference, expected):
    assert _name_from_reference(reference) == expected


# ---------------------------------------------------------------------------
# _assert_reference_name
# ---------------------------------------------------------------------------

@pytest.fixture
def app_config():
    cfg = MagicMock()
    cfg.http_error.side_effect = lambda *, name, code, msg: HTTPException(
        status_code=code, detail=msg
    )
    return cfg


def test_assert_reference_name_match_passes(app_config):
    _assert_reference_name("orders", "$orders.files.last", app_config)


def test_assert_reference_name_mismatch_raises_400(app_config):
    with pytest.raises(HTTPException) as exc_info:
        _assert_reference_name("invoices", "$orders.files.last", app_config)
    assert exc_info.value.status_code == 400
    assert "orders" in exc_info.value.detail
    assert "invoices" in exc_info.value.detail
