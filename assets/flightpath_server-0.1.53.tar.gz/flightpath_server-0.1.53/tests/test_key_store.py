import os
import json
import pytest
from flightpath_server.config.app_config import AppConfig
from flightpath_server.keys.key_store import FileKeyStore, KeyStore
from flightpath_server.keys.key import Key


def delete_test_keystore_file() -> None:
    path = os.path.join(
        "tests", "test_resources", "config", "app_config", "key_store_app_config.ini"
    )
    app_config = AppConfig(path)
    keyfile = app_config.get(section="security", name="key_file_path")
    if os.path.exists(keyfile):
        os.remove(keyfile)
    delete_key_index()


def delete_key_index() -> None:
    path = os.path.join(
        "tests", "test_resources", "config", "app_config", "key_index.json"
    )
    if os.path.exists(path):
        os.remove(path)


@pytest.fixture
def key_data() -> dict:
    key_data = {
        "key_name": "test_key",
        "key_owner_name": "test_owner",
        "key_owner_contact": "test_contact",
        "config_file_paths": {},
    }
    return key_data


@pytest.fixture
def key_store() -> KeyStore:
    path = os.path.join(
        "tests", "test_resources", "config", "app_config", "key_store_app_config.ini"
    )
    app_config = AppConfig(path)
    keyfile = app_config.get(section="security", name="key_file_path")
    if os.path.exists(keyfile):
        os.remove(keyfile)
    key_store = FileKeyStore(app_config)
    return key_store


def test_new_file_key_store():
    path = os.path.join(
        "tests", "test_resources", "config", "app_config", "key_store_app_config.ini"
    )
    app_config = AppConfig(path)
    keyfile = app_config.get(section="security", name="key_file_path")
    print(f"found keyfile: {keyfile}")
    if os.path.exists(keyfile):
        os.remove(keyfile)
    FileKeyStore(app_config)
    if not os.path.exists(keyfile):
        raise RuntimeError(f"keystore path must exist at {keyfile}")
    os.remove(keyfile)


def test_add_key(key_store, key_data):
    key = Key(**key_data)
    api_key = key_store.add_key(key)
    assert api_key is not None
    with open(key_store.key_file, "r") as f:
        keys = json.load(f)
    hashed_key = key_store.hash_key(api_key)
    assert hashed_key in keys
    assert keys[hashed_key] == key.model_dump()
    delete_test_keystore_file()


def test_key_index(key_store, key_data):
    key_store._app_config.set(section="security", name="key_index", value="yes")
    delete_key_index()
    assert key_store._app_config.get(section="security", name="key_index") == "yes"

    key = Key(**key_data)
    api_key = key_store.add_key(key)
    assert api_key is not None
    with open(key_store.key_file, "r") as f:
        keys = json.load(f)
    hashed_key = key_store.hash_key(api_key)
    assert hashed_key in keys
    assert keys[hashed_key] == key.model_dump()

    path = os.path.join(os.path.dirname(key_store._key_file), "key_index.json")
    assert os.path.exists(path)

    with open(path, "r") as f:
        keys = json.load(f)
    found_key = keys.get(hashed_key)
    assert found_key
    assert found_key == api_key

    delete_test_keystore_file()


def test_get_key_data(key_store, key_data):
    key = Key(**key_data)
    api_key = key_store.add_key(key)
    retrieved_key = key_store.get_key_data(api_key)
    assert retrieved_key == key
    delete_test_keystore_file()


def test_get_key_data_invalid_key(key_store):
    retrieved_key = key_store.get_key_data("invalid_key")
    assert retrieved_key is None
    delete_test_keystore_file()


def test_delete_key(key_store, key_data):
    key = Key(**key_data)
    api_key = key_store.add_key(key)
    assert key_store.delete_key(api_key) is True
    assert key_store.get_key_data(api_key) is None
    delete_test_keystore_file()


def test_delete_invalid_key(key_store):
    assert key_store.delete_key("invalid_key") is False
    delete_test_keystore_file()


def test_update_key_data(key_store, key_data):
    key = Key(**key_data)
    api_key = key_store.add_key(key)
    key = key_store.get_key_data(api_key)
    key.key_owner_name = "dk"
    assert key_store.update_key_data(api_key, key) is True
    new_data = key_store.get_key_data(api_key)
    assert new_data
    assert new_data.key_owner_name == "dk"
    delete_test_keystore_file()


def test_update_invalid_key(key_store):
    assert key_store.delete_key("invalid_key") is False
    delete_test_keystore_file()


def test_default_key_file_path(monkeypatch):
    # Ensure the environment variable is not set
    monkeypatch.delenv("FLIGHTPATH_API_KEY_FILE", raising=False)

    # Create a mock AppConfig that returns None for key_file_path
    mock_app_config = AppConfig(
        os.path.join(
            "tests", "test_resources", "config", "app_config", "app_config.ini"
        )
    )
    monkeypatch.setattr(
        mock_app_config, "get", lambda section, name, default=None: None
    )

    # Create a FileKeyStore instance
    key_store = FileKeyStore(mock_app_config)

    # Assert that the key_file path is the default path
    default_path = os.path.expanduser("~/FlightPathServer/config/keys.json")
    assert key_store.key_file == default_path

    # Clean up the dummy file
    os.remove(default_path)
