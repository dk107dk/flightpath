import pytest
from unittest.mock import MagicMock
from flightpath_server.util.info_dumper import InfoDumper


@pytest.fixture
def verbose_config():
    cfg = MagicMock()
    cfg.verbose.return_value = True
    return cfg


@pytest.fixture
def quiet_config():
    cfg = MagicMock()
    cfg.verbose.return_value = False
    return cfg


# ---------------------------------------------------------------------------
# dump_info_string — guard clauses
# ---------------------------------------------------------------------------

def test_none_app_config_raises():
    with pytest.raises(ValueError, match="App config cannot be None"):
        InfoDumper.dump_info_string(app_config=None, hash_key="abc")


def test_none_hash_key_raises(verbose_config):
    with pytest.raises(ValueError, match="Api key cannot be None"):
        InfoDumper.dump_info_string(app_config=verbose_config, hash_key=None)


# ---------------------------------------------------------------------------
# dump_info_string — verbose=False early return
# ---------------------------------------------------------------------------

def test_not_verbose_returns_none(quiet_config):
    result = InfoDumper.dump_info_string(app_config=quiet_config, hash_key="abc")
    assert result is None


# ---------------------------------------------------------------------------
# dump_info_string — content when verbose=True
# ---------------------------------------------------------------------------

def test_hash_key_appears_in_output(verbose_config):
    result = InfoDumper.dump_info_string(app_config=verbose_config, hash_key="deadbeef")
    assert "deadbeef" in result


def test_none_project_name_shows_unset(verbose_config):
    result = InfoDumper.dump_info_string(app_config=verbose_config, hash_key="abc", project_name=None)
    assert "Project unset" in result


def test_blank_project_name_shows_unset(verbose_config):
    result = InfoDumper.dump_info_string(app_config=verbose_config, hash_key="abc", project_name="   ")
    assert "Project unset" in result


def test_project_name_included_in_output(verbose_config):
    result = InfoDumper.dump_info_string(app_config=verbose_config, hash_key="abc", project_name="my-project")
    assert "my-project" in result


def test_no_csvpaths_shows_placeholder(verbose_config):
    result = InfoDumper.dump_info_string(app_config=verbose_config, hash_key="abc")
    assert "No CsvPaths instance" in result


def test_csvpaths_config_path_included(verbose_config):
    csvpaths = MagicMock()
    csvpaths.config.get.return_value = "/projects/xyz/config.ini"
    result = InfoDumper.dump_info_string(app_config=verbose_config, hash_key="abc", csvpaths=csvpaths)
    assert "/projects/xyz/config.ini" in result
    csvpaths.config.get.assert_called_once_with(section="config", name="path")


# ---------------------------------------------------------------------------
# dump_info — delegates to logger.debug
# ---------------------------------------------------------------------------

def test_dump_info_calls_logger_debug(verbose_config):
    InfoDumper.dump_info(app_config=verbose_config, hash_key="abc", project_name="proj")
    verbose_config.logger.debug.assert_called_once()


def test_dump_info_passes_string_to_debug(verbose_config):
    InfoDumper.dump_info(app_config=verbose_config, hash_key="abc", project_name="proj")
    logged = verbose_config.logger.debug.call_args[0][0]
    assert "abc" in logged
    assert "proj" in logged
