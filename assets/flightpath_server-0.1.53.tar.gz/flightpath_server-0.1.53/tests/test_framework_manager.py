import pytest
from contextlib import ExitStack
from unittest.mock import MagicMock, patch, call
from flightpath_server.framework_manager import FrameworkManager

_PATCH_TARGETS = [
    "flightpath_server.framework_manager.KeyManager",
    "flightpath_server.framework_manager.RunManager",
    "flightpath_server.framework_manager.ResultsManager",
    "flightpath_server.framework_manager.CsvPathsLoader",
    "flightpath_server.framework_manager.RegistrationManager",
    "flightpath_server.framework_manager.Box",
]


@pytest.fixture
def deps():
    """Patches all FrameworkManager dependencies and wires up a valid key by default."""
    with ExitStack() as stack:
        mocks = {t.split(".")[-1]: stack.enter_context(patch(t)) for t in _PATCH_TARGETS}

        key_data = MagicMock()
        key_data.key_name = "test_key"
        km = MagicMock()
        km.get_key_data.return_value = key_data
        mocks["KeyManager"].return_value = km
        mocks["_km"] = km
        mocks["_key_data"] = key_data

        mock_csvpaths = MagicMock()
        mocks["CsvPathsLoader"].get_csvpaths.return_value = mock_csvpaths
        mocks["_csvpaths"] = mock_csvpaths

        mocks["app_config"] = MagicMock()

        yield mocks


def _build(deps, *, api_key="test-key", project_name="test-project"):
    return FrameworkManager(
        api_key=api_key,
        project_name=project_name,
        app_config=deps["app_config"],
    )


# ---------------------------------------------------------------------------
# Constructor — guard clauses
# ---------------------------------------------------------------------------

def test_invalid_api_key_raises(deps):
    deps["_km"].get_key_data.return_value = None
    with pytest.raises(ValueError, match="Invalid API Key"):
        _build(deps)


def test_none_project_name_raises(deps):
    with pytest.raises(ValueError, match="project name"):
        _build(deps, project_name=None)


# ---------------------------------------------------------------------------
# Constructor — successful construction
# ---------------------------------------------------------------------------

def test_construction_sets_api_key(deps):
    fm = _build(deps, api_key="my-key")
    assert fm.api_key == "my-key"


def test_construction_sets_project_name(deps):
    fm = _build(deps, project_name="my-project")
    assert fm.project_name == "my-project"


def test_construction_sets_key_data(deps):
    fm = _build(deps)
    assert fm.key_data is deps["_key_data"]


def test_construction_sets_csvpaths(deps):
    fm = _build(deps)
    assert fm.csvpaths is deps["_csvpaths"]


def test_app_config_property(deps):
    fm = _build(deps)
    assert fm.app_config is deps["app_config"]


# ---------------------------------------------------------------------------
# Box / cleanup
# ---------------------------------------------------------------------------

def test_box_emptied_on_construction(deps):
    _build(deps)
    deps["Box"].return_value.empty_my_stuff.assert_called()


def test_cleanup_empties_box(deps):
    fm = _build(deps)
    before = deps["Box"].return_value.empty_my_stuff.call_count
    fm._cleanup()
    assert deps["Box"].return_value.empty_my_stuff.call_count == before + 1


# ---------------------------------------------------------------------------
# Delegation — registration
# ---------------------------------------------------------------------------

def test_register_file_delegates(deps):
    fm = _build(deps)
    fm.register_file(named_file_name="myfile", file_location="/path/to/file.csv", template=None)
    fm.registration_manager.register_file.assert_called_once_with(
        named_file_name="myfile",
        file_location="/path/to/file.csv",
        template=None,
    )


def test_register_file_cleans_up(deps):
    fm = _build(deps)
    before = deps["Box"].return_value.empty_my_stuff.call_count
    fm.register_file(named_file_name="f", file_location="/x")
    assert deps["Box"].return_value.empty_my_stuff.call_count == before + 1


def test_register_csvpath_group_delegates(deps):
    fm = _build(deps)
    fm.register_csvpath_group(named_paths_name="mypaths", file_location="/p.csvpaths", append=True)
    fm.registration_manager.register_csvpath_group.assert_called_once_with(
        named_paths_name="mypaths",
        file_location="/p.csvpaths",
        template=None,
        append=True,
    )


# ---------------------------------------------------------------------------
# Delegation — run
# ---------------------------------------------------------------------------

def test_run_calls_new_run_then_do_run(deps):
    fm = _build(deps)
    mock_run = MagicMock()
    fm.run_manager.new_run.return_value = mock_run

    fm.run(named_file_name="f", named_paths_name="p", method="collect_paths")

    fm.run_manager.new_run.assert_called_once_with(
        csvpaths=fm.csvpaths,
        run_method="collect_paths",
        pathsname="p",
        filename="f",
        template=None,
        api_key="test-key",
        project_name="test-project",
    )
    fm.run_manager.do_run.assert_called_once_with(mock_run)


# ---------------------------------------------------------------------------
# Delegation — results
# ---------------------------------------------------------------------------

def test_get_run_path_delegates(deps):
    fm = _build(deps)
    fm.get_run_path("$paths.results.:last")
    fm.results_manager.get_run_path.assert_called_once_with(
        run_reference="$paths.results.:last",
        api_key="test-key",
        project_name="test-project",
    )


def test_find_completed_runs_delegates(deps):
    fm = _build(deps)
    fm.find_completed_runs("$paths.results")
    fm.results_manager.find_completed_runs.assert_called_once_with(
        run_reference="$paths.results",
        api_key="test-key",
        project_name="test-project",
    )


def test_find_registered_files_delegates(deps):
    fm = _build(deps)
    fm.find_registered_files("myfile.:last")
    fm.registration_manager.find_files.assert_called_once_with(reference="myfile.:last")


def test_get_result_delegates(deps):
    fm = _build(deps)
    fm.get_result("$paths.results.:last.print")
    fm.results_manager.get_result.assert_called_once_with(
        api_key="test-key",
        project_name="test-project",
        reference="$paths.results.:last.print",
    )
