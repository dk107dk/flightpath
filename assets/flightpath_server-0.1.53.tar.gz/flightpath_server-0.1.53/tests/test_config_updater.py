import configparser
import pytest
from flightpath_server.util.config_updater import ConfigUpdater

BASE_CONFIG = """
[section]
key = original
"""


def test_neither_path_nor_string_raises():
    with pytest.raises(ValueError):
        ConfigUpdater.update(section="section", name="key", value="new")


def test_string_only_returns_updated_string():
    result = ConfigUpdater.update(config_str=BASE_CONFIG, section="section", name="key", value="changed")
    cfg = configparser.ConfigParser()
    cfg.read_string(result)
    assert cfg["section"]["key"] == "changed"


def test_string_only_does_not_write_file(tmp_path):
    sentinel = tmp_path / "should_not_exist.ini"
    ConfigUpdater.update(config_str=BASE_CONFIG, section="section", name="key", value="changed")
    assert not sentinel.exists()


def test_path_only_reads_and_writes_file(tmp_path):
    config_file = tmp_path / "config.ini"
    config_file.write_text(BASE_CONFIG)

    result = ConfigUpdater.update(path=str(config_file), section="section", name="key", value="from_file")

    # return value is updated
    cfg = configparser.ConfigParser()
    cfg.read_string(result)
    assert cfg["section"]["key"] == "from_file"

    # file on disk is also updated
    written = configparser.ConfigParser()
    written.read(str(config_file))
    assert written["section"]["key"] == "from_file"


def test_path_and_string_reads_string_writes_file(tmp_path):
    config_file = tmp_path / "config.ini"
    config_file.write_text(BASE_CONFIG)

    # config_str has a different section than the file — proves we read from string, not file
    other_config = """
[other]
thing = original
"""
    result = ConfigUpdater.update(
        path=str(config_file),
        config_str=other_config,
        section="other",
        name="thing",
        value="updated",
    )

    # return value reflects the string, not the file's original content
    cfg = configparser.ConfigParser()
    cfg.read_string(result)
    assert cfg["other"]["thing"] == "updated"
    assert "section" not in cfg

    # file on disk was written with the updated string content
    written = configparser.ConfigParser()
    written.read(str(config_file))
    assert written["other"]["thing"] == "updated"
    assert "section" not in written
