import hashlib
import pytest
from flightpath_server.keys.key_manager import KeyManager
from flightpath_server.keys.key import Key
from flightpath_server.config.app_config import AppConfig
import os


_KEY_DATA = {
    "key_name": "test admin",
    "key_owner_name": "dk",
    "key_owner_contact": "foo",
    "admin": False,
    "config_file_paths": {},
}

_USER_DATA = {
    "key_name": "test user",
    "key_owner_name": "dk",
    "key_owner_contact": "foo",
    "admin": False,
    "config_file_paths": {},
}


@pytest.fixture
def key_manager():
    path = os.path.join(
        "tests", "test_resources", "config", "app_config", "key_manager_app_config.ini"
    )
    app_config = AppConfig(path)
    key_file = app_config.get(section="security", name="key_file_path")
    if os.path.exists(key_file):
        os.remove(key_file)
    key_manager = KeyManager(app_config=app_config)
    return key_manager


def test_create_key(key_manager):
    key_data = {
        "key_name": "test admin",
        "key_owner_name": "dk",
        "key_owner_contact": "foo",
        "admin": False,
        "config_file_paths": {},
    }
    admin_uuid = key_manager.create_key(key=Key(**key_data))
    if admin_uuid is None:
        raise ValueError("Admin UUID cannot be None")
    admin_data = key_manager.get_key_data(admin_uuid)
    if admin_data.admin is not True:
        raise ValueError("Admin data admin flag must be True")
    new_user = {
        "key_name": "test user",
        "key_owner_name": "also dk",
        "key_owner_contact": "foo",
        "admin": False,
        "config_file_paths": {},
    }
    user_uuid = key_manager.create_key(api_key=admin_uuid, key=Key(**new_user))
    if user_uuid is None:
        raise ValueError("User uuid cannot be None")
    user_data = key_manager.get_key_data(user_uuid)
    if user_data is None:
        raise ValueError("User data cannot be None")
    assert user_data.key_name == new_user["key_name"]


def test_delete_key(key_manager):
    # test partly overlaps create key. but it may diverge later.
    key_data = {
        "key_name": "test admin",
        "key_owner_name": "dk",
        "key_owner_contact": "foo",
        "admin": False,
        "config_file_paths": {},
    }
    admin_uuid = key_manager.create_key(api_key=None, key=Key(**key_data))
    if admin_uuid is None:
        raise ValueError("Admin UUID cannot be None")
    admin_data = key_manager.get_key_data(admin_uuid)
    print(f"admin_data: {admin_data}")
    print(f"admin uuid: {admin_uuid} in {key_manager.key_store.key_file}")
    if admin_data.admin is not True:
        raise ValueError("Admin data admin flag must be True")
    new_user = {
        "key_name": "test user",
        "key_owner_name": "dk",
        "key_owner_contact": "foo",
        "admin": False,
        "config_file_paths": {},
    }
    user_uuid = key_manager.create_key(api_key=admin_uuid, key=Key(**new_user))
    if user_uuid is None:
        raise ValueError("User uuid cannot be None")
    user_data = key_manager.get_key_data(user_uuid)
    if user_data is None:
        raise ValueError("User data cannot be None")
    assert user_data.key_name == new_user["key_name"]
    with pytest.raises(ValueError):
        key_manager.delete_key(admin_key=user_uuid, delete_key=user_uuid)
    assert key_manager.delete_key(admin_key=admin_uuid, delete_key=user_uuid)
    assert not key_manager.validate_key(user_uuid)


# ---------------------------------------------------------------------------
# has_keys
# ---------------------------------------------------------------------------

def test_has_keys_false_when_empty(key_manager):
    assert key_manager.has_keys() is False


def test_has_keys_true_after_create(key_manager):
    key_manager.create_key(key=Key(**_KEY_DATA))
    assert key_manager.has_keys() is True


# ---------------------------------------------------------------------------
# hash_key
# ---------------------------------------------------------------------------

def test_hash_key_returns_sha256_hex(key_manager):
    raw = "some-api-key"
    expected = hashlib.sha256(raw.encode()).hexdigest()
    assert key_manager.hash_key(raw) == expected


def test_hash_key_is_deterministic(key_manager):
    raw = "some-api-key"
    assert key_manager.hash_key(raw) == key_manager.hash_key(raw)


# ---------------------------------------------------------------------------
# validate_key
# ---------------------------------------------------------------------------

def test_validate_key_true_for_valid(key_manager):
    api_key = key_manager.create_key(key=Key(**_KEY_DATA))
    assert key_manager.validate_key(api_key) is True


def test_validate_key_false_for_invalid(key_manager):
    assert key_manager.validate_key("not-a-real-key") is False


# ---------------------------------------------------------------------------
# is_admin
# ---------------------------------------------------------------------------

def test_is_admin_true_for_admin_key(key_manager):
    admin_key = key_manager.create_key(key=Key(**_KEY_DATA))
    assert key_manager.is_admin(admin_key) is True


def test_is_admin_false_for_non_admin(key_manager):
    admin_key = key_manager.create_key(key=Key(**_KEY_DATA))
    user_key = key_manager.create_key(api_key=admin_key, key=Key(**_USER_DATA))
    assert key_manager.is_admin(user_key) is False


# ---------------------------------------------------------------------------
# update_key_data
# ---------------------------------------------------------------------------

def test_update_key_data_none_api_key_raises(key_manager):
    with pytest.raises(ValueError, match="API key cannot be None"):
        key_manager.update_key_data(None, Key(**_USER_DATA))


def test_update_key_data_none_key_raises(key_manager):
    with pytest.raises(ValueError, match="Key cannot be None"):
        key_manager.update_key_data("some-key", None)


def test_update_key_data_persists_change(key_manager):
    api_key = key_manager.create_key(key=Key(**_KEY_DATA))
    updated = key_manager.get_key_data(api_key)
    updated.key_owner_name = "updated-name"
    key_manager.update_key_data(api_key, updated)
    reloaded = key_manager.get_key_data(api_key)
    assert reloaded.key_owner_name == "updated-name"


# ---------------------------------------------------------------------------
# create_key — invalid api_key when keys exist
# ---------------------------------------------------------------------------

def test_create_key_invalid_api_key_raises(key_manager):
    key_manager.create_key(key=Key(**_KEY_DATA))  # creates first (admin) key
    with pytest.raises(ValueError, match="Invalid API key"):
        key_manager.create_key(api_key="bad-key", key=Key(**_USER_DATA))



# ---------------------------------------------------------------------------
# set_admin_status
# ---------------------------------------------------------------------------

def test_set_admin_status_unknown_key_raises(key_manager):
    with pytest.raises(ValueError, match="API key not found\\."):
        key_manager.set_admin_status(api_key="nonexistent-key")


def test_set_admin_status_promotes_to_admin(key_manager):
    admin_key = key_manager.create_key(key=Key(**_KEY_DATA))
    user_key = key_manager.create_key(api_key=admin_key, key=Key(**_USER_DATA))
    assert key_manager.is_admin(user_key) is False
    key_manager.set_admin_status(api_key=user_key, is_admin=True)
    assert key_manager.is_admin(user_key) is True


def test_set_admin_status_demotes_from_admin(key_manager):
    admin_key = key_manager.create_key(key=Key(**_KEY_DATA))
    key_manager.set_admin_status(api_key=admin_key, is_admin=False)
    assert key_manager.is_admin(admin_key) is False
