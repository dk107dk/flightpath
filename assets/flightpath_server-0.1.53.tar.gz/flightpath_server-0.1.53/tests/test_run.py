from datetime import datetime, timezone
from flightpath_server.runs.run import Run


REQUIRED = {
    "run_uuid": "abc-123",
    "start_time": None,
    "end_time": None,
    "csvpaths": None,
    "run_method": "collect_paths",
    "pathsname": "mypaths",
    "filename": "myfile",
    "template": None,
    "api_key": "hashed-key",
    "result_reference": None,
    "project_name": "myproject",
    "config_path": "/some/config.ini",
}


def _make(**overrides) -> Run:
    return Run(**{**REQUIRED, **overrides})


# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------

def test_fields_are_set():
    run = _make()
    assert run.run_uuid == "abc-123"
    assert run.run_method == "collect_paths"
    assert run.pathsname == "mypaths"
    assert run.filename == "myfile"
    assert run.api_key == "hashed-key"
    assert run.project_name == "myproject"
    assert run.config_path == "/some/config.ini"


def test_optional_fields_default_none():
    run = _make()
    assert run.start_time is None
    assert run.end_time is None
    assert run.csvpaths is None
    assert run.template is None
    assert run.result_reference is None
    assert run.run_summary_path is None


def test_timestamps_accepted():
    now = datetime.now(timezone.utc)
    run = _make(start_time=now, end_time=now)
    assert run.start_time == now
    assert run.end_time == now


# ---------------------------------------------------------------------------
# __str__
# ---------------------------------------------------------------------------

def test_str_includes_run_uuid():
    run = _make()
    assert "abc-123" in str(run)


def test_str_includes_run_method():
    run = _make()
    assert "collect_paths" in str(run)


def test_str_includes_project_name():
    run = _make()
    assert "myproject" in str(run)


def test_str_includes_api_key():
    run = _make()
    assert "hashed-key" in str(run)


# ---------------------------------------------------------------------------
# Serialisation — used by RunManager.update_runs_in_progress
# ---------------------------------------------------------------------------

def test_model_dump_json_mode_serialises():
    run = _make()
    data = run.model_dump(mode="json")
    assert data["run_uuid"] == "abc-123"
    assert data["csvpaths"] is None


def test_model_dump_exclude_csvpaths():
    run = _make()
    data = run.model_dump(exclude={"csvpaths"})
    assert "csvpaths" not in data
    assert data["run_uuid"] == "abc-123"
