import configparser
import os

import pytest
from unittest.mock import MagicMock

from flightpath_server.projects.project_manager import ProjectManager
from flightpath_server.util.config_updater import ConfigUpdater
from flightpath_server.v2.routers.admin import _server_local_files_allowed


# ---------------------------------------------------------------------------
# _server_local_files_allowed
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("value,expected", [
    ("yes", True),
    ("true", True),
    ("on", True),
    ("True", True),
    ("YES", True),
    ("ON", True),
    ("no", False),
    ("false", False),
    ("off", False),
    ("", False),
    ("0", False),
])
def test_server_local_files_allowed(value, expected):
    app_config = MagicMock()
    app_config.get.return_value = value
    assert _server_local_files_allowed(app_config) == expected


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _pm_with_keys(key_data_list):
    key_manager = MagicMock()
    key_manager.key_store.load_all_keys.return_value = {
        str(i): kd for i, kd in enumerate(key_data_list)
    }
    return ProjectManager(app_config=MagicMock(), key_manager=key_manager)


def _write_project_config(path: str, allow_local: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    config = configparser.ConfigParser()
    config["inputs"] = {"allow_local_files": allow_local, "allow_http_files": "no"}
    with open(path, "w") as f:
        config.write(f)


# ---------------------------------------------------------------------------
# ProjectManager.get_all_project_config_paths
# ---------------------------------------------------------------------------

def test_get_all_project_config_paths_empty():
    pm = _pm_with_keys([])
    assert pm.get_all_project_config_paths() == []


def test_get_all_project_config_paths_single_key():
    pm = _pm_with_keys([
        {"config_file_paths": {"proj-a": "/p/a.ini", "proj-b": "/p/b.ini"}},
    ])
    assert sorted(pm.get_all_project_config_paths()) == ["/p/a.ini", "/p/b.ini"]


def test_get_all_project_config_paths_multiple_keys():
    pm = _pm_with_keys([
        {"config_file_paths": {"proj-a": "/p/a.ini", "proj-b": "/p/b.ini"}},
        {"config_file_paths": {"proj-c": "/p/c.ini"}},
    ])
    assert sorted(pm.get_all_project_config_paths()) == ["/p/a.ini", "/p/b.ini", "/p/c.ini"]


def test_get_all_project_config_paths_key_with_no_projects():
    pm = _pm_with_keys([
        {"config_file_paths": {}},
        {"config_file_paths": {"proj-a": "/p/a.ini"}},
    ])
    assert pm.get_all_project_config_paths() == ["/p/a.ini"]


# ---------------------------------------------------------------------------
# ProjectManager.find_project_config_path
# ---------------------------------------------------------------------------

def test_find_project_config_path_found():
    pm = _pm_with_keys([
        {"config_file_paths": {"proj-a": "/p/a.ini"}},
        {"config_file_paths": {"proj-b": "/p/b.ini"}},
    ])
    assert pm.find_project_config_path("proj-b") == "/p/b.ini"


def test_find_project_config_path_not_found():
    pm = _pm_with_keys([
        {"config_file_paths": {"proj-a": "/p/a.ini"}},
    ])
    assert pm.find_project_config_path("unknown") is None


def test_find_project_config_path_empty_store():
    pm = _pm_with_keys([])
    assert pm.find_project_config_path("anything") is None


# ---------------------------------------------------------------------------
# Cascade: disabling server local files updates every project config
# ---------------------------------------------------------------------------

def test_cascade_disable_sets_all_projects_to_no(tmp_path):
    path_a = str(tmp_path / "proj_a" / "config.ini")
    path_b = str(tmp_path / "proj_b" / "config.ini")
    path_c = str(tmp_path / "proj_c" / "config.ini")
    for path in [path_a, path_b, path_c]:
        _write_project_config(path, "yes")

    pm = _pm_with_keys([
        {"config_file_paths": {"proj-a": path_a, "proj-b": path_b}},
        {"config_file_paths": {"proj-c": path_c}},
    ])

    for config_path in pm.get_all_project_config_paths():
        ConfigUpdater.update(
            path=config_path,
            section="inputs",
            name="allow_local_files",
            value="no",
        )

    for path in [path_a, path_b, path_c]:
        config = configparser.ConfigParser()
        config.read(path)
        assert config["inputs"]["allow_local_files"] == "no", f"Failed for {path}"


def test_cascade_disable_does_not_affect_unrelated_setting(tmp_path):
    path_a = str(tmp_path / "proj_a" / "config.ini")
    _write_project_config(path_a, "yes")

    pm = _pm_with_keys([{"config_file_paths": {"proj-a": path_a}}])

    for config_path in pm.get_all_project_config_paths():
        ConfigUpdater.update(
            path=config_path,
            section="inputs",
            name="allow_local_files",
            value="no",
        )

    config = configparser.ConfigParser()
    config.read(path_a)
    assert config["inputs"]["allow_http_files"] == "no"
