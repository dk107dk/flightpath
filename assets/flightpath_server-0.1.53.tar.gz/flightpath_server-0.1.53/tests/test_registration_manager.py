import pytest
import os
from csvpath import CsvPaths
from csvpath.util.nos import Nos
from csvpath.util.file_readers import DataFileReader
from flightpath_server.registration.registration_manager import RegistrationManager
from flightpath_server.projects.project_manager import ProjectManager
from flightpath_server.config.app_config import AppConfig
from flightpath_server.keys.key_manager import KeyManager
from flightpath_server.keys.key import Key
from flightpath_server.util.config_updater import ConfigUpdater


@pytest.fixture
def registration_manager():
    path = os.path.join(
        "tests",
        "test_resources",
        "config",
        "app_config",
        "registration_manager_app_config.ini",
    )
    app_config = AppConfig(path)
    keys_path = app_config.get(section="security", name="key_file_path")
    # start from scratch
    if os.path.exists(keys_path):
        os.remove(keys_path)
    key_manager = KeyManager(app_config=app_config)
    key_data = {
        "key_name": "test admin",
        "key_owner_name": "dk",
        "key_owner_contact": "foo",
        "admin": False,
        "config_file_paths": {},
    }
    admin_uuid = key_manager.create_key(api_key=None, key=Key(**key_data))
    #
    # temp way to pass uuid around
    #
    app_config.set(section="test", name="admin_uuid", value=admin_uuid)
    project_name = "reg-mgr-tests"
    app_config.set(section="test", name="project_name", value=project_name)
    proj_manager = ProjectManager(app_config=app_config, key_manager=key_manager)
    project_config = None
    path = os.path.join(
        "tests",
        "test_resources",
        "config",
        "project_config",
        "test_registration_manager_project_config.ini",
    )
    with open(path, "r") as file:
        project_config = file.read()
    #
    # proj manager needs to load the config in a configparser, set the [config] value and
    # save. otherwise, when we load the config it will not match and we'll reload (again!)
    # to another config -- potentially a security problem, as well as wrong.
    #
    new_config_path = proj_manager.create_new_project(
        api_key=admin_uuid, name=project_name, config_str=project_config
    )
    ConfigUpdater.update(
        path=new_config_path,
        config_str=project_config,
        section="inputs",
        name="allow_local_files",
        value="True",
    )
    #
    # setup the csvpaths with config using the project config path
    #
    csvpaths = CsvPaths()
    csvpaths.config.set_config_path_and_reload(new_config_path)
    return RegistrationManager(csvpaths=csvpaths, app_config=app_config)


def test_check_file_location(registration_manager):
    app_config = registration_manager.app_config
    assert (
        app_config.get(
            section="security", name="localhost_files_allowed", default="False"
        )
        .strip()
        .lower()
        == "true"
    )
    registration_manager.check_file_location("/path/to/local/file")
    app_config.set(section="security", name="localhost_files_allowed", value="False")
    with pytest.raises(ValueError):
        registration_manager.check_file_location("/path/to/local/file")
    registration_manager.check_file_location("s3://path/to/local/file")
    registration_manager.check_file_location("sftp://path/to/local/file")
    registration_manager.check_file_location("azure://path/to/local/file")
    registration_manager.check_file_location("gcs://path/to/local/file")


def test_register_named_file(registration_manager):
    named_file_name = "test"
    file_location = os.path.join("tests", "test_resources", "files", "dummy_file.csv")
    template = None
    ret = registration_manager.register_file(
        named_file_name=named_file_name, file_location=file_location, template=template
    )
    assert ret
    assert "success" in ret
    assert ret["success"] is True
    assert registration_manager.csvpaths.file_manager.has_named_file(named_file_name)
    #
    # need to prove that the named-file ended up in the files location we expect.
    #
    config = registration_manager.csvpaths.config
    path = os.path.join(config.get(section="inputs", name="files"), named_file_name)
    assert os.path.exists(path)


def test_find_named_file(registration_manager):
    named_file_name = "test"
    file_location = os.path.join("tests", "test_resources", "files", "dummy_file.csv")
    template = None
    ret = registration_manager.register_file(
        named_file_name=named_file_name, file_location=file_location, template=template
    )
    assert ret
    assert "success" in ret
    assert ret["success"] is True
    assert "reference" in ret
    assert registration_manager.csvpaths.file_manager.has_named_file(named_file_name)
    #
    # need to prove that the named-file ended up in the files location we expect.
    #
    files = registration_manager.find_files(ret["reference"])
    assert files
    assert "files" in files
    files = files["files"]
    assert isinstance(files, list)
    assert len(files) == 1
    nos = Nos(files[0])
    assert nos.exists()
    contents = None
    with DataFileReader(files[0]) as file:
        contents = file.read()
    found = registration_manager.get_file(ret["reference"])
    assert found
    assert "file" in found
    found = found["file"]
    assert isinstance(found, bytes)
    found = found.decode("utf-8")
    assert found == contents


def test_register_named_paths(registration_manager):
    named_paths_name = "test_path"
    file_location = os.path.join(
        "tests", "test_resources", "csvpaths", "dummy_paths.csvpaths"
    )
    template = None
    ret = registration_manager.register_csvpath_group(
        named_paths_name=named_paths_name,
        file_location=file_location,
        template=template,
    )
    assert ret
    assert "success" in ret
    assert ret["success"] is True
    assert "reference" in ret
    assert registration_manager.csvpaths.paths_manager.has_named_paths(named_paths_name)
    #
    # need to prove that the named-file ended up in the files location we expect.
    #
    config = registration_manager.csvpaths.config
    path = os.path.join(config.get(section="inputs", name="csvpaths"), named_paths_name)
    assert os.path.exists(path)


def test_register_bad_named_paths(registration_manager):
    file_location = os.path.join(
        "tests", "test_resources", "csvpaths", "dummy_paths.csvpathss"
    )
    ret = registration_manager.register_csvpath_group(
        named_paths_name="bad", file_location=file_location, template=None
    )
    assert ret
    assert "success" in ret
    assert ret["success"] is False
    assert "errors" in ret
    assert not registration_manager.csvpaths.paths_manager.has_named_paths("bad")
