from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, call, patch

import pytest
from fastapi import HTTPException

from flightpath_server.runs.run import Run
from flightpath_server.v2.routers.runs import StartRunRequest, RunMethod, _execute_run, _run_to_status


def _make_run(**overrides) -> Run:
    defaults = dict(
        run_uuid="test-uuid",
        start_time=None,
        end_time=None,
        csvpaths=None,
        run_method="collect_paths",
        pathsname="my-validation",
        filename="my-file",
        template=None,
        api_key="hashed-key",
        result_reference=None,
        project_name="my-project",
        config_path="/tmp/config.ini",
    )
    defaults.update(overrides)
    return Run(**defaults)


# ---------------------------------------------------------------------------
# _run_to_status
# ---------------------------------------------------------------------------

def test_run_to_status_field_mapping():
    run = _make_run()
    status = _run_to_status(run)

    assert status.run_uuid == "test-uuid"
    assert status.validation_name == "my-validation"   # pathsname → validation_name
    assert status.file_name == "my-file"                # filename → file_name
    assert status.project_name == "my-project"
    assert status.run_method == "collect_paths"
    assert status.start_time is None
    assert status.end_time is None
    assert status.result_reference is None


def test_run_to_status_completed_run():
    now = datetime.now(timezone.utc)
    ref = "$my-validation.results.2026-01-01_00-00-00"
    run = _make_run(start_time=now, end_time=now, result_reference=ref)
    status = _run_to_status(run)

    assert status.start_time == now
    assert status.end_time == now
    assert status.result_reference == ref


# ---------------------------------------------------------------------------
# _execute_run — delimiter / quotechar
# ---------------------------------------------------------------------------

def _mock_app_config():
    cfg = MagicMock()
    cfg.http_error.side_effect = lambda *, name, code, msg: HTTPException(
        status_code=code, detail=msg
    )
    return cfg


@patch("flightpath_server.v2.routers.runs.FrameworkManager")
def test_execute_run_sets_delimiter_and_quotechar(mock_fm_class):
    mock_fm = MagicMock()
    mock_fm_class.return_value = mock_fm
    mock_fm.run_manager.new_run.return_value = MagicMock()

    _execute_run(
        run_uuid="uuid-1",
        project_name="proj",
        file_name="orders",
        validation_name="check-orders",
        method="collect_paths",
        template=None,
        delimiter="|",
        quotechar="'",
        api_key="key",
        app_config=_mock_app_config(),
    )

    assert mock_fm.csvpaths.delimiter == "|"
    assert mock_fm.csvpaths.quotechar == "'"


@patch("flightpath_server.v2.routers.runs.FrameworkManager")
def test_execute_run_skips_delimiter_quotechar_when_none(mock_fm_class):
    mock_fm = MagicMock()
    mock_fm_class.return_value = mock_fm
    mock_fm.run_manager.new_run.return_value = MagicMock()

    _execute_run(
        run_uuid="uuid-2",
        project_name="proj",
        file_name="orders",
        validation_name="check-orders",
        method="collect_paths",
        template=None,
        delimiter=None,
        quotechar=None,
        api_key="key",
        app_config=_mock_app_config(),
    )

    # Neither attribute should have been explicitly assigned
    for attr_call in mock_fm.csvpaths.mock_calls:
        assert "delimiter" not in str(attr_call) or "=" not in str(attr_call)
        assert "quotechar" not in str(attr_call) or "=" not in str(attr_call)
    assert mock_fm.csvpaths.delimiter != "|"
    assert mock_fm.csvpaths.quotechar != "'"


@patch("flightpath_server.v2.routers.runs.FrameworkManager")
def test_execute_run_passes_template_to_do_run(mock_fm_class):
    mock_fm = MagicMock()
    mock_fm_class.return_value = mock_fm
    fake_run = MagicMock()
    mock_fm.run_manager.new_run.return_value = fake_run

    _execute_run(
        run_uuid="uuid-3",
        project_name="proj",
        file_name="orders",
        validation_name="check-orders",
        method="collect_paths",
        template=":year/:run_dir",
        delimiter=None,
        quotechar=None,
        api_key="key",
        app_config=_mock_app_config(),
    )

    _, kwargs = mock_fm.run_manager.new_run.call_args
    assert kwargs["template"] == ":year/:run_dir"
    mock_fm.run_manager.do_run.assert_called_once_with(fake_run)


# ---------------------------------------------------------------------------
# start_run — file_template vs run_template split
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
@patch("flightpath_server.v2.routers.runs._fm")
async def test_register_and_run_uses_file_template_not_run_template(mock_fm_ctx):
    mock_fm = MagicMock()
    mock_fm.register_file.return_value = {"success": True, "reference": "$orders.files.last"}
    mock_fm_ctx.return_value.__enter__ = MagicMock(return_value=mock_fm)
    mock_fm_ctx.return_value.__exit__ = MagicMock(return_value=False)

    background_tasks = MagicMock()
    app_config = _mock_app_config()

    from flightpath_server.v2.routers.runs import start_run
    request = StartRunRequest(
        project_name="proj",
        file_name="orders",
        validation_name="check-orders",
        file_location="/data/orders.csv",
        file_template=":filename",
        run_template=":year/:run_dir",
    )

    result = await start_run(
        request=request,
        background_tasks=background_tasks,
        api_key="key",
        app_config=app_config,
    )

    _, kwargs = mock_fm.register_file.call_args
    assert kwargs["template"] == ":filename"        # file_template goes to register
    assert kwargs["template"] != ":year/:run_dir"   # run_template does NOT go to register

    _, bg_kwargs = background_tasks.add_task.call_args
    assert bg_kwargs["template"] == ":year/:run_dir"  # run_template goes to the run
    assert bg_kwargs["template"] != ":filename"        # file_template does NOT go to the run


@pytest.mark.asyncio
@patch("flightpath_server.v2.routers.runs._fm")
async def test_register_and_run_returns_both_references(mock_fm_ctx):
    mock_fm = MagicMock()
    mock_fm.register_file.return_value = {
        "success": True,
        "reference": "$orders.files.2026-06-12:last",
    }
    mock_fm_ctx.return_value.__enter__ = MagicMock(return_value=mock_fm)
    mock_fm_ctx.return_value.__exit__ = MagicMock(return_value=False)

    background_tasks = MagicMock()

    from flightpath_server.v2.routers.runs import start_run
    request = StartRunRequest(
        project_name="proj",
        file_name="orders",
        validation_name="check-orders",
        file_location="/data/orders.csv",
    )

    result = await start_run(
        request=request,
        background_tasks=background_tasks,
        api_key="key",
        app_config=_mock_app_config(),
    )

    assert result.run_uuid is not None
    assert result.registration_reference == "$orders.files.2026-06-12:last"


@pytest.mark.asyncio
async def test_run_only_returns_no_registration_reference():
    background_tasks = MagicMock()

    from flightpath_server.v2.routers.runs import start_run
    request = StartRunRequest(
        project_name="proj",
        file_name="orders",
        validation_name="check-orders",
    )

    result = await start_run(
        request=request,
        background_tasks=background_tasks,
        api_key="key",
        app_config=_mock_app_config(),
    )

    assert result.run_uuid is not None
    assert result.registration_reference is None
