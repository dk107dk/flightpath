import requests
import os
import json
import shutil
from csvpath.util.nos import Nos
from configparser import ConfigParser


BASE = "http://localhost:8000"
KEY = None

#
#
# this sequence of calls is based on the RapidAPI manual tests. it
# attempts to check things that I would check by hand after each request.
# some additional work required!
#
# running this class will delete your local flightpath server. the
# server should be running and listening on localhost:8000, or change
# the BASE property.
#
#


def ping():
    try:
        response = requests.get(
            url=BASE,
            headers={
                "Content-Type": "application/json",
            },
        )
        print(
            "Response HTTP Status Code: {status_code}".format(
                status_code=response.status_code
            )
        )
        print("Response HTTP Response Body: {content}".format(content=response.content))
    except requests.exceptions.RequestException:
        print("HTTP Request failed")


def new_key() -> str:
    try:
        response = requests.post(
            url=f"{BASE}/admin/new_key",
            headers={
                "Content-Type": "application/json",
            },
            data=json.dumps(
                {
                    "key_owner_name": "david",
                    "key_name": "test",
                    "key_owner_contact": "call",
                }
            ),
        )
        print(
            "Response HTTP Status Code: {status_code}".format(
                status_code=response.status_code
            )
        )
        print("Response HTTP Response Body: {content}".format(content=response.content))
        if response.status_code != 200:
            raise RuntimeError(
                f"Request failed with {response.status_code}: {response.content}"
            )
        return json.loads(response.content).get("api_key")
    except requests.exceptions.RequestException:
        print("HTTP Request failed")


def new_project():
    try:
        response = requests.post(
            url=f"{BASE}/projects/new_project",
            headers={
                "Content-Type": "application/json",
                "access_token": KEY,
            },
            data=json.dumps({"name": "first_proj"}),
        )
        print(
            "Response HTTP Status Code: {status_code}".format(
                status_code=response.status_code
            )
        )
        print("Response HTTP Response Body: {content}".format(content=response.content))
        if response.status_code != 200:
            raise RuntimeError(
                f"Request failed with {response.status_code}: {response.content}"
            )
    except requests.exceptions.RequestException:
        print("HTTP Request failed")


def get_project_config():
    try:
        response = requests.post(
            url=f"{BASE}/projects/get_project_config",
            headers={
                "access_token": KEY,
                "Content-Type": "application/json",
            },
            data=json.dumps({"name": "first_proj"}),
        )
        print(
            "Response HTTP Status Code: {status_code}".format(
                status_code=response.status_code
            )
        )
        # print('Response HTTP Response Body: {content}'.format(content=response.content))
        if response.status_code != 200:
            raise RuntimeError(
                f"Request failed with {response.status_code}: {response.content}"
            )
        return response.content
    except requests.exceptions.RequestException:
        print("HTTP Request failed")


def set_project_config():
    try:
        response = requests.post(
            url=f"{BASE}/projects/set_project_config",
            headers={
                "Content-Type": "application/json",
                "access_token": KEY,
            },
            data=json.dumps(
                {
                    "name": "first_proj",
                    "config_str": """
[logging]
log_file = logs/csvpath.log
csvpath = info
csvpaths = info
log_files_to_keep = 100
log_file_size = 50000000
handler = file

[extensions]
csvpath_files = None
csv_files = csv, tsv, dat, tab, psv, ssv

[errors]
csvpath = print,fail,collect
csvpaths = print,collect
use_format = full
pattern = {time}:{file}:{line}:{paths}:{instance}:{chain}:  {message}

[config]
path = config/config.ini
allow_var_sub = yes
var_sub_source = config/env.json

[server]
host =
api_key =

[functions]
imports =

[cache]
path = cache
use_cache = yes

[results]
archive = archive
transfers = transfers

[inputs]
files = inputs/named_files
csvpaths = inputs/named_paths
on_unmatched_file_fingerprints = halt
allow_http_files = no
allow_local_files = no

[listeners]
groups = default, otlp
webhook.results = from csvpath.managers.integrations.webhook.webhook_results_listener import WebhookResultsListener
scripts.results = from csvpath.managers.integrations.scripts.scripts_results_listener import ScriptsResultsListener
sql.file = from csvpath.managers.integrations.sql.sql_file_listener import SqlFileListener
sql.paths = from csvpath.managers.integrations.sql.sql_paths_listener import SqlPathsListener
sql.result = from csvpath.managers.integrations.sql.sql_result_listener import SqlResultListener
sql.results = from csvpath.managers.integrations.sql.sql_results_listener import SqlResultsListener
sqlite.results = from csvpath.managers.integrations.sqlite.sqlite_results_listener import SqliteResultsListener
sqlite.result = from csvpath.managers.integrations.sqlite.sqlite_result_listener import SqliteResultListener
default.file = from csvpath.managers.files.files_listener import FilesListener
default.paths = from csvpath.managers.paths.paths_listener import PathsListener
otlp.result = from csvpath.managers.integrations.otlp.otlp_result_listener import OpenTelemetryResultListener
otlp.results = from csvpath.managers.integrations.otlp.otlp_results_listener import OpenTelemetryResultsListener
otlp.errors = from csvpath.managers.integrations.otlp.otlp_error_listener import OpenTelemetryErrorListener
otlp.paths = from csvpath.managers.integrations.otlp.otlp_paths_listener import OpenTelemetryPathsListener
otlp.file = from csvpath.managers.integrations.otlp.otlp_file_listener import OpenTelemetryFileListener
sftp.results = from csvpath.managers.integrations.sftp.sftp_sender import SftpSender
sftpplus.paths = from csvpath.managers.integrations.sftpplus.sftpplus_listener import SftpPlusListener
ckan.results = from csvpath.managers.integrations.ckan.ckan_listener import CkanListener
openlineage.file = from csvpath.managers.integrations.ol.file_listener_ol import OpenLineageFileListener
openlineage.paths = from csvpath.managers.integrations.ol.paths_listener_ol import OpenLineagePathsListener
openlineage.result = from csvpath.managers.integrations.ol.result_listener_ol import OpenLineageResultListener
openlineage.results = from csvpath.managers.integrations.ol.results_listener_ol import OpenLineageResultsListener
slack.file = from csvpath.managers.integrations.slack.sender import SlackSender
slack.paths = from csvpath.managers.integrations.slack.sender import SlackSender
slack.result = from csvpath.managers.integrations.slack.sender import SlackSender
slack.results = from csvpath.managers.integrations.slack.sender import SlackSender

[otlp]

[aws]

[azure]

[gcs]

[sqlite]
db = archive/csvpath.db

[sql]
dialect =
connection_string = sqlite:///archive/csvpath-sqlite.db

[sftp]
server = 192.168.73.2
port = 2022
username = python
password = example-password

[sftpplus]
admin_username = SFTPPLUS_ADMIN_USERNAME
admin_password = SFTPPLUS_ADMIN_PASSWORD
api_url = https://localhost:10020/json
scripts_dir =
execute_timeout = 300
mailbox_user = mailbox
mailbox_password = SFTPPLUS_MAILBOX_PASSWORD
server = SFTPPLUS_SERVER
port = SFTPPLUS_PORT

[ckan]
server = http://localhost:80
api_token =

[openlineage]
base_url = http://localhost:5000
endpoint = api/v1/lineage
api_key =
timeout = 5
verify = False

[slack]
webhook_url =

[scripts]
run_scripts = no
shell = /bin/bash

[marquez]
base_url = http://localhost:5000
endpoint = api/v1/lineage
api_key =
timeout = 5
verify = False

""",
                }
            ),
        )
        print(
            "Response HTTP Status Code: {status_code}".format(
                status_code=response.status_code
            )
        )
        print("Response HTTP Response Body: {content}".format(content=response.content))
    except requests.exceptions.RequestException:
        print("HTTP Request failed")


def set_env_file():
    try:
        response = requests.post(
            url=f"{BASE}/projects/set_env_file",
            headers={
                "Content-Type": "application/json",
                "access_token": KEY,
            },
            data=json.dumps(
                {
                    "name": "first_proj",
                    "env_str": '{"AWS_ACCESS_KEY_ID": "example-aws-access-key-id","AWS_SECRET_ACCESS_KEY": "example-aws-secret-access-key"}',
                }
            ),
        )
        print(
            "Response HTTP Status Code: {status_code}".format(
                status_code=response.status_code
            )
        )
        print("Response HTTP Response Body: {content}".format(content=response.content))
    except requests.exceptions.RequestException:
        print("HTTP Request failed")


def get_env_file():
    try:
        response = requests.post(
            url=f"{BASE}/projects/get_env_file",
            headers={
                "Content-Type": "application/json",
                "access_token": KEY,
            },
            data=json.dumps({"name": "first_proj"}),
        )
        print(
            "Response HTTP Status Code: {status_code}".format(
                status_code=response.status_code
            )
        )
        print("Response HTTP Response Body: {content}".format(content=response.content))
        return response.content
    except requests.exceptions.RequestException:
        print("HTTP Request failed")


def set_env_key1():
    try:
        response = requests.post(
            url=f"{BASE}/projects/set_env_key",
            headers={
                "Content-Type": "application/json",
                "access_token": KEY,
            },
            data=json.dumps(
                {
                    "name": "first_proj",
                    "key": "OTEL_EXPORTER_OTLP_ENDPOINT",
                    "value": "http://192.168.73.1:5080/api/default/v1/logs",
                }
            ),
        )
        print(
            "Response HTTP Status Code: {status_code}".format(
                status_code=response.status_code
            )
        )
        print("Response HTTP Response Body: {content}".format(content=response.content))
    except requests.exceptions.RequestException:
        print("HTTP Request failed")


def set_env_key2():
    try:
        response = requests.post(
            url=f"{BASE}/projects/set_env_key",
            headers={
                "Content-Type": "application/json",
                "access_token": KEY,
            },
            data=json.dumps(
                {
                    "name": "first_proj",
                    "key": "OTEL_EXPORTER_OTLP_HEADERS",
                    "value": "Authorization=Basic ZXhhbXBsZS11c2VyOmV4YW1wbGUtcGFzc3dvcmQ=,stream-name=flightpath",
                }
            ),
        )
        print(
            "Response HTTP Status Code: {status_code}".format(
                status_code=response.status_code
            )
        )
        print("Response HTTP Response Body: {content}".format(content=response.content))
    except requests.exceptions.RequestException:
        print("HTTP Request failed")


def register_file():
    try:
        response = requests.post(
            url=f"{BASE}/csvpath/register_file",
            headers={
                "Content-Type": "application/json",
                "access_token": KEY,
            },
            data=json.dumps(
                {
                    "name": "projects",
                    "file_location": "sftp://192.168.1.152:2022/projects.csv",
                    "project_name": "first_proj",
                }
            ),
        )
        print(
            "Response HTTP Status Code: {status_code}".format(
                status_code=response.status_code
            )
        )
        print("Response HTTP Response Body: {content}".format(content=response.content))
    except requests.exceptions.RequestException:
        print("HTTP Request failed")


def register_csvpath_group():
    try:
        response = requests.post(
            url=f"{BASE}/csvpath/register_csvpath_group",
            headers={
                "Content-Type": "application/json",
                "access_token": KEY,
            },
            data=json.dumps(
                {
                    "name": "people",
                    "file_location": "s3://csvpath-example-1/missing_example.csvpaths",
                    "project_name": "first_proj",
                }
            ),
        )
        print(
            "Response HTTP Status Code: {status_code}".format(
                status_code=response.status_code
            )
        )
        print("Response HTTP Response Body: {content}".format(content=response.content))
    except requests.exceptions.RequestException:
        print("HTTP Request failed")


def find_registered_files():
    try:
        response = requests.post(
            url=f"{BASE}/find/find_files",
            headers={
                "Content-Type": "application/json",
                "access_token": KEY,
            },
            data=json.dumps(
                {
                    "reference": "$projects.files.a711df7d2846e8ba46125d3f7adb7aea0ede50eb20a6550fca2358628a05425b",
                    "project_name": "first_proj",
                }
            ),
        )
        print(
            "Response HTTP Status Code: {status_code}".format(
                status_code=response.status_code
            )
        )
        print("Response HTTP Response Body: {content}".format(content=response.content))
    except requests.exceptions.RequestException:
        print("HTTP Request failed")


def get_registered_file():
    try:
        response = requests.post(
            url=f"{BASE}/find/get_file",
            headers={
                "Content-Type": "application/json",
                "access_token": KEY,
            },
            data=json.dumps(
                {
                    "reference": "$projects.files.a711df7d2846e8ba46125d3f7adb7aea0ede50eb20a6550fca2358628a05425b",
                    "project_name": "first_proj",
                }
            ),
        )
        print(
            "Response HTTP Status Code: {status_code}".format(
                status_code=response.status_code
            )
        )
        print("Response HTTP Response Body: {content}".format(content=response.content))
    except requests.exceptions.RequestException:
        print("HTTP Request failed")


def register_and_run():
    try:
        response = requests.post(
            url=f"{BASE}/csvpath/register_and_run",
            headers={
                "Content-Type": "application/json",
                "access_token": KEY,
            },
            data=json.dumps(
                {
                    "csvpaths_group_name": "people",
                    "method": "collect_paths",
                    "file_name": "projects",
                    "project_name": "first_proj",
                    "file_location": "sftp://192.168.1.152:2022/projects.csv",
                }
            ),
        )
        print(
            "Response HTTP Status Code: {status_code}".format(
                status_code=response.status_code
            )
        )
        print("Response HTTP Response Body: {content}".format(content=response.content))
    except requests.exceptions.RequestException:
        print("HTTP Request failed")


def find_results():
    try:
        response = requests.post(
            url=f"{BASE}/find/find_results",
            headers={
                "Content-Type": "application/json",
                "access_token": KEY,
            },
            data=json.dumps(
                {
                    "reference": "$people.results.2025-10-:first",
                    "project_name": "first_proj",
                }
            ),
        )
        print(
            "Response HTTP Status Code: {status_code}".format(
                status_code=response.status_code
            )
        )
        print("Response HTTP Response Body: {content}".format(content=response.content))
    except requests.exceptions.RequestException:
        print("HTTP Request failed")


def get_project_file():
    try:
        response = requests.post(
            url=f"{BASE}/projects/get_file",
            headers={
                "Content-Type": "application/json",
                "access_token": KEY,
            },
            data=json.dumps({"name": "first_proj", "file_path": "logs/csvpath.log"}),
        )
        print(
            "Response HTTP Status Code: {status_code}".format(
                status_code=response.status_code
            )
        )
        print("Response HTTP Response Body: {content}".format(content=response.content))
    except requests.exceptions.RequestException:
        print("HTTP Request failed")


def get_run_metadata():
    try:
        response = requests.post(
            url=f"{BASE}/csvpath/get_run_metadata",
            headers={
                "Content-Type": "application/json",
                "access_token": KEY,
            },
            data=json.dumps(
                {
                    "run_reference": "$people.results.2025-10-:last",
                    "project_name": "first_proj",
                }
            ),
        )
        print(
            "Response HTTP Status Code: {status_code}".format(
                status_code=response.status_code
            )
        )
        print("Response HTTP Response Body: {content}".format(content=response.content))
    except requests.exceptions.RequestException:
        print("HTTP Request failed")


if __name__ == "__main__":
    print("\ndeleting server assets")
    server_dir = os.path.expanduser("~/FlightPathServer")
    shutil.rmtree(server_dir)
    #
    print("\nping")
    #
    # the ping just has to not error
    #
    ping()
    #
    # the KEY needs to exist. and it will need to work for the rest
    # of the manual tests.
    #
    print("\nnew key")
    KEY = new_key()
    assert KEY
    #
    #
    # create a new project. we need to see the project dir created with
    # a config dir, config.ini, and env.json.
    #
    print("\nnew project")
    new_project()
    projects_dir = os.path.join(server_dir, "projects")
    nos = Nos(projects_dir)
    assert nos.exists()
    assert len(nos.listdir()) == 1
    key_dir = os.path.join(projects_dir, nos.listdir()[0])
    project_dir = os.path.join(key_dir, "first_proj")
    config_dir = os.path.join(project_dir, "config")
    config_path = os.path.join(config_dir, "config.ini")
    env_path = os.path.join(config_dir, "env.json")
    assert Nos(config_path).exists()
    assert Nos(env_path).exists()
    config = ConfigParser()
    config.read(config_path)
    assert config["config"]["path"] == config_path
    #
    #
    # get the project config. its [config]path must match the
    # project's config file path
    #
    print("\nget project config")
    s = get_project_config()
    s = s.decode("utf-8")
    s = s.replace("\\n", "\n")
    s = s.strip()
    s = s.lstrip('"').rstrip('"')
    config2 = ConfigParser()
    config2.read_string(s)
    assert config2["config"]["path"] == config_path
    files = config2["inputs"]["files"]
    paths = config2["inputs"]["csvpaths"]
    #
    #
    # set the project's config. the config we set has different
    # [inputs] file and csvpaths. we need to get the config again and
    # see that change happened
    #
    print("\nset project config")
    set_project_config()
    print("\nget project config 2")
    s = get_project_config()
    s = s.decode("utf-8")
    s = s.replace("\\n", "\n")
    s = s.strip()
    s = s.lstrip('"').rstrip('"')
    config2 = ConfigParser()
    config2.read_string(s)
    assert config2["inputs"]["files"] == files
    assert config2["inputs"]["csvpaths"] == paths

    #
    #
    # get the default env.json. it must be {}
    #
    e = get_env_file()
    assert e
    e = e.decode("utf-8")
    e = e.strip()
    e = e.lstrip('"').rstrip('"')
    d = json.loads(e)
    assert len(d) == 0
    assert isinstance(d, dict)

    #
    #
    # set the env.json. we add AWS keys. they must be present after another
    # get.
    #
    set_env_file()
    e = get_env_file()
    assert e
    e = e.decode("utf-8")
    e = e.strip()
    e = e.lstrip('"').rstrip('"')
    e = e.replace("\\", "")
    d = json.loads(e)
    assert len(d) == 2
    assert isinstance(d, dict)
    assert d.get("AWS_ACCESS_KEY_ID")

    set_env_key1()
    set_env_key2()

    """
    set_env_key1
    set_env_key2
    register_file()
    register_csvpath_group()
    find_registered_files()
    get_registered_file()
    register_and_run()
    find_results()
    get_project_file()
    get_run_metadata()
    """
