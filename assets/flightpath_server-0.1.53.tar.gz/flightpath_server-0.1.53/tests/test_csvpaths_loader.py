import os
import pytest
from unittest.mock import MagicMock, patch
from flightpath_server.config.app_config import AppConfig
from flightpath_server.util.csvpaths_loader import CsvPathsLoader
from flightpath_server.keys.key_manager import KeyManager
from flightpath_server.projects.project_manager import ProjectManager
from flightpath_server.keys.key import Key


def test_csvpaths_loader():
    path = os.path.join(
        "tests",
        "test_resources",
        "config",
        "app_config",
        "csvpaths_loader_app_config.ini",
    )
    app_config = AppConfig(path)
    key_file = app_config.get(section="security", name="key_file_path")
    if os.path.exists(key_file):
        os.remove(key_file)

    key_manager = KeyManager(app_config=app_config)
    key_data = {
        "key_name": "test user",
        "key_owner_name": "dk",
        "key_owner_contact": "foo",
        "admin": False,
        "config_file_paths": {},
    }
    api_key = key_manager.create_key(key=Key(**key_data))
    assert api_key

    proj_manager = ProjectManager(app_config=app_config, key_manager=key_manager)
    projects = os.path.expanduser("~/FlightPathServer/projects")
    project_name = "my-new-config"
    config_str = None
    with open(
        os.path.join(
            "tests",
            "test_resources",
            "config",
            "project_config",
            "csvpaths_loader_config.ini",
        ),
        "r",
    ) as file:
        config_str = file.read()
    key_data = key_manager.get_key_data(api_key)
    assert len(key_data.config_file_paths) == 0

    proj_manager.create_new_project(
        api_key=api_key, name=project_name, config_str=config_str
    )
    hash_key = key_manager.hash_key(api_key)
    path = os.path.join(projects, hash_key, project_name, "config", "config.ini")
    assert os.path.exists(path)

    csvpaths = CsvPathsLoader.get_csvpaths(
        app_config=app_config, api_key=api_key, project_name=project_name
    )
    files = csvpaths.config.get(section="inputs", name="files")
    assert files
    assert files.endswith("hey/ho!")


# ---------------------------------------------------------------------------
# Error paths — guard clauses
# ---------------------------------------------------------------------------

def test_none_app_config_raises():
    with pytest.raises(ValueError, match="App config cannot be None"):
        CsvPathsLoader.get_csvpaths(app_config=None, api_key="key", project_name="proj")


def test_none_api_key_raises():
    with pytest.raises(ValueError, match="Api key cannot be None"):
        CsvPathsLoader.get_csvpaths(app_config=MagicMock(), api_key=None, project_name="proj")


def test_none_project_name_raises():
    with pytest.raises(ValueError, match="Project name cannot be None"):
        CsvPathsLoader.get_csvpaths(app_config=MagicMock(), api_key="key", project_name=None)


def test_invalid_key_raises():
    with patch("flightpath_server.util.csvpaths_loader.KeyManager") as MockKM:
        mock_km = MagicMock()
        mock_km.get_key_data.return_value = None
        MockKM.return_value = mock_km
        with pytest.raises(ValueError, match="Invalid key"):
            CsvPathsLoader.get_csvpaths(
                app_config=MagicMock(), api_key="bad-key", project_name="proj"
            )


def test_unknown_project_name_raises():
    with patch("flightpath_server.util.csvpaths_loader.KeyManager") as MockKM:
        mock_km = MagicMock()
        key_data = MagicMock()
        key_data.config_file_paths = {"other-project": "/some/path"}
        mock_km.get_key_data.return_value = key_data
        MockKM.return_value = mock_km
        with pytest.raises(ValueError, match="Unknown project name"):
            CsvPathsLoader.get_csvpaths(
                app_config=MagicMock(), api_key="good-key", project_name="missing-project"
            )
