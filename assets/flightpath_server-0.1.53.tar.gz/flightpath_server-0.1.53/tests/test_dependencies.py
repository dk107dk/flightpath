import pytest
from unittest.mock import MagicMock, patch
from fastapi import HTTPException
from flightpath_server.dependencies import (
    get_app_config,
    get_key_manager,
    get_api_key,
    get_optional_api_key,
    require_admin_key,
)


@pytest.fixture
def mock_app_config():
    cfg = MagicMock()
    cfg.http_error.side_effect = lambda *, name, code, msg: HTTPException(
        status_code=code, detail=msg
    )
    return cfg


@pytest.fixture
def mock_key_manager():
    return MagicMock()


# ---------------------------------------------------------------------------
# get_app_config
# ---------------------------------------------------------------------------

def test_get_app_config_missing_attribute():
    request = MagicMock()
    del request.app.state.app_config
    with pytest.raises(RuntimeError, match="AppConfig not loaded"):
        get_app_config(request)


def test_get_app_config_none_value():
    request = MagicMock()
    request.app.state.app_config = None
    with pytest.raises(RuntimeError, match="AppConfig not loaded"):
        get_app_config(request)


def test_get_app_config_returns_config():
    request = MagicMock()
    expected = MagicMock()
    request.app.state.app_config = expected
    assert get_app_config(request) is expected


# ---------------------------------------------------------------------------
# get_key_manager
# ---------------------------------------------------------------------------

def test_get_key_manager_constructs_with_app_config(mock_app_config):
    with patch("flightpath_server.dependencies.KeyManager") as MockKM:
        mock_instance = MagicMock()
        MockKM.return_value = mock_instance
        result = get_key_manager(app_config=mock_app_config)
        MockKM.assert_called_once_with(app_config=mock_app_config)
        assert result is mock_instance


# ---------------------------------------------------------------------------
# get_api_key
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_get_api_key_missing_header_raises_401(mock_app_config, mock_key_manager):
    with pytest.raises(HTTPException) as exc_info:
        await get_api_key(
            api_key_header=None,
            key_manager=mock_key_manager,
            app_config=mock_app_config,
        )
    assert exc_info.value.status_code == 401


@pytest.mark.asyncio
async def test_get_api_key_invalid_key_raises_403(mock_app_config, mock_key_manager):
    mock_key_manager.validate_key.return_value = False
    with pytest.raises(HTTPException) as exc_info:
        await get_api_key(
            api_key_header="bad-key",
            key_manager=mock_key_manager,
            app_config=mock_app_config,
        )
    assert exc_info.value.status_code == 403


@pytest.mark.asyncio
async def test_get_api_key_valid_key_returns_it(mock_app_config, mock_key_manager):
    mock_key_manager.validate_key.return_value = True
    result = await get_api_key(
        api_key_header="good-key",
        key_manager=mock_key_manager,
        app_config=mock_app_config,
    )
    assert result == "good-key"


# ---------------------------------------------------------------------------
# get_optional_api_key
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_get_optional_api_key_none_returns_none(mock_app_config, mock_key_manager):
    result = await get_optional_api_key(
        api_key_header=None,
        key_manager=mock_key_manager,
        app_config=mock_app_config,
    )
    assert result is None


@pytest.mark.asyncio
async def test_get_optional_api_key_empty_string_returns_none(mock_app_config, mock_key_manager):
    result = await get_optional_api_key(
        api_key_header="",
        key_manager=mock_key_manager,
        app_config=mock_app_config,
    )
    assert result is None


@pytest.mark.asyncio
async def test_get_optional_api_key_valid_returns_key(mock_app_config, mock_key_manager):
    mock_key_manager.validate_key.return_value = True
    result = await get_optional_api_key(
        api_key_header="good-key",
        key_manager=mock_key_manager,
        app_config=mock_app_config,
    )
    assert result == "good-key"


@pytest.mark.asyncio
async def test_get_optional_api_key_invalid_raises_403(mock_app_config, mock_key_manager):
    mock_key_manager.validate_key.return_value = False
    with pytest.raises(HTTPException) as exc_info:
        await get_optional_api_key(
            api_key_header="bad-key",
            key_manager=mock_key_manager,
            app_config=mock_app_config,
        )
    assert exc_info.value.status_code == 403


# ---------------------------------------------------------------------------
# require_admin_key
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_require_admin_key_no_key_data_raises_403(mock_app_config, mock_key_manager):
    mock_key_manager.get_key_data.return_value = None
    with pytest.raises(HTTPException) as exc_info:
        await require_admin_key(
            api_key="some-key",
            key_manager=mock_key_manager,
            app_config=mock_app_config,
        )
    assert exc_info.value.status_code == 403


@pytest.mark.asyncio
async def test_require_admin_key_non_admin_raises_403(mock_app_config, mock_key_manager):
    key_data = MagicMock()
    key_data.admin = False
    mock_key_manager.get_key_data.return_value = key_data
    with pytest.raises(HTTPException) as exc_info:
        await require_admin_key(
            api_key="some-key",
            key_manager=mock_key_manager,
            app_config=mock_app_config,
        )
    assert exc_info.value.status_code == 403


@pytest.mark.asyncio
async def test_require_admin_key_admin_passes(mock_app_config, mock_key_manager):
    key_data = MagicMock()
    key_data.admin = True
    mock_key_manager.get_key_data.return_value = key_data
    # Should not raise
    await require_admin_key(
        api_key="admin-key",
        key_manager=mock_key_manager,
        app_config=mock_app_config,
    )
