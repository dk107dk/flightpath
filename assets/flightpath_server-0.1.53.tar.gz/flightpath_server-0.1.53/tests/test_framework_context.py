import pytest
from unittest.mock import MagicMock, patch
from fastapi import HTTPException
from flightpath_server.routers.framework_context import fm_context

_FM_TARGET = "flightpath_server.routers.framework_context.FrameworkManager"


@pytest.fixture
def app_config():
    cfg = MagicMock()
    cfg.http_error.side_effect = lambda *, name, code, msg: HTTPException(
        status_code=code, detail=msg
    )
    return cfg


# ---------------------------------------------------------------------------
# Happy path
# ---------------------------------------------------------------------------

def test_yields_framework_manager(app_config):
    with patch(_FM_TARGET) as MockFM:
        mock_fm = MagicMock()
        MockFM.return_value = mock_fm
        with fm_context("key", "proj", app_config) as result:
            assert result is mock_fm


# ---------------------------------------------------------------------------
# HTTPException passes through unchanged
# ---------------------------------------------------------------------------

def test_http_exception_reraises_as_is(app_config):
    with patch(_FM_TARGET):
        original = HTTPException(status_code=404, detail="not found")
        with pytest.raises(HTTPException) as exc_info:
            with fm_context("key", "proj", app_config):
                raise original
        assert exc_info.value is original
        assert exc_info.value.status_code == 404


# ---------------------------------------------------------------------------
# ValueError → 403
# ---------------------------------------------------------------------------

def test_value_error_raises_403(app_config):
    with patch(_FM_TARGET):
        with pytest.raises(HTTPException) as exc_info:
            with fm_context("key", "proj", app_config):
                raise ValueError("bad input")
        assert exc_info.value.status_code == 403
        assert "bad input" in exc_info.value.detail


def test_value_error_calls_dump_info(app_config):
    with patch(_FM_TARGET):
        try:
            with fm_context("key", "proj", app_config):
                raise ValueError("oops")
        except HTTPException:
            pass
        app_config.dump_info_if.assert_called_once()


# ---------------------------------------------------------------------------
# Unexpected exception → 500
# ---------------------------------------------------------------------------

def test_unexpected_exception_raises_500(app_config):
    with patch(_FM_TARGET):
        with pytest.raises(HTTPException) as exc_info:
            with fm_context("key", "proj", app_config):
                raise RuntimeError("something broke")
        assert exc_info.value.status_code == 500
        assert "something broke" in exc_info.value.detail


def test_unexpected_exception_calls_dump_info(app_config):
    with patch(_FM_TARGET):
        try:
            with fm_context("key", "proj", app_config):
                raise RuntimeError("boom")
        except HTTPException:
            pass
        app_config.dump_info_if.assert_called_once()


# ---------------------------------------------------------------------------
# fm is None when FrameworkManager constructor raises (error before yield)
# ---------------------------------------------------------------------------

def test_construction_failure_passes_none_csvpaths(app_config):
    with patch(_FM_TARGET) as MockFM:
        MockFM.side_effect = ValueError("Invalid API Key None")
        with pytest.raises(HTTPException) as exc_info:
            with fm_context("bad-key", "proj", app_config):
                pass
        assert exc_info.value.status_code == 403
        # dump_info_if should have been called with csvpaths=None
        call_kwargs = app_config.dump_info_if.call_args.kwargs
        assert call_kwargs["csvpaths"] is None
