import pytest
import os
from csvpath import CsvPaths
from csvpath.util.file_readers import DataFileReader
from flightpath_server.runs.run_manager import RunManager
from flightpath_server.runs.results_manager import ResultsManager
from flightpath_server.projects.project_manager import ProjectManager
from flightpath_server.registration.registration_manager import RegistrationManager
from flightpath_server.keys.key import Key
from flightpath_server.keys.key_manager import KeyManager
from flightpath_server.config.app_config import AppConfig
from flightpath_server.util.config_updater import ConfigUpdater


@pytest.fixture
def results_manager(tmp_path):
    path = os.path.join(
        "tests",
        "test_resources",
        "config",
        "app_config",
        "results_manager_app_config.ini",
    )
    app_config = AppConfig(path)
    keys_path = app_config.get(section="security", name="key_file_path")
    if os.path.exists(keys_path):
        os.remove(keys_path)
    key_manager = KeyManager(app_config=app_config)
    key_data = {
        "key_name": "test admin",
        "key_owner_name": "dk",
        "key_owner_contact": "foo",
        "admin": False,
        "config_file_paths": {},
    }
    admin_uuid = key_manager.create_key(api_key=None, key=Key(**key_data))

    project_name = "results-mgr-tests"
    proj_manager = ProjectManager(app_config=app_config, key_manager=key_manager)
    project_config = None
    path = os.path.join(
        "tests",
        "test_resources",
        "config",
        "project_config",
        "test_results_manager_project_config.ini",
    )
    with open(path, "r") as file:
        project_config = file.read()

    new_config_path = proj_manager.create_new_project(
        api_key=admin_uuid, name=project_name, config_str=project_config
    )
    ConfigUpdater.update(
        path=new_config_path,
        config_str=project_config,
        section="inputs",
        name="allow_local_files",
        value="True",
    )

    #
    # setup the csvpaths with config using the project config path
    #
    csvpaths = CsvPaths()
    csvpaths.config.set_config_path_and_reload(new_config_path)

    run_manager = RunManager(app_config, history_dir=str(tmp_path / "history"))

    # bag up the parts we may need
    app_config.bag["csvpaths"] = csvpaths
    app_config.bag["admin_uuid"] = admin_uuid
    app_config.bag["project_name"] = project_name
    app_config.bag["key_manager"] = key_manager

    run = run_manager.new_run(
        csvpaths=csvpaths,
        run_method="collect_paths",
        pathsname="group",
        filename="test",
        template=None,
        api_key=admin_uuid,
        project_name=project_name,
    )

    reg_mgr = RegistrationManager(csvpaths=csvpaths, app_config=app_config)
    file_location = os.path.join("tests", "test_resources", "files", "dummy_file.csv")
    result = reg_mgr.register_file(named_file_name="test", file_location=file_location)
    assert result["success"] is True

    file_location = os.path.join(
        "tests", "test_resources", "csvpaths", "dummy_paths.csvpaths"
    )
    result = reg_mgr.register_csvpath_group(
        named_paths_name="group", file_location=file_location
    )
    assert result["success"] is True

    result = run_manager.do_run(run)
    assert result["success"] is True

    app_config.bag["run"] = run
    app_config.bag["run_result"] = result

    return ResultsManager(app_config)


def test_get_run_path(results_manager):
    app_config = results_manager.app_config
    api_key = app_config.bag["admin_uuid"]
    project_name = app_config.bag["project_name"]
    result = results_manager.get_run_path(
        api_key=api_key,
        project_name=project_name,
        run_reference="$group.results.:last",
    )
    assert result["success"] is True
    assert "path" in result
    assert result["path"]


def test_get_run_path_not_found(results_manager):
    app_config = results_manager.app_config
    api_key = app_config.bag["admin_uuid"]
    project_name = app_config.bag["project_name"]
    result = results_manager.get_run_path(
        api_key=api_key,
        project_name=project_name,
        run_reference="$nonexistent.results.:last",
    )
    assert result["success"] is False
    assert "errors" in result


def test_get_run_results_not_found(results_manager):
    app_config = results_manager.app_config
    api_key = app_config.bag["admin_uuid"]
    project_name = app_config.bag["project_name"]
    #
    # the get errors/metadata/printouts methods throw TypeError on attempting to iterate None.
    # CsvPath's ResultsManager has been updated to return None when the reference/name is not
    # found
    #
    result = results_manager.get_run_errors(
        api_key=api_key, project_name=project_name, run_reference="bad ref"
    )
    assert result["success"] is False
    assert len(result["errors"]) == 1


def test_find_results(results_manager):
    app_config = results_manager.app_config
    project_name = app_config.bag["project_name"]
    api_key = app_config.bag["admin_uuid"]
    result = app_config.bag["run_result"]
    reference = result["reference"]
    reference = f"{reference}.print"
    print(f"reference: {reference}")
    results = results_manager.find_results(
        api_key=api_key, project_name=project_name, reference=reference
    )
    assert results
    assert "success" in results
    assert results["success"] is True
    assert "results" in results
    results = results["results"]
    assert isinstance(results, list)
    assert len(results) == 1
    path = results[0]
    results = app_config.bag["csvpaths"].results_manager.get_named_results(reference)
    assert results
    if isinstance(results, list):
        assert len(results) == 1
        results = results[0]
    assert results.data_file_path == path
    results = results_manager.get_result(
        api_key=api_key, project_name=project_name, reference=reference
    )
    assert results
    assert "success" in results
    assert results["success"] is True
    assert "result" in results
    contents = results["result"]
    with DataFileReader(path) as file:
        assert contents == file.read()


def test_get_run_metadata(results_manager):
    app_config = results_manager.app_config
    project_name = app_config.bag["project_name"]
    api_key = app_config.bag["admin_uuid"]
    result = app_config.bag["run_result"]
    reference = result["reference"]
    ########
    #
    # need the same test as we do with get errors in results_manager:41
    #
    result = results_manager.get_run_metadata(
        api_key=api_key, project_name=project_name, run_reference=reference
    )
    assert result["success"] is True
    assert result["metadata"] is not None
    assert "metadata" in result["metadata"]


def test_get_run_variables(results_manager):
    app_config = results_manager.app_config
    project_name = app_config.bag["project_name"]
    api_key = app_config.bag["admin_uuid"]
    result = app_config.bag["run_result"]
    reference = result["reference"]
    result = results_manager.get_run_variables(
        api_key=api_key, project_name=project_name, run_reference=reference
    )
    assert result["success"] is True
    assert result["variables"] == {"var": 5}


"""
#
# CsvPath's next release will support printout results. it cannot do it today (21 aug 2025)
#
def test_get_run_printouts_no_stream(results_manager):
    app_config = results_manager.app_config
    project_name = app_config.bag["project_name"]
    api_key = app_config.bag["admin_uuid"]
    result = app_config.bag["run_result"]
    reference = result["run_reference"]
    result = results_manager.get_run_printouts( api_key=api_key, project_name=project_name, run_reference=reference )
    print(f"test_get_run_printouts: result: {result}")
    assert result["success"] is True
    assert result["printouts"] == ["printout1"]
    #sample_run.csvpaths.results_manager.get_printouts.assert_called_with("test_ref", "default")

def test_get_run_printouts_with_stream(results_manager):
    sample_run.result_reference = "test_ref"
    run_manager.add_run(sample_run)
    sample_run.csvpaths.results_manager.get_printouts.return_value = ["printout1"]
    result = run_manager.get_run_printouts("test_ref")
    assert result["success"] is True
    assert result["printouts"] == ["printout1"]
    sample_run.csvpaths.results_manager.get_printouts.assert_called_with("test_ref", None)
"""
