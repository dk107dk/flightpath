import os
from fastapi.testclient import TestClient
from flightpath_server.main import app
import pytest

TEST_DIR = os.path.join("tests", "test_resources", "api_make_admin")
CONFIG_PATH = os.path.join(TEST_DIR, "app_config.ini")
KEYS_PATH = os.path.join(TEST_DIR, "keys.json")


@pytest.fixture(scope="function")
def setup_keys():
    os.makedirs(TEST_DIR, exist_ok=True)
    os.environ["FLIGHTPATH_SERVER_CONFIG"] = CONFIG_PATH
    os.environ["FLIGHTPATH_API_KEY_FILE"] = KEYS_PATH

    with open(CONFIG_PATH, "w") as f:
        f.write("""
[security]
localhost_files_allowed=True
key_file_path=FLIGHTPATH_API_KEY_FILE

[server]
port=8000
host=127.0.0.1

[logging]
level=debug
""")

    if os.path.exists(KEYS_PATH):
        os.remove(KEYS_PATH)

    with TestClient(app) as client:
        key_data = {
            "key_name": "initial_admin",
            "key_owner_name": "test",
            "key_owner_contact": "test@test.com",
        }
        response = client.post("/admin/new_key", json=key_data)
        assert response.status_code == 200
        admin_key = response.json()["api_key"]

        client.headers["access_token"] = admin_key
        key_data = {
            "key_name": "regular_user",
            "key_owner_name": "test",
            "key_owner_contact": "test@test.com",
        }
        response = client.post("/admin/new_key", json=key_data)
        assert response.status_code == 200
        regular_key = response.json()["api_key"]

    yield admin_key, regular_key

    key_index_path = os.path.join(TEST_DIR, "key_index.json")
    for path in (KEYS_PATH, CONFIG_PATH, key_index_path):
        if os.path.exists(path):
            os.remove(path)


def test_admin_make_admin(setup_keys):
    """Tests the /admin/make_admin_key endpoint."""
    admin_key, regular_key = setup_keys

    with TestClient(app) as client:
        client.headers["access_token"] = regular_key
        response = client.get("/admin/active_runs")
        assert response.status_code == 403

        client.headers["access_token"] = admin_key
        make_admin_data = {"api_key": regular_key}
        response = client.post("/admin/make_admin_key", json=make_admin_data)
        assert response.status_code == 200
        assert "has been made an admin key" in response.json()["message"]

        client.headers["access_token"] = regular_key
        response = client.get("/admin/active_runs")
        assert response.status_code == 200
