import os
import re
import json
import pytest
from configparser import ConfigParser
from csvpath.util.nos import Nos
from fastapi.testclient import TestClient
from flightpath_server.main import app
from flightpath_server.keys.key_manager import KeyManager

CONFIG = os.path.join(
    "tests", "test_resources", "config", "app_config", "test_api_app_config.ini"
)
FILE_LOC = os.path.join("tests", "test_resources", "files", "dummy_file.csv")
CSVPATHS_LOC = os.path.join(
    "tests", "test_resources", "csvpaths", "dummy_paths.csvpaths"
)
PROJECT_CONFIG_PATH = os.path.join(
    "tests", "test_resources", "config", "project_config", "test_api_project_config.ini"
)
PROJECT_NAME = "aproject"
FILE_NAME = "test_file"
PATHS_NAME = "test_paths"
RUN_REF = f"${PATHS_NAME}.results.:last"


@pytest.fixture(scope="module", autouse=True)
def set_env(api_keys_file):
    os.environ["FLIGHTPATH_SERVER_CONFIG"] = CONFIG
    os.environ["FLIGHTPATH_API_KEY_FILE"] = str(api_keys_file)
    if api_keys_file.exists():
        api_keys_file.unlink()


@pytest.fixture(scope="module")
def api_session(api_keys_file):
    with TestClient(app) as client:
        # create admin key
        response = client.post("/admin/new_key", json={
            "key_name": "admin",
            "key_owner_name": "dk",
            "key_owner_contact": "dk@dk.dk",
        })
        assert response.status_code == 200
        api_key = response.json()["api_key"]
        hash_key = KeyManager(app_config=app.state.app_config).hash_key(api_key)
        client.headers["access_token"] = api_key

        # create project
        with open(PROJECT_CONFIG_PATH, "r") as f:
            config_str = f.read()
        response = client.post("/projects/new_project", json={
            "name": PROJECT_NAME, "config_str": config_str,
        })
        assert response.status_code == 200

        # fetch server-side config and patch to allow local files
        response = client.post("/projects/get_project_config", json={"name": PROJECT_NAME})
        assert response.status_code == 200
        c = ConfigParser()
        c.read_string(response.json())
        c["inputs"]["allow_local_files"] = "True"
        with open(c["config"]["path"], "w") as f:
            c.write(f)

        # register file
        response = client.post("/csvpath/register_file", json={
            "project_name": PROJECT_NAME,
            "name": FILE_NAME,
            "file_location": FILE_LOC,
            "template": None,
        })
        assert response.status_code == 200
        file_ref = response.json()["reference"]

        # register csvpath group
        response = client.post("/csvpath/register_csvpath_group", json={
            "project_name": PROJECT_NAME,
            "name": PATHS_NAME,
            "file_location": CSVPATHS_LOC,
            "append": False,
            "template": None,
        })
        assert response.status_code == 200

        # register and run
        response = client.post("/csvpath/register_and_run", json={
            "project_name": PROJECT_NAME,
            "file_location": FILE_LOC,
            "file_name": FILE_NAME,
            "csvpaths_group_name": PATHS_NAME,
            "method": "collect_paths",
            "file_template": None,
            "run_template": None,
        })
        assert response.status_code == 200

        yield {
            "client": client,
            "api_key": api_key,
            "hash_key": hash_key,
            "config": c,
            "file_ref": file_ref,
        }


def test_new_key_stored(api_session, api_keys_file):
    with open(api_keys_file, "r") as f:
        keys = json.load(f)
    assert len(keys) == 1
    assert api_session["hash_key"] in keys
    assert keys[api_session["hash_key"]].get("admin") is True


def test_register_file(api_session):
    path = os.path.join(api_session["config"]["inputs"]["files"], FILE_NAME)
    assert os.path.exists(path)


def test_find_files(api_session):
    response = api_session["client"].post("/find/find_files", json={
        "reference": api_session["file_ref"],
        "project_name": PROJECT_NAME,
    })
    assert response.status_code == 200
    files = response.json()["files"]
    assert isinstance(files, list)
    assert len(files) > 0


def test_get_file(api_session):
    response = api_session["client"].post("/find/get_file", json={
        "reference": api_session["file_ref"],
        "project_name": PROJECT_NAME,
    })
    assert response.status_code == 200
    data = response.json()
    assert data.get("file")
    assert isinstance(data["file"], str)


def test_register_csvpath_group(api_session):
    path = os.path.join(api_session["config"]["inputs"]["csvpaths"], PATHS_NAME)
    assert os.path.exists(path)


def test_get_run_path_exists(api_session):
    response = api_session["client"].post("/csvpath/get_run_path", json={
        "run_reference": RUN_REF,
        "project_name": PROJECT_NAME,
    })
    assert response.status_code == 200
    assert os.path.exists(response.json()["path"])


def test_get_run_errors(api_session):
    response = api_session["client"].post("/csvpath/get_run_errors", json={
        "run_reference": RUN_REF,
        "project_name": PROJECT_NAME,
    })
    assert response.status_code == 200
    assert len(response.json()["errors"]) == 3


def test_get_run_metadata(api_session):
    response = api_session["client"].post("/csvpath/get_run_metadata", json={
        "run_reference": RUN_REF,
        "project_name": PROJECT_NAME,
    })
    assert response.status_code == 200
    metadata = response.json()["metadata"]
    assert len(metadata["metadata"]) == 4
    assert len(metadata["manifest"]) == 4
    assert len(metadata["runtime"]) == 4


def test_get_run_variables(api_session):
    response = api_session["client"].post("/csvpath/get_run_variables", json={
        "run_reference": RUN_REF,
        "project_name": PROJECT_NAME,
    })
    assert response.status_code == 200
    assert "var" in response.json()["variables"]


def test_get_run_printouts(api_session):
    response = api_session["client"].post("/csvpath/get_run_printouts", json={
        "run_reference": RUN_REF,
        "project_name": PROJECT_NAME,
    })
    assert response.status_code == 200
    assert len(response.json()["printouts"]) == 3


def test_get_result(api_session):
    response = api_session["client"].post("/find/get_result", json={
        "reference": f"${PATHS_NAME}.results.:last.print",
        "project_name": PROJECT_NAME,
    })
    assert response.status_code == 200
    result = response.json().get("result")
    assert result and isinstance(result, str)


def test_find_results(api_session):
    response = api_session["client"].post("/find/find_results", json={
        "reference": f"${PATHS_NAME}.results.:last.print",
        "project_name": PROJECT_NAME,
    })
    assert response.status_code == 200
    results = response.json()["results"]
    assert isinstance(results, list)
    assert len(results) > 0
    assert results[0].endswith("data.csv")


def test_run_path_in_archive(api_session):
    response = api_session["client"].post("/csvpath/get_run_path", json={
        "run_reference": RUN_REF,
        "project_name": PROJECT_NAME,
    })
    assert response.status_code == 200
    path = os.path.normpath(response.json()["path"])
    arch = os.path.normpath(api_session["config"]["results"]["archive"])
    assert path.startswith(arch)
    end = path[path.rfind(Nos(os.sep).sep) + 1:]
    assert re.search(r"^.*\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}(?:_\d)?", end)


def test_find_completed_runs(api_session):
    response = api_session["client"].post("/find/find_completed_runs", json={
        "reference": f"${PATHS_NAME}.results.:all",
        "project_name": PROJECT_NAME,
    })
    assert response.status_code == 200
    runs = response.json().get("runs")
    assert runs and isinstance(runs, list) and len(runs) == 1
    path = os.path.normpath(runs[0])
    arch = os.path.normpath(api_session["config"]["results"]["archive"])
    assert path.startswith(arch)
    end = path[path.rfind(Nos(os.sep).sep) + 1:]
    assert re.search(r"^.*\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}(?:_\d)?", end)
