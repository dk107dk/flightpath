import os
import json
import pytest
from fastapi.testclient import TestClient
from flightpath_server.config.app_config import AppConfig
from flightpath_server.main import app
from flightpath_server.keys.key_manager import KeyManager

CONFIG = os.path.join(
    "tests", "test_resources", "config", "app_config", "test_api_app_config.ini"
)


@pytest.fixture
def setup_env(tmp_path):
    keys_file = str(tmp_path / "keys.json")
    os.environ[AppConfig.FLIGHTPATH_SERVER_CONFIG] = CONFIG
    os.environ["FLIGHTPATH_API_KEY_FILE"] = keys_file
    yield keys_file
    os.environ.pop(AppConfig.FLIGHTPATH_SERVER_CONFIG, None)
    os.environ.pop("FLIGHTPATH_API_KEY_FILE", None)


def test_admin_new_key(setup_env):
    keys_file = setup_env

    with TestClient(app) as client:
        key_data = {
            "key_name": "admin",
            "key_owner_name": "dk",
            "key_owner_contact": "dk@dk.dk",
        }
        response = client.post("/admin/new_key", json=key_data)
        assert response.status_code == 200
        new_key = response.json()
        assert "api_key" in new_key

        keymgr = KeyManager(app_config=app.state.app_config)
        assert keys_file == keymgr.key_store.key_file
        hash_key = keymgr.hash_key(new_key["api_key"])

        client.headers["access_token"] = new_key["api_key"]

        with open(keys_file, "r") as file:
            keys = json.load(file)
            assert len(keys) == 1
            assert hash_key in keys
            assert "admin" in keys[hash_key]
            assert keys[hash_key]["admin"] is True

        with open(
            os.path.join(
                "tests",
                "test_resources",
                "config",
                "project_config",
                "test_api_project_config.ini",
            ),
            "r",
        ) as file:
            config_str = file.read()

        response = client.post("/projects/new_project", json={"name": "newproj", "config_str": config_str})
        assert response.status_code == 200

        response = client.post("/projects/get_project_names")
        assert response.status_code == 200
        names = response.json()["names"]
        assert len(names) == 1
        assert names[0] == "newproj"

        response = client.post("/projects/get_project_config", json={"name": "newproj"})
        assert response.status_code == 200
        config = response.json()
        assert config is not None
        assert config.find("[listeners]") > -1

        updated_config = """
[test]
bats = animal
[config]
path = so
[inputs]
files = many
csvpaths = paths
[results]
archive = to
transfers = fix
"""
        response = client.post(
            "/projects/set_project_config",
            json={"name": "newproj", "config_str": updated_config},
        )
        assert response.status_code == 200

        response = client.post("/projects/get_project_config", json={"name": "newproj"})
        assert response.status_code == 200
        config = response.json()
        assert config is not None
        assert config.find("bats") > -1

        response = client.post("/projects/delete_project", json={"name": "newproj"})
        assert response.status_code == 200

        response = client.post("/projects/get_project_names")
        assert response.status_code == 200
        assert len(response.json()["names"]) == 0
