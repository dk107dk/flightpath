import os
import subprocess
import time
import httpx
import signal
import pytest
from flightpath_server.keys.key_manager import KeyManager
from flightpath_server.keys.key import Key
from flightpath_server.config.app_config import AppConfig

TEST_CONFIG_DIR = os.path.join("tests", "test_resources", "api_shutdown", "config")
CONFIG_PATH = os.path.join(TEST_CONFIG_DIR, "app_config.ini")
KEYS_PATH = os.path.join(TEST_CONFIG_DIR, "keys.json")
SERVER_URL = "http://127.0.0.1:8000"


def _wait_for_server(timeout: float = 15.0, interval: float = 0.2) -> None:
    """Poll the server root until it responds or timeout expires."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            httpx.get(f"{SERVER_URL}/", timeout=1.0)
            return
        except httpx.ConnectError:
            time.sleep(interval)
    pytest.fail(f"Server did not become ready within {timeout}s")


@pytest.fixture(scope="module")
def admin_api_key():
    os.makedirs(TEST_CONFIG_DIR, exist_ok=True)
    with open(CONFIG_PATH, "w") as f:
        f.write(f"""
[security]
localhost_files_allowed=True
key_file_path={KEYS_PATH}

[server]
port=8000
host=127.0.0.1

[logging]
level=debug
""")
    if os.path.exists(KEYS_PATH):
        os.remove(KEYS_PATH)

    app_config = AppConfig(CONFIG_PATH)
    key_manager = KeyManager(app_config=app_config)
    key = Key(
        key_name="shutdown_test_admin",
        key_owner_name="test",
        key_owner_contact="test@test.com",
        admin=True,
        config_file_paths={},
    )
    api_key = key_manager.create_key(key=key)
    key_manager.is_admin(api_key)
    return api_key


def test_admin_shutdown(admin_api_key):
    """Tests the /admin/shutdown endpoint by starting a real server process."""
    server_process = None
    try:
        env = {"FLIGHTPATH_SERVER_CONFIG": CONFIG_PATH, "PATH": os.getenv("PATH")}
        server_process = subprocess.Popen(["uv", "run", "serve"], env=env)

        _wait_for_server()

        assert server_process.poll() is None, "Server process failed to start."

        with httpx.Client() as client:
            response = client.get(
                f"{SERVER_URL}/admin/shutdown",
                headers={"access_token": admin_api_key},
            )
        assert response.status_code == 200
        assert response.json() == {"message": "Server is shutting down."}

        server_process.wait(timeout=5)
        assert server_process.returncode == -signal.SIGTERM

    finally:
        if server_process and server_process.poll() is None:
            server_process.kill()
        if os.path.exists(KEYS_PATH):
            os.remove(KEYS_PATH)
        if os.path.exists(CONFIG_PATH):
            os.remove(CONFIG_PATH)
