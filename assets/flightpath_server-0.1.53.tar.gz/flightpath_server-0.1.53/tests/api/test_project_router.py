import os
import json
import pytest
from fastapi.testclient import TestClient
from flightpath_server.main import app

CONFIG = os.path.join(
    "tests", "test_resources", "config", "app_config", "test_api_app_config.ini"
)


@pytest.fixture(scope="module", autouse=True)
def set_env(api_keys_file):
    os.environ["FLIGHTPATH_SERVER_CONFIG"] = CONFIG
    os.environ["FLIGHTPATH_API_KEY_FILE"] = str(api_keys_file)


@pytest.fixture(scope="function")
def client(api_keys_file):
    if api_keys_file.exists():
        api_keys_file.unlink()

    with TestClient(app) as c:
        app.state.app_config.load()
        key_data = {
            "key_name": "admin",
            "key_owner_name": "dk",
            "key_owner_contact": "dk@dk.dk",
        }
        response = c.post("/admin/new_key", json=key_data)
        assert response.status_code == 200
        new_key = response.json()
        api_key = new_key["api_key"]
        c.headers["access_token"] = api_key

        config_str = None
        with open(
            os.path.join(
                "tests",
                "test_resources",
                "config",
                "project_config",
                "test_api_project_config.ini",
            ),
            "r",
        ) as file:
            config_str = file.read()
        project_name = "test_project_env"
        project_data = {"name": project_name, "config_str": config_str}
        response = c.post("/projects/new_project", json=project_data)
        assert response.status_code == 200

        yield c, project_name, api_key


def test_set_and_get_env_file(client):
    c, project_name, _ = client
    env_data = {"foo": "bar"}
    env_str = json.dumps(env_data)
    set_env_req = {"name": project_name, "env_str": env_str}
    response = c.post("/projects/set_env_file", json=set_env_req)
    assert response.status_code == 200

    get_env_req = {"name": project_name}
    response = c.post("/projects/get_env_file", json=get_env_req)
    assert response.status_code == 200
    retrieved_env_str = response.json()
    retrieved_env_data = json.loads(retrieved_env_str)
    assert retrieved_env_data == env_data


def test_set_env_key(client):
    c, project_name, _ = client
    set_key_req = {"name": project_name, "key": "first_key", "value": "first_value"}
    response = c.post("/projects/set_env_key", json=set_key_req)
    assert response.status_code == 200

    get_env_req = {"name": project_name}
    response = c.post("/projects/get_env_file", json=get_env_req)
    assert response.status_code == 200
    retrieved_env_data = json.loads(response.json())
    assert retrieved_env_data == {"first_key": "first_value"}

    set_key_req = {"name": project_name, "key": "second_key", "value": "second_value"}
    response = c.post("/projects/set_env_key", json=set_key_req)
    assert response.status_code == 200

    get_env_req = {"name": project_name}
    response = c.post("/projects/get_env_file", json=get_env_req)
    assert response.status_code == 200
    retrieved_env_data = json.loads(response.json())
    assert retrieved_env_data == {
        "first_key": "first_value",
        "second_key": "second_value",
    }


def test_add_and_get_file(client):
    c, project_name, _ = client
    import base64

    file_content = b"some file content"
    encoded_content = base64.b64encode(file_content).decode("utf-8")
    add_file_req = {
        "name": project_name,
        "file_path": "data/test.txt",
        "file_content": encoded_content,
    }
    response = c.post("/projects/add_file", json=add_file_req)
    assert response.status_code == 200

    get_file_req = {"name": project_name, "file_path": "data/test.txt"}
    response = c.post("/projects/get_file", json=get_file_req)
    assert response.status_code == 200
    response_data = response.json()
    decoded_content = base64.b64decode(response_data["file_content"])
    assert decoded_content == file_content


def test_add_file_size_limit(client):
    c, project_name, _ = client
    import base64

    file_content = b"a" * (1025 * 1024)
    encoded_content = base64.b64encode(file_content).decode("utf-8")
    add_file_req = {
        "name": project_name,
        "file_path": "data/large_file.txt",
        "file_content": encoded_content,
    }
    response = c.post("/projects/add_file", json=add_file_req)
    assert response.status_code == 400


def test_add_file_blacklist(client):
    c, project_name, _ = client
    import base64

    file_content = b"some content"
    encoded_content = base64.b64encode(file_content).decode("utf-8")

    add_file_req = {
        "name": project_name,
        "file_path": "config/config.ini",
        "file_content": encoded_content,
    }
    response = c.post("/projects/add_file", json=add_file_req)
    assert response.status_code == 400

    add_file_req["file_path"] = "config/env.json"
    response = c.post("/projects/add_file", json=add_file_req)
    assert response.status_code == 400


def test_get_file_blacklist(client):
    c, project_name, _ = client
    get_file_req = {"name": project_name, "file_path": "config/config.ini"}
    response = c.post("/projects/get_file", json=get_file_req)
    assert response.status_code == 400

    get_file_req["file_path"] = "config/env.json"
    response = c.post("/projects/get_file", json=get_file_req)
    assert response.status_code == 400


def test_add_file_creates_dirs(client):
    c, project_name, _ = client
    import base64

    file_content = b"some file content"
    encoded_content = base64.b64encode(file_content).decode("utf-8")
    add_file_req = {
        "name": project_name,
        "file_path": "a/b/c/d/e/f/g/test.txt",
        "file_content": encoded_content,
    }
    response = c.post("/projects/add_file", json=add_file_req)
    assert response.status_code == 200

    get_file_req = {"name": project_name, "file_path": "a/b/c/d/e/f/g/test.txt"}
    response = c.post("/projects/get_file", json=get_file_req)
    assert response.status_code == 200


def test_add_file_path_traversal(client):
    c, project_name, _ = client
    import base64

    encoded_content = base64.b64encode(b"malicious").decode("utf-8")
    traversal_paths = [
        "../other_project/config/config.ini",
        "../../FlightPathServer/config/keys.json",
        "subdir/../../other_project/secret.txt",
    ]
    for path in traversal_paths:
        response = c.post(
            "/projects/add_file",
            json={"name": project_name, "file_path": path, "file_content": encoded_content},
        )
        assert response.status_code == 400, f"Expected 400 for traversal path: {path!r}"


def test_get_file_path_traversal(client):
    c, project_name, _ = client
    traversal_paths = [
        "../other_project/config/config.ini",
        "../../FlightPathServer/config/keys.json",
        "subdir/../../other_project/secret.txt",
    ]
    for path in traversal_paths:
        response = c.post(
            "/projects/get_file",
            json={"name": project_name, "file_path": path},
        )
        assert response.status_code == 400, f"Expected 400 for traversal path: {path!r}"
