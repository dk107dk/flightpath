import pytest


@pytest.fixture(scope="module")
def api_keys_file(tmp_path_factory):
    """Provides an isolated, module-scoped keys file path backed by a temp directory."""
    tmp_dir = tmp_path_factory.mktemp("keys")
    return tmp_dir / "keys.json"
