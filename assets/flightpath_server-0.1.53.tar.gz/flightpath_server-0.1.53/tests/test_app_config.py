import os
import pytest
from flightpath_server.config.app_config import AppConfig

_CONFIG_PATH = os.path.join(
    "tests", "test_resources", "config", "app_config", "app_config.ini"
)


def test_config():
    config = AppConfig(_CONFIG_PATH)
    assert config.get(section="server", name="test_key") == ["a", "b", "c", "d"]


def test_get_allcaps_resolves_from_env(monkeypatch):
    monkeypatch.setenv("MY_SECRET_VALUE", "resolved-from-env")
    config = AppConfig(_CONFIG_PATH)
    config.set(section="server", name="secret", value="MY_SECRET_VALUE")
    assert config.get(section="server", name="secret") == "resolved-from-env"


def test_get_allcaps_missing_env_raises(monkeypatch):
    monkeypatch.delenv("DEFINITELY_NOT_SET", raising=False)
    config = AppConfig(_CONFIG_PATH)
    config.set(section="server", name="missing", value="DEFINITELY_NOT_SET")
    with pytest.raises(ValueError, match="unknown"):
        config.get(section="server", name="missing")


def test_reload_picks_up_file_change(tmp_path):
    cfg_file = tmp_path / "app_config.ini"
    cfg_file.write_text("[server]\nhost=original\n")
    config = AppConfig(str(cfg_file))
    assert config.get(section="server", name="host") == "original"

    cfg_file.write_text("[server]\nhost=updated\n")
    config.reload()
    assert config.get(section="server", name="host") == "updated"


def test_default_config_path(monkeypatch):
    # Ensure the environment variable is not set
    monkeypatch.delenv("FLIGHTPATH_SERVER_CONFIG", raising=False)

    # Create a dummy config file at the default location
    default_path = os.path.expanduser("~/FlightPathServer/config/app_config.ini")
    os.makedirs(os.path.dirname(default_path), exist_ok=True)
    with open(default_path, "w") as f:
        f.write("[server]\n")

    # Get the AppConfig instance
    app_config = AppConfig.me()

    # Assert that the config path is the default path
    assert os.path.normpath(app_config.configpath) == os.path.normpath(default_path)

    # Clean up the dummy file
    os.remove(default_path)
