import pytest
import os

from csvpath import CsvPaths
from flightpath_server.runs.run import Run
from flightpath_server.runs.run_manager import RunManager
from flightpath_server.projects.project_manager import ProjectManager
from flightpath_server.keys.key import Key
from flightpath_server.keys.key_manager import KeyManager
from flightpath_server.config.app_config import AppConfig
from flightpath_server.util.config_updater import ConfigUpdater

from flightpath_server.registration.registration_manager import RegistrationManager

# ===================
# tests
# ===================


@pytest.fixture
def run_manager(tmp_path):
    path = os.path.join(
        "tests", "test_resources", "config", "app_config", "run_manager_app_config.ini"
    )
    app_config = AppConfig(path)
    keys_path = app_config.get(section="security", name="key_file_path")
    if os.path.exists(keys_path):
        os.remove(keys_path)
    key_manager = KeyManager(app_config=app_config)
    key_data = {
        "key_name": "test admin",
        "key_owner_name": "dk",
        "key_owner_contact": "foo",
        "admin": False,
        "config_file_paths": {},
    }
    admin_uuid = key_manager.create_key(api_key=None, key=Key(**key_data))

    project_name = "run-mgr-tests"
    proj_manager = ProjectManager(app_config=app_config, key_manager=key_manager)
    project_config = None
    path = os.path.join(
        "tests",
        "test_resources",
        "config",
        "project_config",
        "test_run_manager_project_config.ini",
    )
    with open(path, "r") as file:
        project_config = file.read()

    new_config_path = proj_manager.create_new_project(
        api_key=admin_uuid, name=project_name, config_str=project_config
    )
    ConfigUpdater.update(
        path=new_config_path, section="inputs", name="allow_local_files", value="True"
    )
    #
    # setup the csvpaths with config using the project config path
    #
    csvpaths = CsvPaths()
    csvpaths.config.set_config_path_and_reload(new_config_path)

    run_manager = RunManager(app_config, history_dir=str(tmp_path / "history"))

    # bag up the parts we may need
    app_config.bag["csvpaths"] = csvpaths
    app_config.bag["admin_uuid"] = admin_uuid
    app_config.bag["project_name"] = project_name
    app_config.bag["key_manager"] = key_manager

    return run_manager


def test_new_run(run_manager):
    app_config = run_manager.app_config
    csvpaths = app_config.bag["csvpaths"]
    api_key = app_config.bag["admin_uuid"]
    project_name = app_config.bag["project_name"]
    run = run_manager.new_run(
        csvpaths=csvpaths,
        run_method="collect_paths",
        pathsname="paths",
        filename="file",
        template="template/:run_dir",
        api_key=api_key,
        project_name=project_name,
    )
    assert isinstance(run, Run)
    assert os.path.exists(run.run_summary_path)


def test_get_active_runs(run_manager):
    app_config = run_manager.app_config
    csvpaths = app_config.bag["csvpaths"]
    api_key = app_config.bag["admin_uuid"]
    project_name = app_config.bag["project_name"]
    run = run_manager.new_run(
        csvpaths=csvpaths,
        run_method="collect_paths",
        pathsname="paths",
        filename="file",
        template="template/:run_dir",
        api_key=api_key,
        project_name=project_name,
    )
    runs = run_manager.get_active_runs()
    assert len(runs) == 1
    assert runs[0].run_uuid == run.run_uuid
    runs = run_manager.get_active_runs(api_key=api_key)
    assert len(runs) == 1
    assert runs[0].run_uuid == run.run_uuid
    runs = run_manager.get_active_runs(api_key="abc")
    assert len(runs) == 0


def test_do_run_bad_method(run_manager):
    app_config = run_manager.app_config
    csvpaths = app_config.bag["csvpaths"]
    api_key = app_config.bag["admin_uuid"]
    project_name = app_config.bag["project_name"]
    run = run_manager.new_run(
        csvpaths=csvpaths,
        run_method="method",
        pathsname="paths",
        filename="file",
        template="template/:run_dir",
        api_key=api_key,
        project_name=project_name,
    )
    result = run_manager.do_run(run)
    assert result["success"] is False


# ---------------------------------------------------------------------------
# find_run / new_run with explicit UUID
# ---------------------------------------------------------------------------

def test_find_run_returns_none_for_unknown_uuid(run_manager):
    assert run_manager.find_run("nonexistent-uuid-xyz") is None


def test_find_run_locates_created_run(run_manager):
    app_config = run_manager.app_config
    csvpaths = app_config.bag["csvpaths"]
    api_key = app_config.bag["admin_uuid"]
    project_name = app_config.bag["project_name"]
    run = run_manager.new_run(
        csvpaths=csvpaths,
        run_method="collect_paths",
        pathsname="paths",
        filename="file",
        template=None,
        api_key=api_key,
        project_name=project_name,
    )
    found = run_manager.find_run(run.run_uuid)
    assert found is not None
    assert found.run_uuid == run.run_uuid
    assert found.pathsname == "paths"


def test_new_run_uses_explicit_uuid(run_manager):
    app_config = run_manager.app_config
    csvpaths = app_config.bag["csvpaths"]
    api_key = app_config.bag["admin_uuid"]
    project_name = app_config.bag["project_name"]
    explicit_uuid = "explicit-test-uuid-99999"
    run = run_manager.new_run(
        csvpaths=csvpaths,
        run_method="collect_paths",
        pathsname="paths",
        filename="file",
        template=None,
        api_key=api_key,
        project_name=project_name,
        run_uuid=explicit_uuid,
    )
    assert run.run_uuid == explicit_uuid
    found = run_manager.find_run(explicit_uuid)
    assert found is not None
    assert found.run_uuid == explicit_uuid


def test_do_run(run_manager):
    app_config = run_manager.app_config
    csvpaths = app_config.bag["csvpaths"]
    api_key = app_config.bag["admin_uuid"]
    project_name = app_config.bag["project_name"]
    run = run_manager.new_run(
        csvpaths=csvpaths,
        run_method="collect_paths",
        pathsname="group",
        filename="test",
        template=None,
        api_key=api_key,
        project_name=project_name,
    )

    reg_mgr = RegistrationManager(csvpaths=csvpaths, app_config=app_config)
    file_location = os.path.join("tests", "test_resources", "files", "dummy_file.csv")
    result = reg_mgr.register_file(named_file_name="test", file_location=file_location)
    assert result["success"] is True

    file_location = os.path.join(
        "tests", "test_resources", "csvpaths", "dummy_paths.csvpaths"
    )
    result = reg_mgr.register_csvpath_group(
        named_paths_name="group", file_location=file_location
    )
    assert result["success"] is True

    result = run_manager.do_run(run)
    assert result["success"] is True
