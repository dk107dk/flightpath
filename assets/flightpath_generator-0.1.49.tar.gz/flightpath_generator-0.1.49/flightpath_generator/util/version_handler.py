import os
from release_candidate_maker.version_handler import VersionHandler


class GeneratorVersionHandler(VersionHandler):

    def handle_new(self, old_version: str, new_version: str) -> None:
        with open(os.path.join("storage", "dev", "version.txt"), "w") as file:
            file.write(new_version)


