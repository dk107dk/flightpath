import os
import datetime
import json
import traceback
from typing import Callable

import litellm

#from ratelimit import limits
#from ratelimit.exception import RateLimitException

from csvpath import CsvPath
from csvpath.util.config import Config as CsvPathConfig
from csvpath.util.nos import Nos

from flightpath_generator.managers.context_manager import ContextManager
from flightpath_generator.managers.generation_manager import GenerationManager
from flightpath_generator.managers.prompt_manager import PromptManager
from flightpath_generator.prompts import Prompt, Context, Generation
from flightpath_generator.util.config import Config
from flightpath_generator.util.storage_utility import StorageUtility as stut

from flightpath_generator.client.tools import GeneratorTool, AssistantError, ExpectedError

from flightpath_generator.client.llm_client import LiteLLMClient

class Limits:
    #
    # checked at do_send to match generator.ini values.
    #
    CALLS = 20
    SECONDS = 600

class TurnsLimitException(Exception):
    ...

class Generator:
    """
    Use like:
        #
        # set up the two config objects. csvpath config sets the AI.
        # generator config sets the context and prompt template versions
        #
        csvpath = CsvPath()
        cc = csvpath.config
        path = os.path.dirname(cc.configpath)
        config = Config(os.path.join(path, "generator.ini"))
        #
        # set up generator. version key identities context, template pairs
        # so that we can configure multiple uses of generators.
        #
        generator = Generator(config)
        generator.csvpath_config = cc
        generator.version_key="question"
        #
        # create a context. mainly used for system prompt inputs. can also
        # create user/assistant back-and-forth.
        #
        context = generator.context_manager.get_context()
        #
        # create a prompt obj from the user's input and save it for future
        # reference. context and templates are preexisting. prompts are
        # created saved and then used. inside generator prompt and context
        # are merged to make the API call that results in a generation.
        #
        prompt = generator.prompt_manager.create_prompt()
        prompt.rules = "How do I check if a date is from last week?"
        prompt.example = "..."
        prompt.save()
        #
        # run the prompt and receive a generation obj with results. the
        # generation is a collection of inputs and outputs of one API call.
        #
        generation = generator.do_send(context=context, prompt=prompt)
    """

    def __init__(self, config=None, ignore_context_and_template_versions=False) -> None:
        self._config = config if config is not None else Config()
        self._root = self._config.get("storage", "root")
        if self._root is None:
            raise ValueError(f"Storage root cannot be None in {self._config.configpath}")
        self.context_manager = ContextManager(generator=self)
        self.prompt_manager = PromptManager(generator=self)
        self._csvpath_config = None
        self._csvpath_logger = None
        self._prod = None
        self._context = None
        self._context_name = None
        self._version_key = "default"
        self._model = None
        self._api_base = None
        self._tools = None
        self._generations = None
        self._callbacks = None
        self._verbose = False
        self._exceptions = None
        #
        # these two stut methods setup the storage dirs for prompts, generations, etc.
        # they will overwrite to get the templates and contexts to the level expected
        # by the installed version of the library, based on
        # flightpath_generator/storage/version.txt. users can customize prompts easily
        # but they should create new prompt template and context names and use those in
        # generator.ini in order to not be overwritten by the library's numbered
        # versions
        #
        #
        # ignore_context_and_template_versions=True means Generator won't check and overwrite its
        # context and prompt template files from zip.
        #
        if ignore_context_and_template_versions is False:
            print("Generator: init: checking context and prompt template versions")
            stut.assure_paths(self)
            stut.assure_context_and_templates(self, force_update=False)
        else:
            print("Generator: init: NOT checking context and prompt template versions")
        Limits.CALLS = config.get(section="limits", name="call_limit")
        Limits.SECONDS = config.get(section="limits", name="call_limit_time_block")

#=============
# properties
#=============


    @property
    def verbose(self) -> bool:
        return self._verbose

    @verbose.setter
    def verbose(self, v:bool) -> None:
        self._verbose = v

    @property
    def root(self) -> str:
        return self._root

    @root.setter
    def root(self, root: str) -> None:
        self._root = root

    @property
    def config(self) -> Config:
        return self._config

    @property
    def model(self) -> str:
        return self._model

    @model.setter
    def model(self, m:str) -> None:
        self._model = m

    @property
    def api_base(self) -> str:
        return self._api_base

    @api_base.setter
    def api_base(self, a:str) -> None:
        self._api_base = a

    @property
    def prod(self) -> bool:
        if self._prod is None:
            prod = self.config.get("env", "prod")
            self._prod = f"{prod}".strip().lower() == "true"
        return self._prod

    @prod.setter
    def prod(self, prod: bool) -> None:
        self._prod = prod

    @property
    def context_name(self) -> str:
        if self._context_name is None:
            self._context_name = self.config.get("version", "context")
        return self._context_name

    @context_name.setter
    def context_name(self, c: str) -> None:
        self._context_name = c

    @property
    def context(self) -> str:
        if self._context is None:
            self._context = self.context_manager.get_context(self.context_name)
        return self._context

    @context.setter
    def context(self, context: Context) -> None:
        self._context = context

    @property
    def tools(self) -> dict:
        return self._tools

    @tools.setter
    def tools(self, t:dict) -> None:
        self._tools = t

    @property
    def version_key(self) -> str:
        return self._version_key

    @version_key.setter
    def version_key(self, key:str) -> None:
        self._version_key = key

    @property
    def manifest(self) -> list:
        path = os.path.join(self._root, "manifest.json")
        if not os.path.exists(path):
            with open(path, "w") as file:
                json.dump([],file)
        with open (path, "r") as file:
            return json.load(file)

    @manifest.setter
    def manifest(self, mani:list ) -> None:
        path = os.path.join(self._root, "manifest.json")
        with open(path, "w") as file:
            json.dump(mani, file, indent=2)

    @property
    def csvpath_logger(self) -> CsvPathConfig:
        if self._csvpath_logger is None:
            self._csvpath_logger = CsvPath().logger
        return self._csvpath_logger

    @csvpath_logger.setter
    def csvpath_logger(self, log ) -> None:
        self._csvpath_logger = log

    @property
    def csvpath_config(self) -> CsvPathConfig:
        if self._csvpath_config is None:
            self._csvpath_config = CsvPath().config
        return self._csvpath_config

    @csvpath_config.setter
    def csvpath_config(self, c:CsvPathConfig ) -> None:
        self._csvpath_config = c

    @property
    def turns_limit(self) -> int:
        n = self.config.get("generations", "turns_limit", -1)
        if n is None or str(n).strip() == "":
            n = -1
        return int(n)

    @property
    def generations(self) -> list:
        if self._generations is None:
            self._generations = []
        return self._generations

    @property
    def callbacks(self) -> list[Callable]:
        if self._callbacks is None:
            self._callbacks = []
        return self._callbacks

    @property
    def exceptions(self) -> list[Exception]:
        if self._exceptions is None:
            self._exceptions = []
        return self._exceptions

#================
# util methods
#================

    def get_turns(self, text_list:bool=True) -> list[str|dict]:
        #
        # if text_list is true we serialize the manifests and return
        # a list of string. otherwise, a list of dict.
        #
        gs = self.generations
        lst = []
        for g in gs:
            _ = g.json_manifest() if text_list is True else g.manifest
            lst.append(_)
        return lst

    def dump(self) -> None:
        print(self)

    def __str__(self) -> str:
        return f"""Generator (root:{self.root}, prod:{self.prod}, context_name:{self.context_name}, config:{self.config.configpath})"""

    def assure_root(self) -> None:
        if self.root is None:
            raise ValueError(f"Storage root cannot be None")
        if not os.path.exists(self.root):
           os.makedirs(self.root)

    def create_prompt(self) -> Prompt:
        prompt = self.prompt_manager.create_prompt()
        return prompt

    def create_context(self) -> Context:
        return self.context_manager.create_context()

    def exceeds_turns_limit(self) -> bool:
        ret = False
        t = -1
        l = -1
        if self.turns_limit == -1:
            ret = False
        elif self.turns_limit == 0:
            ret = True
        else:
            t = self.turn_number
            l = self.turns_limit
            ret = t >= l
        print(f"Generator: exceeds_turns_limit: ret: {ret}: {t} >= {l}")
        return ret

    @property
    def turn_number(self) -> int:
        return len(self.generations) -1

    def _track(self, generation:Generation) -> None:
        now, td = generation.run_time_delta()
        mani = self.manifest
        #
        # TODO: add token use here
        #
        stats = {
            "model":self.model,
            "api_base":self.api_base,
            "context": f"{os.path.join(self._root, "contexts", generation.context.name)}",
            "prompt": f"{os.path.join(self._root, "prompts", generation.prompt.name)}",
            "generation": f"{os.path.join(self._root, "generations", generation.name)}",
            "started_at": str(generation.started_at),
            "ended_at": str(now),
            "duration": td.total_seconds(),
            "errors": str(generation.errors)
        }
        mani.append(stats)
        #
        # writes as well as sets property
        #
        self.manifest = mani

    def collect_generation(self, generation:Generation) -> None:
        self.generations.append(generation)
        self._track(generation)

    def add_callback(self, c:Callable) -> None:
        if self.callbacks is None:
            self._callbacks = []
        self.callbacks.append(c)

    def callback_if(self) -> None:
        g = self.generations[len(self.generations)-1]
        for c in self.callbacks:
            c(g)

    def _mock_response_if(self, context:Context, prompt:Prompt, messages:list|None) -> str:
        #
        # for now, either prompt or context named "mock" trigger a mock string. the string comes
        # from the mock context, not the prompt. that could change if mocking this way becomes
        # important. we find 0.mock_response.txt then 1.mock_response.txt, etc. with the digit
        # being the len(messages).
        #
        ret = None
        if "mock" in [context.name, prompt.name]:
            i = 0 if not messages else len(messages) -1
            path = os.path.join(self.context_manager.context_root, "mock", f"{i}.mock_response.txt")
            #print(f"_mock_response_if 1: path: {path}, os.path.exists(path): {os.path.exists(path)}")
            if os.path.exists(path):
                with open(path, "r") as file:
                    ret = file.read()
            else:
                path = os.path.join(self.context_manager.context_root, "mock", "mock_response.txt")
                #print(f"_mock_response_if 2: path: {path}, os.path.exists(path): {os.path.exists(path)}")
                if os.path.exists(path):
                    with open(path, "r") as file:
                        ret = file.read()
                else:
                    ret = "mock response"
        #print(f"_mock_response_if: ret: {ret}")
        return ret

    def on_exception(self, ex:Exception) -> None:
        self.exceptions.append(ex)

#===================
# sending methods
#===================

    #@limits(calls=Limits.CALLS, period=Limits.SECONDS)
    def do_send(self, *,
        context=None,
        prompt=None,
        datapath:str=None,
        messages=None,
        store_results=True
    ) -> Generation:
        #print(f"doing send with messages: {messages}")
        generation = None
        try:
            if context is None:
                raise ValueError("Context cannot be none")
            if prompt is None:
                raise ValueError("Prompt cannot be none")

            if self.exceeds_turns_limit():
                msg = f"Turns limit exceeded. Dropped at #{self.turn_number}."
                if generation:
                    generation.add_error("Conversation turns limit reached, including tool use. Cutting things short. You can raise the limit and try again.")
                print(msg)
                raise TurnsLimitException(msg)

            messages = self._get_messages(
                context=context,
                datapath=datapath,
                prompt=prompt,
                messages=messages
            )
            start_time = datetime.datetime.now()
            client = LiteLLMClient(generator=self)
            response = None
            #
            # we use tools. they are not in the message flow. have
            # to re-add each request cycle so they exist for the model.
            #
            client.tools = self.tools
            error_msg = None
            #
            # verbose is depreciated in favor of an OS env var setting. for now it still works.
            #
            if self.verbose is True:
                litellm.set_verbose = True
            #
            # the send happens here
            #
            ex = None
            try:
                response = client.completion(
                    messages,
                    mock_response=self._mock_response_if(context, prompt, messages)
                )
            except Exception as ex:
                self.on_exception(ex)
                print(traceback.format_exc())
            #
            #
            #
            generation = Generation(
                generator=self,
                context=context,
                prompt=prompt,
                response=response,
                errors = f"{ex}" if ex else None,
                started_at=start_time,
                messages=messages
            )
            print(f"Created generation: {generation} for turn #{self.turn_number}")
            #
            # if the send caused a problem we're done. not catching an exception here
            # doesn't mean the send was good, just means it completed.
            #
            # at this point, if we have an exception we'll have the error string in
            # the generation and the exception in the generator. That should be enough.
            #
            if ex is not None:
                generation.response_text = f"Error in AI request: {error_msg}"
                generation.save()
                return generation
            #
            #
            #
            self.collect_generation(generation)
            generation.save()
            #
            # if we have messages we are recursing and should call back. this
            # gives the caller the chance to inspect the work so far.
            #
            if messages:
                self.callback_if()
            print(f"Done with turn #{self.turn_number}")
            #
            #
            #
            """
            if errors != "" or not response:
                print(f"Error state on turn #{self.turn_number} of {self.turns_limit}")
                return generation
            """
            ng = self._do_tool_calls_if(
                response=response,
                generation = generation,
                context=context,
                prompt=prompt,
                messages=messages
            )
            #
            # we do this here so we have any errors from the tool call. in particular, going over
            # limit. however.... this will disrupt the order, right? hmmm.
            #
            if ng is None:
                #
                # this is probably the last turn, but it could be an error state
                #
                #self.callback_if()
                return generation
            stut.cleanup_generations_if(self)
            return ng
        except litellm.exceptions.ServiceUnavailableError as ex:
            self.on_exception(ex)
            msg = str(ex)
            errors=traceback.format_exc()
            print(errors)
            if generation:
                generation.errors = msg
            """
            except RateLimitException as ex:
                self.on_exception(ex)
                msg = "Too many AI requests. You can control the call limits in generator.ini."
                errors=traceback.format_exc()
                print(errors)
                if generation:
                    generation.errors = msg
            """
        except Exception as ex:
            self.on_exception(ex)
            msg = str(ex)
            errors=traceback.format_exc()
            print(errors)
            if generation:
                generation.errors = msg
        return generation

    def _get_messages(self, *, context:Context, datapath:str=None, prompt:Prompt=None, messages:dict=None):
        #
        # apply prompt adds the user generated prompt to the
        # context object that constructs the whole api prompt
        # from versioned context files containing system
        # instructions, etc.
        #
        if messages:
            #
            # if messages were passed in we need to push them to the LLM, but
            # we also need to backfil into the context so that the generation
            # can serialize the context with the most current messages.
            #
            context.from_json(messages)
        else:
            #
            # give the message templates a chance to use the path of the
            # current data file. this is so a generated csvpath file can
            # include a use-data: or test-data: metadata field.
            #
            if datapath:
                context.background["datapath"] = datapath
            #
            #
            #
            context.apply_prompt(prompt)
            messages = context.json_friendly_messages()
        return messages

    def _do_tool_calls_if(self, *, response, generation, messages, context, prompt) -> Generation:
        ok = self._check_tool_calls(
            response=response,
            generation = generation,
            context=context,
            prompt=prompt,
            messages=messages
        )
        if ok:
            return self.do_send(messages=messages, context=context, prompt=prompt)
        return None

    def _check_tool_calls(self, *, response, generation, messages, context, prompt) -> Generation:
        try:
            response_message = response.choices[0].message
            tool_calls = response_message.tool_calls
            if tool_calls is None:
                return False
            if len(tool_calls) == 0:
                return False
            #
            # we add the assistant's response to the messages because we're
            # going to reply, unless the turns limit is exceeded.
            #
            self._add_response_to_messages(
                generation=generation,
                messages=messages,
                response_message=response_message,
                tool_calls=tool_calls
            )
            #
            # response_message must go into the messages chain here so
            # that claude or another LLM has the tool call id to refer back to
            #
            return self._tool_calls(generation, messages, response_message)
        except TurnsLimitException as ex:
            print(f"Too many tool-call turns: {ex}")
            self.on_exception(ex)
            return False
        except Exception as ex:
            self.on_exception(ex)
            print(f"Error at check_tool_calls: {ex}")
            print(traceback.format_exc())
            return False


    def _add_response_to_messages(self, *, generation, messages, response_message, tool_calls) -> None:
        #
        # this response is needed for the message chain. it will be
        # pulled into into the context's messages, also, so that it
        # will be serialized to the generation's results as part of
        # the turns.
        #
        m = {
              "role": "assistant",
              "content": None,
              "tool_calls": []
            }
        for tool_call in tool_calls:
            m["tool_calls"].append({
                  "id": tool_call.id,
                  "type": "function",
                  "function": {
                    "name": tool_call.function.name,
                    "arguments": tool_call.function.arguments
                  }
            })
        messages.append(m)

    def _tool_calls(self, generation, messages:list, response_message:list) -> bool:
        tool_calls = response_message.tool_calls
        ret = True
        for tool_call in tool_calls:
            try:
                tool_name = tool_call.function.name
                generation.add_tool_used(tool_name)
                args = json.loads(tool_call.function.arguments)
                t = GeneratorTool.tool_for_name(tool_name)
                if t is None:
                    messages.append({
                        "tool_call_id": tool_call.id,
                        "role": "tool",
                        "name": tool_name,
                        "content": "Error: unknown tool"
                    })
                else:
                    m = t.use(generation, tool_call, args)
                    messages.append(m)
            except AssistantError as ex:
                print(f"Error during tool call due to assistant's incorrect use of tool: {tool_call}: {ex}")
                messages.append({
                        "tool_call_id": tool_call.id,
                        "role": "tool",
                        "name": tool_name,
                        "content": "Error: your tool-use request was incorrectly made."
                    })
                self.on_exception(ex)
            except ExpectedError as ex:
                print(f"Error during tool call: likely due to bad inputs from assistant: {tool_call}: {ex}")
                messages.append({
                        "tool_call_id": tool_call.id,
                        "role": "tool",
                        "name": tool_name,
                        "content": "Error: the tool did not perform as exected. Check your inputs."
                    })
                self.on_exception(ex)
            except Exception as ex:
                print(traceback.format_exc())
                print(f"Unexpected error in tool call: {tool_call}: {ex}")
                ret = False
                self.on_exception(ex)
        return ret


