from __future__ import annotations
import os
from typing import List
from flightpath_generator.prompts import Generation

class GenerationManager:

    def __init__(self, generator):
        #
        # assuming we'll come back to this class so people can load
        # past runs.
        #
        if generator is None:
            raise ValueError("Generator cannot be None")
        self.generator = generator

    def assure_generation_root(self) -> None:
        path = os.path.join(self.generator.root, "generations")
        if not os.path.exists(path):
            os.makedirs(path)

    def add_generation(self, generation:Generation) -> None:
        if generation is None:
            raise ValueError("Generation cannot be None")
        if generation.name is None:
            raise ValueError("Generation name cannot be None")
        ...

    def get_generations(self, name:str) -> List[Generation]:
        return []

    def last(self, name:str ):
        return None
