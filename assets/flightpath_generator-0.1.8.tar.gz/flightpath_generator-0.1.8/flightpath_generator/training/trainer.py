import os
from flightpath_generator import Generator
from flightpath_generator.prompts import Prompt, Generation
from flightpath_generator.managers import PromptManager, ContextManager
from flightpath_generator.training.assessor import Assessor
from flightpath_generator.util.exceptions import PromptException


class Trainer:
    """
    In order to do an iteration, Trainer needs a prompt_model name and an AutoGen.
    The AutoGen's prod:bool and context_name:str properties must be set correctly.
    """

    def __init__(self, generator=None) -> None:
        self._generator = generator
        self._prompt_model_name = None
        self._prompt_model = None
        self._prompt = None
        self._generation = None


    def load_historic(self, *, context_name, prompt_name, generation_name) -> Generation:
        prompt = PromptManager(self.generator).get_prompt(name=prompt_name)
        context = ContextManager(self.generator).get_context(name=context_name)
        response = os.path.join(self.generator.root, "generations")
        response = os.path.join(response, generation_name)
        response = os.path.join(response, "response.txt")
        with open(response, "r") as f:
            response = f.read()
        generation = Generation(
            generator=self.generator, context=context, prompt=prompt, generation_name=generation_name, response=response
        )
        assessor = Assessor()
        assessor.generation = generation
        a = assessor.assess()
        generation.assessment = a
        return generation

    @property
    def generator(self) -> AutoGen:
        if self._generator is None:
            self._generator = AutoGen()
        return self._generator

    @property
    def prompt_model_name(self) -> str:
        if self._prompt_model_name is None or self._prompt_model_name.strip() == "":
            self._prompt_model_name = self.generator.config.get("version", "prompt_model")
        if self._prompt_model_name is None or self._prompt_model_name.strip() == "":
            raise PromptException(
                f"Prompt model cannot be None. Check {self.generator.config._configpath}"
            )
        return self._prompt_model_name

    @prompt_model_name.setter
    def prompt_model_name(self, p: str) -> None:
        self._prompt_model_name = p

    @property
    def prompt_model(self) -> str:
        if self._prompt_model is None:
            name = self.prompt_model_name
            self._prompt_model = self.generator.prompt_manager.get_prompt(name)
        return self._prompt_model

    @prompt_model.setter
    def prompt_model(self, p: str) -> None:
        self._prompt_model = p

    @property
    def generation(self) -> Generation:
        return self._generation

    @generation.setter
    def generation(self, gen: Generation) -> None:
        self._generation = gen

    @property
    def prompt(self) -> Prompt:
        if self._prompt is None:
            prompt = self.generator.prompt_manager.create_prompt()
            self._prompt = prompt
            prompt_model = self.prompt_model
            if prompt_model is not None:
                prompt.rules = prompt_model.rules
                prompt.example = prompt_model.example
        return self._prompt

    @prompt.setter
    def prompt(self, prompt: Prompt) -> None:
        self._prompt = prompt

    def dump_run_prep(self) -> None:
        d = "Trainer.dump_run_prep: "
        if self.prompt_model_name is None or self.prompt_model_name.strip() == "":
            d = f"{d}\n no prompt model name,"
        else:
            d = f"{d}\n  prompt model name: {self.prompt_model_name},"
            p = os.path.join(
                self.generator.prompt_manager.prompt_root, self.prompt_model_name
            )
            d = f"{d}\n  prompt model path: {p}"
            d = f"{d}\n  prompt name: {self.prompt.name}"
            p = os.path.join(self.generator.prompt_manager.prompt_root, self.prompt.name)
            d = f"{d}\n  prompt path: {p}"
        d = f"{d}\n  context name: {self.generator.context.name}"
        p = os.path.join(
            self.generator.context_manager.context_root, self.generator.context.name
        )
        d = f"{d}\n  context path: {p}"
        print(d)

    def run_and_score(self) -> None:
        print("")
        #
        # we usually get the selected context from config.ini. if needed,
        # we can set it to another name in the AutoGen.
        #
        context = self.generator.context
        #
        # we load the prompt with user input. prompt saves it.
        #
        prompt = self.prompt
        #
        # do the run
        #
        self.generation = self.generator.do_send(context, prompt)
        print(f"Trainer.run_and_score: generation: {self.generation.name}")
        self.generation.save_if()
        #
        # do the score and save in the generation
        #
        assessor = Assessor()
        assessor.generation = self.generation
        a = assessor.assess()
        self.generation.assessment = a
