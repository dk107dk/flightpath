from abc import ABC, abstractmethod
from typing import Self
from flightpath_generator.prompts import Generation

class GeneratorTool(ABC):

    TOOLS = {}

    @abstractmethod
    def tool_definition(self) -> dict:
        ...

    @abstractmethod
    def name(self) -> str:
        ...

    @abstractmethod
    def use(self, generation:Generation, tool_call, args:dict) -> dict:
        ...

    @classmethod
    def tool_for_name(cls, name:str) -> Self:
        if name in GeneratorTool.TOOLS:
            return GeneratorTool.TOOLS[name]
        return None

    def _tool_def(self, *, name:str, desc:str, properties:dict[str,dict], required:list[str]) -> dict:
        return {
                "type": "function",
                "function": {
                    "name": name,
                    "description": desc,
                    "parameters": {
                        "type": "object",
                        "properties": properties,
                        "required": required
                    }
                }
            }



