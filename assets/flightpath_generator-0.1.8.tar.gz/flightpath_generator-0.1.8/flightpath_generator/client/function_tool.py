import io
import traceback
from contextlib import redirect_stdout
from csvpath import CsvPath
from csvpath.cli.function_describer import FunctionDescriber
from csvpath.matching.functions.function_factory import FunctionFactory
from flightpath_generator.prompts import Generation
from flightpath_generator.client.tools import GeneratorTool

class MyConst:
    ITALIC = ""
    SIDEBAR_COLOR = ""
    REVERT = ""

class LiteLLMFunctionTool(GeneratorTool):

    NAME = "get_function_description"

    def __init__(self) -> None:
        GeneratorTool.TOOLS[LiteLLMFunctionTool.NAME] = self

    def tool_definition(self) -> dict:
        props = {
            "function": {
                "type": "string",
                "description": "The function to describe"
            }
        }
        return self._tool_def(
            name=LiteLLMFunctionTool.NAME,
            desc="Gives a description on how to use a CsvPath function",
            properties=props,
            required=["function"]
        )

    def name(self) -> str:
        return LiteLLMFunctionTool.NAME

    def use(self, generation:Generation, tool_call, args:dict) -> dict:
        function_response = self._use(generation, args["function"])
        return {
            "tool_call_id": tool_call.id,
            "role": "tool",
            "name": tool_call.function.name,
            "content": function_response,
        }

    def _use(self, generation, function:str ) -> str:
        function_response = None
        try:
            f = FunctionFactory.get_function(
                None,
                name=function,
                child=None,
                find_external_functions=False
            )
            if f is None:
                raise ValueError(f"Unknown function: {function}")
            ps = io.StringIO()
            FunctionDescriber.CONST = MyConst
            with redirect_stdout(ps):
                FunctionDescriber.describe(f, markdown=True, links={})
                function_response = ps.getvalue()
        except Exception as ex:
            print(f"eeorr: {ex}")
            if generation:
                generation.add_error(traceback.format_exc())
            print(f">>> tool error: caught in generation {generation.name if generation else ""}: >>>{ex}<<<")
            function_response = f"Error: {ex}"
        return function_response







