from __future__ import annotations
from flightpath_generator.generator import Generator

__all__ = ["Generator"]
