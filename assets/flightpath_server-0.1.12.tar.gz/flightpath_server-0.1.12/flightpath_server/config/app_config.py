import os
import logging
import hashlib
from logging import Logger
from logging.handlers import RotatingFileHandler
from configparser import ConfigParser
from typing import Any, Self
from fastapi import HTTPException
from csvpath import CsvPaths
from csvpath.util.file_writers import DataFileWriter
from csvpath.util.nos import Nos
from flightpath_server.util.info_dumper import InfoDumper
from .logger_provider import LoggerProvider


class ConfigException(Exception):
    ...


class AppConfig:
    config_data: dict[str, dict[str, Any]]

    FLIGHTPATH_SERVER_CONFIG = "FLIGHTPATH_SERVER_CONFIG"
    CONFIG_FILE = "app_config.ini"
    BOOT_SVR_MSG = False
    LOGGER = LoggerProvider().LOGGER

    @classmethod
    def app_home_dir(cls) -> str:
        return os.path.expanduser("~/FlightPathServer")

    @classmethod
    def app_config_dir(cls) -> str:
        return os.path.join(cls.app_home_dir(), "config")

    @classmethod
    def me(cls, config_path: str = None) -> Self:
        if config_path is None or str(config_path).strip() == "":
            config_path = os.getenv(AppConfig.FLIGHTPATH_SERVER_CONFIG)
            if config_path is None or str(config_path).strip() == "":
                config_path = os.path.join(cls.app_config_dir(), cls.CONFIG_FILE)
        if AppConfig.BOOT_SVR_MSG is False:
            AppConfig.BOOT_SVR_MSG = True
        app_config = AppConfig(config_path)
        return app_config

    def __init__(self, path) -> None:
        self._config = None
        if path is None:
            raise ConfigException("Path cannot be None")
        self.configpath = path
        #
        # bag is for anything we need to share temporarily
        #
        self._bag = {}
        self.load()
        self.dump_info_if(api_key="", project_name="")

    def verbose(self) -> bool:
        v = self.get(section="logging", name="verbose")
        return str(v).strip().lower() in ["yes", "true", "on"]

    def dump_info_if(
        self, *, api_key: str, project_name: str = None, csvpaths: CsvPaths = None
    ) -> str:
        if self.verbose():
            key = hashlib.sha256(api_key.encode()).hexdigest()
            InfoDumper.dump_info(
                app_config=self,
                project_name=project_name,
                csvpaths=csvpaths,
                hash_key=key,
            )

    @property
    def logger(self) -> Logger:
        logger = AppConfig.LOGGER
        self._set_log_level(logger)
        return logger

    #
    # use this for a logger that doesn't risk triggering recursion by
    # looking for its level in config.
    #
    def debug_logger(self) -> Logger:
        logger = AppConfig.LOGGER
        logger.setLevel(logging.DEBUG)
        return logger

    def _set_log_level(self, logger: Logger, level: str = None) -> None:
        if level is None:
            level = self.get(section="logging", name="level", default="info")
        if level is None:
            level = "info"
        if level not in ["debug", "info", "warning", "error"]:
            raise ValueError(
                f"Logging level must be one of debug, info, warning, error, not: {level}"
            )
        lvl = None
        if level == "debug":
            lvl = logging.DEBUG
        elif level == "info":
            lvl = logging.INFO
        elif level == "warning":
            lvl = logging.WARNING
        elif level == "error":
            lvl = logging.ERROR
        AppConfig.LOGGER.setLevel(lvl)
        for h in AppConfig.LOGGER.handlers:
            h.setLevel(lvl)

    def http_error(self, name: str, code: int, msg: str) -> HTTPException:
        AppConfig.LOGGER.error(
            f"HTTP error: {msg}", extra={"code": code, "source": name}
        )
        return HTTPException(status_code=code, detail=msg)

    @property
    def bag(self) -> dict:
        return self._bag

    @bag.setter
    def bag(self, b: dict[str, Any]) -> None:
        self._bag = b

    def load(self) -> None:
        if self._config is None:
            if not os.path.exists(self.configpath):
                print(f"No config file at {self.configpath}. Generating a default.")
                dirpath = os.path.dirname(self.configpath)
                nos = Nos(dirpath)
                if not nos.exists():
                    nos.makedirs()
                with DataFileWriter(path=self.configpath) as n:
                    n.write(self._get_default_config_string())
            self._config = ConfigParser()
            self._config.read(self.configpath)

    def _get_default_config_string(self) -> str:
        #
        # in principle we could check here if we have an assets/app_config.ini
        # but for now just returning a string is much easier and we're far
        # from when it will become too problematic.
        #
        return """
#
# use ALL-CAPS to point to an env var. e.g.:
#
# key_file_path=FLIGHTPATH_API_KEY_FILE
#
[security]
localhost_files_allowed=True
#
# if key_index is yes, all keys will be kept in a json file of key->hash pairs.
# this is likely to be helpful in test/dev but should be set to off for prod.
#
key_index=yes
#
# key_file_path points to a json file of FlightPath Server's user API keys
#
key_file_path=
#
# see Uvicorn docs
#
ssl_keyfile=
ssl_certfile=
ssl_keyfile_password=
ssl_version=

[server]
host=localhost
port=8000
workers=1
#
# largest file that can be uploaded by API. this limitation does not
# affect the CsvPath backends, only posting files to the API.
#
max_file_size_kb=1024

[logging]
level=debug
verbose=off
        """

    #
    # TODO: this does not save the updated config.
    #
    def set(self, *, section: str, name: str, value: Any) -> None:
        self._config[section][name] = value

    def get(self, *, section: str, name: str, default: Any = None) -> Any:
        if self._config is None:
            raise ConfigException("No config available")
        try:
            s = self._config[section][name]
            ret = None
            if s and isinstance(s, str) and s.find(",") > -1:
                ret = [s.strip() for s in s.split(",")]
            elif isinstance(s, str):
                ret = s.strip()
            else:
                ret = s
            if ret and isinstance(ret, str) and ret.isupper():
                v2 = os.getenv(ret)
                if v2 is None:
                    raise ValueError(
                        f"All cap ini values are converted to env var values, which must exist. {ret} is unknown."
                    )
                else:
                    ret = v2.strip()
            return ret
        except KeyError:
            self.debug_logger().warning(f"Unknown config: [{section}] {name}")
            print(f"WARNING: unkown config: [{section}] {name}")
            return default
