from typing import Any
import os
import traceback

from csvpath.util.references.results_reference_finder_2 import ResultsReferenceFinder2
from csvpath.util.file_readers import DataFileReader
from csvpath.util.nos import Nos

from flightpath_server.keys.key_manager import KeyManager
from flightpath_server.config.app_config import AppConfig
from flightpath_server.util.csvpaths_loader import CsvPathsLoader


class ResultsManager:
    def __init__(self, app_config: AppConfig):
        if app_config is None:
            raise ValueError("App config cannot be None")
        self.app_config = app_config
        self.key_manager = KeyManager(app_config=app_config)

    def get_run_path(
        self, *, api_key: str, project_name: str, run_reference: str
    ) -> dict[str, Any]:
        try:
            csvpaths = CsvPathsLoader.get_csvpaths(
                app_config=self.app_config, api_key=api_key, project_name=project_name
            )
            results = ResultsReferenceFinder2(csvpaths, reference=run_reference)
            lst = results.resolve()
            if lst is None:
                raise RuntimeError(f"Unknown error in reference {run_reference}")
            if len(lst) == 0:
                raise ValueError(f"No such results: {run_reference}")
            if len(lst) > 1:
                raise ValueError(
                    f"Reference must point to 1 and only 1 run results. {run_reference} pointed to {len(lst)} results."
                )
            return {"success": True, "path": lst[0]}
        except Exception as e:
            print(traceback.format_exc())
            self.app_config.logger.error(traceback.format_exc())
            return {"success": False, "errors": [str(e)]}

    def get_run_errors(
        self, *, api_key: str, project_name: str, run_reference: str
    ) -> dict[str, Any]:
        if run_reference is None:
            raise ValueError("Run reference cannot be None")
        csvpaths = CsvPathsLoader.get_csvpaths(
            app_config=self.app_config, api_key=api_key, project_name=project_name
        )
        try:
            errors = csvpaths.results_manager.get_errors(run_reference)
            if len(errors) == 0:
                #
                # results manager is currently too forgiving so we need to double check
                #
                if csvpaths.results_manager.get_named_results(run_reference) is None:
                    raise ValueError(f"{run_reference} does not point to results")
            es = [e.to_json() for e in errors]
            return {"success": True, "errors": es}
        except Exception as e:
            print(traceback.format_exc())
            self.app_config.logger.error(traceback.format_exc())
            return {"success": False, "errors": [str(e)]}

    #
    # we're looking for a structure like:
    # {
    #       ...field:value,...,
    #       "manifest":[ csvpath-id:{run metadata},...]
    #       "runtime": [ csvpath-id:{runtime metadata},...]
    # }
    #
    def get_run_metadata(
        self, api_key: str, project_name: str, run_reference: str
    ) -> dict[str, Any]:
        if run_reference is None:
            raise ValueError("Run reference cannot be None")
        csvpaths = CsvPathsLoader.get_csvpaths(
            app_config=self.app_config, api_key=api_key, project_name=project_name
        )
        try:

            #
            # _get_results_list is an internal method, when it has a public equiv we'll
            # use that.
            #
            results = csvpaths.results_manager.get_named_results(run_reference)
            #
            # this is prob too concise
            #
            results = (
                results
                if isinstance(results, list)
                else []
                if results is None
                else [results]
            )
            if len(results) == 0:
                raise ValueError(f"{run_reference} does not point to results")
            """
            metadata: dict[str, Any] = csvpaths.results_manager.get_metadata(
                run_reference
            )
            """
            metadata = {}
            for result in results:
                name = result.identity_or_index
                #
                # exp!
                #
                if "metadata" not in metadata:
                    metadata["metadata"] = {}
                metadata["metadata"][name] = result.metadata
                #
                # end exp
                #
                if "manifest" not in metadata:
                    metadata["manifest"] = {}
                metadata["manifest"][name] = result.manifest
                if "runtime" not in metadata:
                    metadata["runtime"] = {}
                from csvpath.matching.util.runtime_data_collector import (
                    RuntimeDataCollector,
                )

                _ = {}
                RuntimeDataCollector.collect(result.csvpath, _, True)
                metadata["runtime"][name] = _
            return {"success": True, "metadata": metadata}
        except Exception as e:
            self.app_config.logger.error(traceback.format_exc())
            return {"success": False, "errors": [str(e)]}

    def get_run_variables(
        self, api_key: str, project_name: str, run_reference: str
    ) -> dict[str, Any]:
        if run_reference is None:
            raise ValueError("Run reference cannot be None")
        csvpaths = CsvPathsLoader.get_csvpaths(
            app_config=self.app_config, api_key=api_key, project_name=project_name
        )
        try:
            variables: dict[str, Any] = csvpaths.results_manager.get_variables(
                run_reference
            )
            if len(variables) == 0:
                #
                # results manager is currently too forgiving so we need to double check
                #
                if csvpaths.results_manager.get_named_results(run_reference) is None:
                    raise ValueError(f"{run_reference} does not point to results")
            return {"success": True, "variables": variables}
        except Exception as e:
            self.app_config.logger.error(traceback.format_exc())
            return {"success": False, "errors": [str(e)]}

    def get_run_printouts(
        self,
        api_key: str,
        project_name: str,
        run_reference: str,
        printstream: str = None,
    ) -> dict[str, Any]:
        if run_reference is None:
            raise ValueError("Run reference cannot be None")
        if printstream is None:
            printstream = "default"
        csvpaths = CsvPathsLoader.get_csvpaths(
            app_config=self.app_config, api_key=api_key, project_name=project_name
        )
        try:
            printouts = csvpaths.results_manager.get_printouts(run_reference)
            if len(printouts) == 0:
                #
                # results manager is currently too forgiving so we need to double check
                #
                if csvpaths.results_manager.get_named_results(run_reference) is None:
                    raise ValueError(f"{run_reference} does not point to results")
            return {"success": True, "printouts": printouts}
        except Exception as e:
            self.app_config.logger.error(traceback.format_exc())
            return {"success": False, "errors": [str(e)]}

    def find_results(
        self, api_key: str, project_name: str, reference: str
    ) -> dict[str, Any]:
        try:
            csvpaths = CsvPathsLoader.get_csvpaths(
                app_config=self.app_config, api_key=api_key, project_name=project_name
            )
            results = csvpaths.results_manager.get_named_results(reference)
            self.app_config.logger.debug(
                "Results for ref %s: %s in %s, %s",
                reference,
                results,
                api_key,
                project_name,
            )
            if results is None:
                raise ValueError(f"Results returned None for {reference}")
            if len(results) == 0:
                return {"success": False, "message": "No results found"}
            if not isinstance(results, list):
                results = [results]
            lst = []
            for result in results:
                lst.append(result.data_file_path)
            return {"success": True, "results": lst}
        except Exception as e:
            print(traceback.format_exc())
            self.app_config.logger.error(traceback.format_exc())
            return {"success": False, "errors": [str(e)]}

    def get_result(
        self, api_key: str, project_name: str, reference: str
    ) -> dict[str, Any]:
        try:
            csvpaths = CsvPathsLoader.get_csvpaths(
                app_config=self.app_config, api_key=api_key, project_name=project_name
            )
            results = csvpaths.results_manager.get_named_results(reference)
            if results is None:
                raise ValueError(f"Results returned None for {reference}")
            if len(results) == 0:
                return {"success": False, "message": "No results found"}
            if isinstance(results, list):
                if len(results) > 1:
                    return {
                        "success": False,
                        "message": "Reference must point to 1 csvpath instance from a run",
                    }
                results = results[0]
            path = results.data_file_path
            nos = Nos(path)
            if not nos.exists():
                return {
                    "success": False,
                    "message": "Reference pointed to run results but there is no data",
                }
            with DataFileReader(path) as file:
                return {"success": True, "result": file.read()}
        except Exception as e:
            print(traceback.format_exc())
            self.app_config.logger.error(traceback.format_exc())
            return {"success": False, "errors": [str(e)]}
