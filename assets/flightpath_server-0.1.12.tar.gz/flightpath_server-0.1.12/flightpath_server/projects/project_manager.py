import os
import io
import shutil
import tempfile
import json
import traceback
import configparser
from configparser import ConfigParser
from csvpath.util.nos import Nos
from csvpath.util.config import Config
from csvpath.util.file_writers import DataFileWriter
from csvpath.util.path_util import PathUtility as pathu

from flightpath_server.keys.key_manager import KeyManager
from flightpath_server.keys.key import Key
from flightpath_server.config.app_config import AppConfig


class ProjectManager:
    @classmethod
    def config_from_str(self, config_str: str) -> ConfigParser:
        config = ConfigParser()
        config.read_string(config_str)
        return config

    @classmethod
    def config_to_str(self, config: ConfigParser) -> str:
        string_buffer = io.StringIO()
        config.write(string_buffer)
        config_str = string_buffer.getvalue()
        return config_str

    def __init__(
        self, *, app_config: AppConfig, key_manager: KeyManager = None
    ) -> None:
        if app_config is None:
            raise ValueError("App config cannot be None")
        self.app_config: AppConfig = app_config
        if key_manager is None:
            key_manager = KeyManager(app_config=app_config)
        self.key_manager = key_manager

    @property
    def projects_dir(self) -> str:
        return os.path.expanduser("~/FlightPathServer/projects")

    def get_project_home(
        self, *, project_name, api_key, must_exist: bool = True
    ) -> str:
        projects_dir = self.projects_dir
        key = self.key_manager.get_key_data(api_key)
        if not key:
            raise ValueError("Invalid API Key")
        hash_key = self.key_manager.hash_key(api_key)
        path = os.path.join(projects_dir, hash_key, project_name)
        if must_exist and not os.path.exists(path):
            raise ValueError(
                f"Cannot find project home for {project_name} and hash key: {hash_key}"
            )
        return path

    # deprecated. use get_project_home()
    def get_project_path(self, api_key: str, project_name: str) -> str:
        return self.get_project_home(
            project_name=project_name, api_key=api_key, must_exist=False
        )

    def create_new_project(self, *, api_key: str, name: str, config_str: str) -> str:
        if api_key is None:
            raise ValueError("API key cannot be None")
        key = self.key_manager.get_key_data(api_key)
        if not key:
            raise ValueError("Invalid API Key")
        config_file_paths = key.config_file_paths
        if name in config_file_paths:
            raise ValueError(f"Config '{name}' already exists for key")
        if config_str is None:
            config_str = Config.DEFAULT_CONFIG

        hash_key = self.key_manager.hash_key(api_key)
        new_config_path = os.path.join(
            self.get_project_path(project_name=name, api_key=api_key),
            "config",
            "config.ini",
        )
        os.makedirs(os.path.dirname(new_config_path), exist_ok=True)
        self.app_config.logger.info(
            f"Create new project {name}. Config path: {new_config_path}"
        )
        #
        # we have exist_ok but it shouldn't be needed. if we delete a project we clean up the filesystem.
        # if a project is in the key an error is thrown. projects are namespaced by key hash(uuid) so
        # there won't be conflicts.
        #
        os.makedirs(os.path.dirname(new_config_path), exist_ok=True)
        projects_dir = self.projects_dir
        #
        # config has several settings that must be managed in a server context
        #
        config_str = self._modify_config(
            config_str=config_str,
            config_path=new_config_path,
            project_name=name,
            projects_dir=projects_dir,
            hash_key=hash_key,
        )
        with open(new_config_path, "w") as f:
            f.write(config_str)
        self.app_config.logger.debug(f"Wrote {name} config with len {len(config_str)}")
        config_file_paths[name] = new_config_path
        self.key_manager.update_key_data(api_key, key)
        return new_config_path

    def _modify_config(
        self,
        *,
        config_str: str,
        config_path: str,
        project_name: str,
        projects_dir: str,
        hash_key: str,
    ) -> str:
        #
        # we modify these config keys both defensively and to give access to the correct project
        # context.
        #
        self.app_config.logger.info(f"Moding {project_name} config at {config_path}")
        config_str = self._update_config_path(
            config_str=config_str, target_config_path=config_path
        )
        config_str = self._update_inputs_paths(
            config_str=config_str,
            projects_dir=projects_dir,
            hash_key=hash_key,
            project_name=project_name,
        )
        config_str = self._update_results_paths(
            config_str=config_str,
            projects_dir=projects_dir,
            hash_key=hash_key,
            project_name=project_name,
        )
        config_str = self._update_log_path(
            config_str=config_str,
            projects_dir=projects_dir,
            hash_key=hash_key,
            project_name=project_name,
        )
        config_str = self._set_no_local_no_http(config_str=config_str)
        config_str = self._set_cache_no_imports_no_scripts(
            config_str=config_str,
            projects_dir=projects_dir,
            hash_key=hash_key,
            project_name=project_name,
        )
        config_str = self._set_no_sqlite_dialect(
            config_str=config_str,
            projects_dir=projects_dir,
            hash_key=hash_key,
            project_name=project_name,
        )
        #
        # we allow var subbing and set the source to a local config/env.json file. the contents of the file
        # will need to be settable by API
        #
        config_str = self._set_var_source(
            config_str=config_str,
            projects_dir=projects_dir,
            hash_key=hash_key,
            project_name=project_name,
        )
        self.app_config.logger.debug(f"Modded {project_name} config at {config_path}")
        return config_str

    def _relative_path(self, path: str) -> bool:
        if path is None:
            raise ValueError("Path cannot be None")
        self.app_config.logger.debug(f"Relative path: {path}?")
        path = path.strip().lower()
        if path == "":
            self.app_config.logger.debug("Relative path? returning True (1)")
            return True
        if path[0] == "/":
            self.app_config.logger.debug("Relative path? returning False (1)")
            return False
        if path[0:1] == "\\":
            self.app_config.logger.debug("Relative path? returning False (2)")
            return False
        if (
            path.startswith("s3://")
            or path.startswith("azure://")
            or path.startswith("gcs://")
            or path.startswith("sftp://")
        ):
            self.app_config.logger.debug("Relative path? returning False (3)")
            return False
        if path[1:2] == ":\\":
            self.app_config.logger.debug("Relative path? returning False (4)")
            return False
        self.app_config.logger.debug("Relative path? returning True (2)")
        return True

    def _set_var_source(
        self, *, config_str: str, projects_dir: str, hash_key: str, project_name: str
    ) -> str:
        config = ConfigParser()
        config.read_string(config_str)
        try:
            config["config"]["allow_var_sub"] = "yes"
        except Exception:
            ...
        try:
            path = os.path.join(
                projects_dir, hash_key, project_name, "config", "env.json"
            )
            config["config"]["var_sub_source"] = path
            nos = Nos(path)
            if not nos.exists():
                with DataFileWriter(path=path) as file:
                    json.dump({}, file.sink, indent=4)
            self.app_config.logger.debug(
                f"Var source config: {project_name} source path {path}"
            )
        except Exception:
            print(traceback.format_exc())
        string_buffer = io.StringIO()
        config.write(string_buffer)
        config_str = string_buffer.getvalue()
        return config_str

    def _set_cache_no_imports_no_scripts(
        self, *, config_str: str, projects_dir: str, hash_key: str, project_name: str
    ) -> str:
        config = ConfigParser()
        config.read_string(config_str)
        #
        # there shouldn't be a time when these sections don't exist.
        #
        try:
            config["cache"]["use_cache"] = "yes"
            config["cache"]["path"] = os.path.join(
                projects_dir, hash_key, project_name, "cache"
            )
        except Exception:
            print(traceback.format_exc())
        try:
            config["scripts"]["run_scripts"] = "no"
        except KeyError:
            ...
        except Exception:
            print(traceback.format_exc())
        try:
            config["functions"]["imports"] = ""
        except KeyError:
            ...
        except Exception:
            print(traceback.format_exc())
        string_buffer = io.StringIO()
        config.write(string_buffer)
        config_str = string_buffer.getvalue()
        return config_str

    def _set_no_sqlite_dialect(
        self, *, config_str: str, projects_dir: str, hash_key: str, project_name: str
    ) -> str:
        config = ConfigParser()
        config.read_string(config_str)
        #
        # we don't allow SQL integration to use sqlite because that is typically
        # local filesystem, presenting security problems.
        #
        try:
            if config["sql"]["dialect"] == "sqlite":
                config["sql"]["dialect"] = ""
        except KeyError:
            ...
        except Exception:
            print(traceback.format_exc())
        #
        # set the sqlite path regardless of if sqlite is enabled. easy to do, no harm.
        #
        try:
            path = os.path.join(projects_dir, hash_key, project_name, "archive")
            nos = Nos(os.path.dirname(path))
            if not nos.exists():
                nos.makedirs()
            path = os.path.join(path, "csvpath.db")
            config["sqlite"]["db"] = path
            self.app_config.logger.debug(
                f"Var source config: {project_name} sqlite path {path}"
            )
        except KeyError:
            ...
        except Exception:
            print(traceback.format_exc())
        string_buffer = io.StringIO()
        config.write(string_buffer)
        config_str = string_buffer.getvalue()
        return config_str

    def _set_no_local_no_http(self, config_str: str) -> str:
        config = ConfigParser()
        config.read_string(config_str)
        #
        # we never allow http loading. too risky.
        #
        config["inputs"]["allow_http_files"] = "no"
        #
        # by default we don't allow local file loading. allowing local files is not a great idea unless you're
        # just using FlightPath Server for a small workgroup.
        #
        if not self.app_config.get(
            section="security", name="localhost_files_allowed", default="no"
        ) in ["yes", "true"]:
            config["inputs"]["allow_local_files"] = "no"
        string_buffer = io.StringIO()
        config.write(string_buffer)
        config_str = string_buffer.getvalue()
        return config_str

    def _update_log_path(
        self, *, config_str: str, projects_dir: str, hash_key: str, project_name: str
    ) -> str:
        config = ConfigParser()
        config.read_string(config_str)
        try:
            file = os.path.join(
                projects_dir, hash_key, project_name, "logs", "csvpath.log"
            )
            config["logging"]["log_file"] = file
            self.app_config.logger.debug(f"Log file: {project_name} file {file}")
        except Exception:
            print(traceback.format_exc())
        string_buffer = io.StringIO()
        config.write(string_buffer)
        config_str = string_buffer.getvalue()
        return config_str

    def _remove_common_prefix(self, path: str, paths: list) -> str:
        p = self._get_common_prefix(path, paths)
        path = path[len(p) + 2 :] if p != "" else path
        return path

    #
    # gets the common prefix of absolute paths
    # returns "" when path is relative
    #
    def _get_common_prefix(self, path: str, paths: list) -> str:
        if path.startswith(os.sep):
            rem = []
            found = True
            path = pathu.parts(path)
            for i, _p in enumerate(path):
                for j, _a in enumerate(paths):
                    _x = pathu.parts(_a)
                    if i < len(_x) and _x[i] == _p:
                        if j == 0:
                            if _x[i] != "":
                                rem.append(_p)
                            else:
                                rem.append(None)
                    else:
                        if j == 0:
                            rem.append(None)
                        else:
                            rem.pop()
                        found = False
                        break
                if not found:
                    break
            rem = [_ for _ in rem if _ is not None]
            ret = f"{os.sep}".join(rem)
            return ret
        return ""

    def _update_inputs_paths(
        self, *, config_str: str, projects_dir: str, hash_key: str, project_name: str
    ) -> str:
        config = ConfigParser()
        config.read_string(config_str)

        files = config["inputs"]["files"]
        paths = config["inputs"]["csvpaths"]

        files = self._remove_common_prefix(files, [paths])
        files = pathu.parts(files)
        files = os.path.join(projects_dir, hash_key, project_name, *files)

        paths = self._remove_common_prefix(paths, [files])
        paths = pathu.parts(paths)
        paths = os.path.join(projects_dir, hash_key, project_name, *paths)

        config["inputs"]["files"] = files
        config["inputs"]["csvpaths"] = paths

        self.app_config.logger.debug(
            f"Inputs: {project_name} files: {files}, paths: {paths}"
        )
        string_buffer = io.StringIO()
        config.write(string_buffer)
        config_str = string_buffer.getvalue()
        return config_str

    def _update_results_paths(
        self, *, config_str: str, projects_dir: str, hash_key: str, project_name: str
    ) -> str:
        config = ConfigParser()
        config.read_string(config_str)

        archive = config["results"]["archive"]
        transfers = config["results"]["transfers"]

        archive = self._remove_common_prefix(archive, [transfers])
        archive = pathu.parts(archive)
        archive = os.path.join(projects_dir, hash_key, project_name, *archive)

        a = self.app_config.get(
            section="security", name="localhost_files_allowed", default="yes"
        )
        if a.strip().lower() not in ["true", "yes", "on"]:
            transfers = self._remove_common_prefix(transfers, [archive])
            transfers = pathu.parts(transfers)
            transfers = os.path.join(projects_dir, hash_key, project_name, *transfers)
        else:
            transfers = os.path.join(projects_dir, hash_key, project_name, "transfers")

        config["results"]["archive"] = archive
        config["results"]["transfers"] = transfers
        self.app_config.logger.debug(
            f"Results: {project_name}: archive {archive}, transfers {transfers}"
        )
        string_buffer = io.StringIO()
        config.write(string_buffer)
        config_str = string_buffer.getvalue()
        return config_str

    def _update_config_path(self, *, config_str: str, target_config_path: str) -> str:
        config = ConfigParser()
        config.read_string(config_str)
        #
        # set the configpath value to target_config_path
        #
        config["config"]["path"] = target_config_path
        self.app_config.logger.debug(f"Config path: path {target_config_path}")
        #
        # write the configpath to string
        #
        string_buffer = io.StringIO()
        config.write(string_buffer)
        config_str = string_buffer.getvalue()
        return config_str

    def delete_project(self, *, api_key: str, name: str) -> None:
        if api_key is None:
            raise ValueError("API key cannot be None")
        if name is None:
            raise ValueError("Project name cannot be None")
        self.app_config.logger.info(f"Delete proj: {name}: key {api_key}")

        key = self.key_manager.get_key_data(api_key)
        if not key:
            raise ValueError("Invalid API key")
        config_file_paths = key.config_file_paths
        if name not in config_file_paths:
            raise ValueError(f"Config '{name}' not found.")

        config_file_path = config_file_paths[name]
        project_path_to_delete = os.path.dirname(os.path.dirname(config_file_path))
        self.app_config.logger.info(f"Delete proj: {name}: config {config_file_path}")
        #
        # TODO: save a last backup zip of the project
        #
        if os.path.isdir(project_path_to_delete):
            shutil.rmtree(project_path_to_delete)
        del config_file_paths[name]
        self.key_manager.update_key_data(api_key, key)
        self.app_config.logger.info(f"Delete proj: {name} complete")

    def get_project_names(self, api_key: str) -> list[str]:
        if api_key is None:
            raise ValueError("API key cannot be None")
        key = self.key_manager.get_key_data(api_key)
        if not key:
            raise ValueError("Invalid API Key")
        return {"names": list(key.config_file_paths.keys())}

    def get_project_config_path(self, *, api_key: str, project_name: str) -> str:
        if not api_key:
            raise ValueError("API key cannot be None")
        if not project_name:
            raise ValueError("Project name cannot be None")
        key = self.key_manager.get_key_data(api_key)
        if not key:
            raise ValueError("Invalid API Key")
        config_file_paths = key.config_file_paths
        if project_name not in config_file_paths:
            raise ValueError(f"Project '{project_name}' not found.")
        return config_file_paths[project_name]

    def set_project_config(self, api_key: str, name: str, config_str: str) -> None:
        if api_key is None:
            raise ValueError("API key cannot be None")
        if name is None:
            raise ValueError("Project name cannot be None")
        if config_str is None:
            raise ValueError("Project config cannot be None")
        key = self.key_manager.get_key_data(api_key)
        if not key:
            raise ValueError("Invalid API Key")
        config_path = self.get_project_config_path(project_name=name, api_key=api_key)
        projects_dir = self.projects_dir
        hash_key = self.key_manager.hash_key(api_key)
        config_str = self._modify_config(
            config_str=config_str,
            config_path=config_path,
            project_name=name,
            projects_dir=projects_dir,
            hash_key=hash_key,
        )
        with open(config_path, "w") as f:
            f.write(config_str)
        self.key_manager.update_key_data(api_key, key)
        self.app_config.logger.debug(
            f"Set proj config: name {name}, config {config_path}"
        )

    def get_project_config(self, api_key: str, name: str) -> str:
        if api_key is None:
            raise ValueError("API key cannot be None")
        if name is None:
            raise ValueError("Project name cannot be None")
        key = self.key_manager.get_key_data(api_key)
        if not key:
            raise ValueError("Invalid API Key {api_key}")
        config_file_paths = key.config_file_paths
        if name not in config_file_paths:
            raise ValueError(f"Config '{name}' not found.")
        p = config_file_paths[name]
        if not Nos(p).exists():
            raise ValueError(f"Config not found at project path {p}")
        with open(p, "r") as f:
            return f.read()

    def _get_env_path(self, api_key: str, name: str) -> str:
        key = self.key_manager.get_key_data(api_key)
        if not key:
            raise ValueError("Invalid API Key {api_key}")
        config_file_paths = key.config_file_paths
        if name not in config_file_paths:
            raise ValueError(f"Config '{name}' not found.")

        project_dir = os.path.dirname(os.path.dirname(config_file_paths[name]))
        self.app_config.logger.debug(
            f"Env path: {name}, key {api_key}, proj dir {project_dir}"
        )
        return os.path.join(project_dir, "config", "env.json")

    def set_env_file(self, api_key: str, name: str, env_str: str) -> None:
        if env_str is None:
            raise ValueError("Env file content cannot be None")
        env_path = self._get_env_path(api_key, name)
        self.app_config.logger.info(
            f"Set env path: {name}, key {api_key}, env_path {env_path}"
        )
        dirpath = os.path.dirname(env_path)
        nos = Nos(dirpath)
        if not nos.exists():
            nos.makedir()
        with open(env_path, "w") as f:
            f.write(env_str)

    def get_env_file(self, api_key: str, name: str) -> str:
        env_path = self._get_env_path(api_key, name)
        if not os.path.exists(env_path):
            with open(env_path, "w") as file:
                json.dump({}, file, indent=4)
        self.app_config.logger.debug(
            f"Get env path: {name}, key {api_key}, env_path {env_path}"
        )
        with open(env_path, "r") as f:
            return f.read()

    def set_env_key(self, api_key: str, name: str, key: str, value: str) -> None:
        if key is None:
            raise ValueError("Key cannot be None")
        env_path = self._get_env_path(api_key, name)
        if not os.path.exists(env_path):
            with open(env_path, "w") as file:
                json.dump({}, file, indent=4)
        with open(env_path, "r") as f:
            data = json.load(f)
        data[key] = value
        self.app_config.logger.info(
            f"Set env key: {name}, key {key}, value {value}, env_path {env_path}"
        )
        with open(env_path, "w") as f:
            json.dump(data, f, indent=4)

    #
    # untested! do not use yet.
    #
    def set_config_key(
        self, *, api_key: str, project_name: str, section: str, name: str, value: str
    ) -> None:
        if api_key is None:
            raise ValueError("API key cannot be None")
        if name is None:
            raise ValueError("Name of value cannot be None")
        if project_name is None:
            raise ValueError("Project name cannot be None")
        if section not in [
            "csvpath_files",
            "csv_files",
            "errors",
            "logging",
            "config",
            "cache",
            "results",
            "inputs",
            "listeners",
            "sftp",
            "openlineage",
            "slack",
        ]:
            raise ValueError("Section is not allowed")
        if section == "listeners" and name != "groups":
            raise ValueError("Named value is not allowed")
        path = self.get_project_config_path(api_key=api_key, project_name=project_name)
        with open(path, "r") as file:
            config_str = file.read()
        config = ConfigParser()
        config.read_string(config_str)
        if section not in config:
            config.add_section(section)
        config[section][name] = value
        string_buffer = io.StringIO()
        config.write(string_buffer)
        config_str = string_buffer.getvalue()
        hash_key = self.key_manager.hash_key(api_key)
        #
        # this is probably a good idea. would be nice to not do it, because lazy, but that is
        # risky or complicating.
        #
        config_str = self._modify_config(
            config_str=config_str,
            config_path=path,
            project_name=project_name,
            projects_dir=self.projects_dir,
            hash_key=hash_key,
        )
        with open(path, "w") as file:
            file.write(config_str)

    def add_file(
        self, api_key: str, name: str, file_path: str, file_content: bytes
    ) -> None:
        if file_path is None:
            raise ValueError("File path cannot be None")
        if file_content is None:
            raise ValueError("File content cannot be None")

        if file_path in ["config/config.ini", "config/env.json"]:
            raise ValueError(f"Cannot modify protected file: {file_path}")

        max_size_kb = int(
            self.app_config.get(section="server", name="max_file_size_kb", default=1024)
        )
        if len(file_content) > max_size_kb * 1024:
            raise ValueError(f"File size exceeds the limit of {max_size_kb}KB")

        project_path = self.get_project_path(api_key, name)
        full_path = os.path.join(project_path, file_path)

        os.makedirs(os.path.dirname(full_path), exist_ok=True)

        self.app_config.logger.info(
            f"Add proj file: {name}, key {api_key}, full_path {full_path}, file_path {file_path}"
        )
        with open(full_path, "wb") as f:
            f.write(file_content)

    def get_file(self, api_key: str, name: str, file_path: str) -> bytes:
        if file_path is None:
            raise ValueError("File path cannot be None")
        if file_path in ["config/config.ini", "config/env.json"]:
            raise ValueError(f"Cannot access protected file: {file_path}")

        project_path = self.get_project_path(api_key, name)
        full_path = os.path.join(project_path, file_path)

        if not os.path.exists(full_path):
            raise ValueError(f"File not found: {file_path}")

        self.app_config.logger.debug(
            f"Get proj file: {name}, key {api_key}, full_path {full_path}, file_path {file_path}"
        )
        with open(full_path, "rb") as f:
            return f.read()
