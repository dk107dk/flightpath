class Formatter:
    """
    - every \n ends a <div>
    - a '-' looks ahead for ---- CSVPATH ----
    - a '---- CSVPATH ----' is wrapped in a div
    - a \t is replaced by a <span class='tab'></span>
    - two or more spaces are replaced by a <span class='spaces s-N'></span>
      where N is the number of spaces
    """

    CSVPATH = "---- CSVPATH ----"
    KEYWORD_LINKS = {
        "count_headers(": "https://github.com/dk107dk/csvpath/blob/main/docs/functions/count_headers.md",
        "print(": "https://github.com/dk107dk/csvpath/blob/main/docs/functions/print.md",
        "concat(": "https://github.com/dk107dk/csvpath/blob/main/docs/functions/string_functions.md",
        "exists(": "https://github.com/dk107dk/csvpath/blob/main/docs/functions/empty.md",
        "empty(": "https://github.com/dk107dk/csvpath/blob/main/docs/functions/empty.md",
        "import(": "https://github.com/dk107dk/csvpath/blob/main/docs/functions/import.md",
        "regex(": "https://github.com/dk107dk/csvpath/blob/main/docs/functions/regex.md",
        "not(": "https://github.com/dk107dk/csvpath/blob/main/docs/functions/not.md",
        "and(": "https://github.com/dk107dk/csvpath/blob/main/docs/functions/andor.md",
        "sum(": "https://github.com/dk107dk/csvpath/blob/main/docs/functions/sum.md",
        "max(": "https://github.com/dk107dk/csvpath/blob/main/docs/functions/max.md",
        "now(": "https://github.com/dk107dk/csvpath/blob/main/docs/functions/now.md",
        "date(": "https://github.com/dk107dk/csvpath/blob/main/docs/functions/date.md",
        "datetime(": "https://github.com/dk107dk/csvpath/blob/main/docs/functions/date.md",
        "between(": "https://github.com/dk107dk/csvpath/blob/main/docs/functions/between.md",
        "failed(": "https://github.com/dk107dk/csvpath/blob/main/docs/functions/fail.md",
        "fail(": "https://github.com/dk107dk/csvpath/blob/main/docs/functions/fail.md",
        "last(": "https://github.com/dk107dk/csvpath/blob/main/docs/functions/last.md",
        "total_lines(": "https://github.com/dk107dk/csvpath/blob/main/docs/functions/total_lines.md",
    }

    @classmethod
    def add_keyword_links(cls, txt: str) -> str:
        for k, v in cls.KEYWORD_LINKS.items():
            k2 = k[0 : (len(k) - 1)]
            v = f"""<a class='keyword-link' target='_blank' href='{v}'>{k2}</a>("""
            txt = txt.replace(k, v)
        return txt

    @classmethod
    def add_html(cls, txt: str) -> str:
        #
        # we should never need this wrap, but seen once, we'll be defensive
        #
        txt = f"{txt}"
        csvl = len(Formatter.CSVPATH)
        formatted = ["<", "d", "i", "v", ">", "<", "d", "i", "v", ">"]
        spaces = ""
        skip = 0
        for i, ch in enumerate(txt):
            if skip > 0:
                skip -= 1
                continue
            if ch == "\t" or ch == "\r":
                cls.punchout(formatted, ch)
                spaces = ""
            elif ch == " ":
                spaces += " "
            elif ch == "\n":
                cls.wrap(formatted, ch)
                if spaces == 1:
                    spaces = ""
            elif ch == "-":
                if len(txt) - i > csvl and txt[i : (i + csvl)] == Formatter.CSVPATH:
                    formatted += [c for c in "<div class='csvpath-separator'>"]
                    formatted += [c for c in Formatter.CSVPATH]
                    formatted += [c for c in "</div>"]
                    skip += csvl
                    if spaces == 1:
                        spaces = ""
                else:
                    formatted.append("-")
            else:
                if len(spaces) > 1:
                    formatted += [
                        c for c in f"<span class='spaces s-{len(spaces)}'></span>"
                    ]
                    spaces = ""
                elif spaces == " ":
                    formatted.append(" ")
                    spaces = ""
                formatted.append(ch)
        for i in range(0, 2):
            formatted += [c for c in "</div>"]
        return "".join(formatted)

    @classmethod
    def punchout(cls, formatted, ch) -> None:
        if ch == "\t":
            formatted += [c for c in "<span class='tab'></span>"]
        elif ch == "\r":
            pass

    @classmethod
    def wrap(cls, formatted, ch) -> None:
        if ch == "\n":
            formatted += [c for c in "</div><div>"]
