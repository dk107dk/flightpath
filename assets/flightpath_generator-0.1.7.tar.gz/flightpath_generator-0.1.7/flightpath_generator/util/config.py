import os
from os import environ
import datetime
from configparser import RawConfigParser
from .exceptions import ConfigurationException


class Config:
    CONFIG: str = "config/generator.ini"
    GENERATOR_CONFIG_FILE_ENV: str = "GENERATOR_CONFIG_PATH"

    DEFAULT_CONFIG = """
[storage]
root = config/storage/dev

[version]
#
# context 8, template 1 is for answering questions about CsvPath
#
question.context = 8
question.prompt_template = 1
#
# context 9, template 3 testdata is for creating test data matching a csvpath
#
testdata.context = 9
testdata.prompt_template = 3
#
# context 7, template 2 is the go-to-market for full generation of sample-file validation
#
validation.context = 7
validation.prompt_template = 2

[generations]
limit = 20
turns_limit = 6
    """

    def __init__(self, configpath:str=None):
        self._configpath = configpath if configpath is not None else environ.get(Config.GENERATOR_CONFIG_FILE_ENV)
        self.log_file = "log/generator.log"
        self._load_time = None
        if self._configpath is None:
            self._configpath = Config.CONFIG
        self._config = None
        self.load()

    def __str__(self) -> str:
        return f"""Config(path: {self._configpath}, log: {self.log_file}, loaded at: {self._load_time}, prod: {self.get('env', 'prod')} root: {self.get('storage', 'root')})
"""

    def dump_config_info(self) -> None:
        print(f"{self}")

    def load(self):
        self._config = RawConfigParser()
        if not os.path.exists(self._configpath):
            with open(self._configpath, "w") as file:
                file.write(Config.DEFAULT_CONFIG)
        self._load_config()

    def set_config_path_and_reload(self, path: str) -> None:
        self._configpath = path
        self.load()

    @property
    def config_path(self) -> str:
        return self._configpath

    def get(self, section: str, name: str, default: str = None):
        if self._config is None:
            raise ConfigurationException("No config object available")
        try:
            s = self._config[section][name]
            s = s.strip()
            ret = None
            if s.find(",") > -1:
                ret = [s.strip() for s in s.split(",")]
            else:
                ret = s
            return ret
        except KeyError:
            return default

    def _load_config(self):
        if not os.path.exists(self._configpath):
            raise ValueError(f"No config found at {self._configpath}")
        self._config.read(self._configpath)
        self.log_file = self.get("logging", "log_file", self.log_file)
        self._load_time = datetime.datetime.now()

    # ======================================

    @property
    def configpath(self) -> str:
        return self._configpath

    @configpath.setter
    def configpath(self, path: str) -> None:
        self._configpath = path
