import os
from flightpath_generator.util.exceptions import PromptException
from flightpath_generator.util.counter_utility import CounterUtility
from flightpath_generator.util.file_utility import FileUtility
from flightpath_generator.prompts.block import Block


class Prompt:
    EXAMPLE_CHAR_MAX = 8192
    RULES_CHAR_MAX = 1024
    EXAMPLE_NAME = "example.txt"
    RULES_NAME = "rules.txt"

    #
    # prompts have two parts: examples (data) and rules (input
    # from user).
    #
    # there is a prompt_template that may have var substitution
    # markers in the form %%%varname%%%. after the template is
    # applied the prompt files are saved for future reference.
    #
    # the context is "applied" to the prompt as well as a kind of
    # super wrapper that includes any number of files that create
    # message turns. all of it together is saved in the generation
    # as the outbound-msg.json.
    #
    def __init__(self, *, generator, name=None, template:str=0):
        self._generator = generator
        self._name = None
        self._csv_example: str = None
        self._example_path: str = None
        self._rules: str = None
        self._rules_path: str = None
        self.name = name

    def new_name(self) -> str:
        return f"{CounterUtility.increment()}"

    @property
    def generator(self) -> None:
        return self._generator

    def __str__(self) -> str:
        return f"""{self.__class__}: name: {self._name}: {self._example_path}, {self._rules_path}"""

    def to_json(self) -> str:
        e = self.get_example_block()
        r = self.get_rules_block()
        j = ""
        j += e.to_json()
        if r is not None:
            j += ","
            j += r.to_json()
        return j

    def save(self, path: str = None) -> None:
        if self.rules is None or self.example is None:
            raise PromptException(
                "Rules and example must exist. The empty string is acceptable."
            )
        #
        # getting the text from the blocks makes sure we apply the template.
        # we're saving the prompt inputs. the context will format them into a
        # message block. the goal is to capture what will be sent. we're not
        # trying to save the raw rules and examples string we received pre-
        # template.
        #
        rules = self.get_rules_block().text
        example = self.get_example_block().text
        FileUtility.save(path=self.rules_path, content=rules)
        FileUtility.save(path=self.example_path, content=example)

    def apply_template(self, *, name:str, values:dict) -> None:
        #
        # name is either example or rules
        #
        #
        # when we apply a template we do a very simple variable sub using
        # the form %%%varname%%%. this is way simpler than jinja and
        # presumably is (much?) quicker, though I haven't checked that.
        #
        if values is None:
            raise ValueError("Values cannot be None")
        t = self.template(name)
        if len(values) == 0 and t.find("%%%") < 0:
            raise ValueError(f"Not enough values in {values}")
        if len(values) == 0:
            return t
        for k, v in values.items():
            t = t.replace(f"%%%{k}%%%", v)
        if t.find("%%%") > -1:
            raise ValueError(f"Values didn't match all replacement tokens: {values}")
        return t

    def template(self, name:str) -> str:
        v = self.generator.version_key
        version = self.generator.config.get("version", f"{v}.prompt_template")
        path = os.path.join(self.generator.prompt_manager.prompt_template_root, version, name)
        if not path.endswith(".txt"):
            path = f"{path}.txt"
        with open(path, "r") as file:
            return file.read()

    def get_example_block(self) -> Block:
        b = self._get_block(ttype="example", content=self.example)
        return b

    def get_rules_block(self) -> Block:
        b = self._get_block(ttype="rules", content=self.rules )
        return b

    def _get_block(self, *, ttype:str, content:str) -> Block:
        if content is None:
            content = ""
        values = {}
        values[ttype] = content
        txt = self.apply_template(name=ttype, values=values)
        block = Block()
        block.block_type = "text"
        block.text = txt
        return block

    @property
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, name:str=None) -> None:
        if name is None:
            self._name = self.new_name()
        else:
            self._name = name

    @property
    def rules(self) -> str:
        if self._rules is None:
            print("loading rules")
            txt = self.load_rules()
            self._rules = txt
        return self._rules

    @property
    def rules_path(self) -> str:
        if self._rules_path is None:
            self._rules_path = os.path.join(
                self.generator.prompt_manager.prompt_root, self.name
            )
            self._rules_path = os.path.join(self._rules_path, Prompt.RULES_NAME)
        return self._rules_path

    @rules_path.setter
    def rules_path(self, path: str) -> None:
        self._rules_path = path

    def load_rules(self) -> str:
        print(f"loading rules from {self.rules_path}")
        return FileUtility.load(
            path=self.rules_path,
            recurse=None,
            max_length=Prompt.RULES_CHAR_MAX,
            escape_quotes=True,
            default="",
        )

    @rules.setter
    def rules(self, text: str) -> None:
        self._rules = text

    @property
    def example_path(self) -> str:
        if self._example_path is None:
            path = self.generator.prompt_manager.prompt_root
            self._example_path = os.path.join(path, self.name)
            self._example_path = os.path.join(self._example_path, Prompt.EXAMPLE_NAME)
        return self._example_path

    @example_path.setter
    def example_path(self, path: str) -> None:
        self._example_path = path

    def _load_example(self, recurse=True) -> str:
        csv = FileUtility.load(
            path=self.example_path, max_length=Prompt.EXAMPLE_CHAR_MAX, max_lines=30
        )
        return csv

    @property
    def example(self) -> str:
        if self._csv_example is None:
            self._csv_example = self._load_example()
        return self._csv_example

    @example.setter
    def example(self, lines: str) -> None:
        e = self.apply_template(name="example", values = {"example":lines})
        self._csv_example = e
