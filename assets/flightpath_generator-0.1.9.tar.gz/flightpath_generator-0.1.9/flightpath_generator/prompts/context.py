import json
from typing import List
from flightpath_generator.util.exceptions import PromptException
from flightpath_generator.prompts.message import Message
from flightpath_generator.prompts.block import Block
from flightpath_generator.prompts.prompt import Prompt
from flightpath_generator.util.file_utility import FileUtility


class Context:
    MESSAGES_NAME = "messages.txt"

    def __init__(self, *, name, messages=None) -> None:
        if name is None:
            raise PromptException("Name cannot be None")
        self._name: str = name
        self._system_role = None
        self._background = {}
        self._summary = None
        self._messages = messages
        if self._messages is None:
            self._messages = []

    def __str__(self) -> str:
        return f"""Context(name={self._name},messages={self._messages})"""

    @property
    def background(self) -> dict:
        return self._background

    @property
    def summary(self) -> str:
        return self._summary

    @summary.setter
    def summary(self, summary: str) -> None:
        self._summary = summary

    @property
    def system_role(self) -> str:
        return self._system_role

    @system_role.setter
    def system_role(self, sys: str) -> None:
        self._system_role = sys

    def apply_background(self) -> None:
        if len(self._background) == 0:
            return
        for i, m in enumerate(self.messages):
            for j, b in enumerate(m.content):
                txt = b.text
                if txt is None:
                    continue
                for k, v in self._background.items():
                    txt = txt.replace(f"%%%{k}%%%", v)
                txt = txt.replace('"', r"\"")
                txt = txt.replace("\n", r"\n")
                b.text = txt

    def apply_prompt(self, prompt: Prompt) -> None:
        m = self.user_message()
        rules = prompt.get_rules_block()
        if rules is None:
            raise ValueError("Rules block cannot be None")
        example = prompt.get_example_block()
        if example is None:
            raise ValueError("Example block cannot be None")
        rules.append(example)
        m.add_content(rules)
        print(f"apply_promptx: m: {m}")
        self.apply_background()

    def user_message(self) -> Message:
        m = Message()
        self.add_message(m)
        m.role = "user"
        return m

    def assistant_message(self) -> Message:
        m = Message()
        self.add_message(m)
        m.role = "assistant"
        return m

    @property
    def name(self) -> str:
        return self._name

    @property
    def messages(self) -> List[Block]:
        return self._messages

    @messages.setter
    def messages(self, ms: List[Block]) -> None:
        self._messages = ms

    def add_message(self, message: Message) -> None:
        if message in self._messages:
            raise Exception(f"Cannot add a mesage twice: {message}")
        self._messages.append(message)

    def from_json(self, j:list) -> None:
        if j is None:
            raise ValueError("Json cannot be None")
        self.messages = None
        ms = []
        for x,m in enumerate(j):
            message = Message()
            message.role = m["role"]
            ms.append(message)
            blocks = []
            message.content = blocks
            lst = m["content"]
            if lst is None:
                if "tool_calls" in m:
                    message.tool_calls = m["tool_calls"]
            else:
                if isinstance(lst, str):
                    b = Block()
                    b.block_type = "text"
                    b.text = lst
                    blocks.append(b)
                else:
                    for y, _ in enumerate(lst):
                        b = Block()
                        b.block_type = _["type"]
                        b.text = _["text"]
                        blocks.append(b)

        self.messages = ms


    def messages_as_json(self):
        j = "["
        for i, m in enumerate(self._messages):
            j += m.to_json()
            if i < len(self._messages) - 1:
                j += ","
        j += "]"
        return j

    def json_friendly_messages(self):
        j = []
        for m in self.messages:
            j.append(m.__dict__())
        return j
