import os
import datetime
import json
import traceback
import importlib
import shutil

from ratelimit import limits
from csvpath import CsvPath
from csvpath.util.config import Config as CsvPathConfig
from csvpath.util.nos import Nos

from flightpath_generator.managers.context_manager import ContextManager
from flightpath_generator.managers.generation_manager import GenerationManager
from flightpath_generator.managers.prompt_manager import PromptManager
from flightpath_generator.prompts import Prompt, Context, Generation
from flightpath_generator.util.config import Config

from flightpath_generator.client.tools import GeneratorTool
from flightpath_generator.client.llm_client import LiteLLMClient


class StorageUtility:


    @classmethod
    def assure_paths(cls, generator) -> None:
        cls.assure_root(generator)
        #
        # we don't need to assure the context root or the prompt_templates because
        # we're unpacking the latest contexts.zip and prompt_templates.zip into
        # the root
        #
        #generator.context_manager.assure_context_root()
        generator.prompt_manager.assure_prompt_root()
        GenerationManager(generator).assure_generation_root()

    @classmethod
    def assure_root(cls, generator) -> None:
        if generator.root is None:
            raise ValueError(f"Storage root cannot be None")
        if not os.path.exists(generator.root):
           os.makedirs(generator.root)

    @classmethod
    def assure_context_and_templates(cls, generator) -> None:
        #
        # check if contexts and prompt_templates are missing or not at the library's version. if
        # so, copy them into place from within the generator package, so that they are unique to
        # the storage location of the given generator.ini.
        #
        v = cls.version()
        sv = cls.storage_version(generator)
        #
        # check the version of the lib and update if not equal to what is found
        #
        if v != sv:
            cls.copy_context_and_templates(generator)

    @classmethod
    def version(cls) -> str:
        #
        # gets the build from a file that build.sh creates in flightpath_generator.storage
        # that has the version number from pyproject.toml.
        #
        path = importlib.resources.files("flightpath_generator.storage").joinpath("version.txt")
        if os.path.exists(path):
            version = None
            with open(path, "r") as file:
                version = file.read()
            return version
        raise ValueError(f"No version.txt at {path}")

    @classmethod
    def storage_version(cls, generator) -> str:
        #
        # get the build from a file that is created from the self.version when the contexts
        # and prompt_templates are unpacked
        #
        path = os.path.join(generator.root, "version.txt")
        if os.path.exists(path):
            sv = None
            with open(path, "r") as file:
                sv = file.read()
            return sv
        else:
            #
            # copy the version file into place, but return None so the unpacking happens
            #
            v = importlib.resources.files("flightpath_generator.storage").joinpath("version.txt")
            shutil.copyfile(v, path)
            return None

    @classmethod
    def copy_context_and_templates(cls, generator):
        #
        # we need to copy from the package to the project. however, we want this to be
        # users can update their prompts; however, they should do that under a name
        # (usually a number) that stays out of the way of the numbers we use by default.
        # we'll replace whatever may be there with new.
        #
        cls._unpack_zip(
            root=generator.root,
            topath=generator.context_manager.context_root,
            name="contexts.zip"
        )
        cls._unpack_zip(
            root=generator.root,
            topath=generator.prompt_manager.prompt_template_root,
            name="prompt_templates.zip"
        )

    @classmethod
    def _unpack_zip(cls,*, root:str, topath:str, name:str) -> None:
        path = importlib.resources.files("flightpath_generator.storage").joinpath(name)
        #print(f"_unpack_zip: unpacking {path}")
        with importlib.resources.as_file(path) as zipfile:
            #print(f"_unpack_zip: rootpath: {root}")
            destpath = os.path.join( root, name)
            #print(f"_unpack_zip: copy from {path} to {destpath}")
            shutil.copyfile(path, destpath)
            #print(f"_unpack_zip: unpack archive from {destpath} to {topath}")
            shutil.unpack_archive(destpath, os.path.dirname(topath))



    @classmethod
    def cleanup_generations_if(cls, generator) -> None:
        n = generator.config.get("generations", "limit", -1)
        n = int(n)
        if n < 0:
            return
        mani = generator.manifest
        if len(mani) < n:
            return
        mani = mani[len(mani)-n:]
        generator.manifest = mani
        #
        # clean up prompts
        #
        prompts_path = os.path.join(generator.root, "prompts")
        nos = Nos(prompts_path)
        lst = nos.listdir(dirs_only=True)
        for _ in lst:
            _ = os.path.join(prompts_path, _)
            found = False
            for p in mani:
                if _ == p.get("prompt"):
                    found = True
                    continue
            if not found:
                nos = Nos(_).remove()
        #
        # clean up generations
        #
        gens_path = os.path.join(generator.root, "generations")
        nos = Nos(gens_path)
        lst = nos.listdir(dirs_only=True)
        for _ in lst:
            _ = os.path.join(gens_path, _)
            found = False
            for p in mani:
                if _ == p.get("generation"):
                    found = True
                    continue
            if not found:
                nos = Nos(_).remove()


