from abc import ABC, abstractmethod
import tempfile
import os
import traceback

from csvpath import CsvPath
from csvpath.util.printer import TestPrinter
from flightpath_generator.prompts import Generation
from flightpath_generator.client.tools import GeneratorTool


class LiteLLMRunTool(GeneratorTool):

    NAME = "check_csvpath_works_correctly"

    def __init__(self) -> None:
        GeneratorTool.TOOLS[LiteLLMRunTool.NAME] = self

    def tool_definition(self) -> dict:
        props = {
            "csvpath": {
                "type": "string",
                "description": "The csvpath statement to run",
            },
            "csv": {
                "type": "string",
                "description": "Test CSV data",
            }
        }
        return self._tool_def(
            name=LiteLLMRunTool.NAME,
            desc="Runs a csvpath statement to make sure it works correctly",
            properties=props,
            required=["csvpath", "csv"]
        )

    def name(self) -> str:
        return LiteLLMSyntaxTool.NAME

    def use(self, generation:Generation, tool_call, args:dict) -> dict:
        if not "csv" in args:
            raise ValueError("No CSV data provided")
        if not "csvpath" in args:
            raise ValueError("No csvpath statement provided")
        msg, error = self._use(
            id=tool_call.id,
            data=args["csv"],
            csvpath=args["csvpath"]
        )
        if error is not None:
            generation.add_error(error)
        return msg

    def _use(self, *, id:str, data:str, csvpath:str) -> tuple[dict, str|None]:
        function_response = None
        error = None
        csvpath = csvpath.strip()
        try:
            name = None
            with tempfile.NamedTemporaryFile(mode='w+t', delete=False, suffix='.csv') as file:
                name = file.name
                file.write(data)
                file.flush()
                csvpath = f"~ validation-mode:print,collect,raise ~${name}{csvpath[1:]}"
                c = CsvPath()
                config = c.config
                t = TestPrinter()
                c.printers = [t]
                c.parse(csvpath)
                s, m = c._find_scan_and_match_parts(csvpath)
                #
                # put data in temp file
                #
                lines = c.collect()
                errors = c.errors
                vars = c.variables
                prints = t.lines
                #
                #
                #
                output = []
                output.append("Run outputs:\n\n")
                output.append("Matched data lines:")
                if lines and len(lines) > 0:
                    for _ in lines:
                        output.append(_)
                else:
                    output.append("None")

                output.append("\nErrors reported:")
                if errors and len(errors) > 0:
                    for _ in errors:
                        output.append(_)
                else:
                    output.append("None")

                output.append("\nVariables:")
                if vars and len(vars) > 0:
                    for _ in vars:
                        output.append(_)
                else:
                    output.append("None")


                output.append("\nPrintout lines:")
                if prints and len(prints) > 0:
                    for _ in prints:
                        output.append(_)
                else:
                    output.append("None")

                output = [str(_) for _ in output]
                function_response = "\n".join(output)

            os.remove(name)

        except Exception as ex:
            print(f">>> tool error: >>>{ex}<<<")
            function_response = f"Error: {ex}"
            error = traceback.format_exc()
        ret = {
            "tool_call_id": id,
            "role": "tool",
            "name": LiteLLMRunTool.NAME,
            "content": function_response,
        }
        return (ret, error)


