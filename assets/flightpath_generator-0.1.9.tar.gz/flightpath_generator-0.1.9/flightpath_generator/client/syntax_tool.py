import traceback
from csvpath import CsvPath
from flightpath_generator.prompts import Generation
from flightpath_generator.client.tools import GeneratorTool


class LiteLLMSyntaxTool(GeneratorTool):

    NAME = "check_csvpath_is_valid"

    def __init__(self) -> None:
        GeneratorTool.TOOLS[LiteLLMSyntaxTool.NAME] = self

    def tool_definition(self) -> dict:
        props = {
            "csvpath": {
                "type": "string",
                "description": "The csvpath statement to check"
            }
        }
        return self._tool_def(
            name=LiteLLMSyntaxTool.NAME,
            desc="Compiles a csvpath statement to make sure it is syntactically valid",
            properties=props,
            requried=["csvpath"]
        )

    def name(self) -> str:
        return LiteLLMSyntaxTool.NAME

    def use(self, generation:Generation, tool_call, args:dict) -> dict:
        function_response = "No errors in csvpath"
        try:
            c = CsvPath()
            c.modes.validation_mode.value = "raise"
            matcher = c.parse(args["csvpath"], disposably=True)
            matcher.check_valid()
        except Exception as ex:
            generation.add_error(traceback.format_exc())
            print(f">>> tool error: caught in generation {generation.name}: >>>{ex}<<<")
            function_response = f"Error: {ex}"
        return {
            "tool_call_id": tool_call.id,
            "role": "tool",
            "name": tool_call.function.name,
            "content": function_response,
        }




