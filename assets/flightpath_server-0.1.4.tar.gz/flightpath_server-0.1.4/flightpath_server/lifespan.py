import os
from contextlib import asynccontextmanager
from fastapi import FastAPI
from typing import AsyncGenerator
from flightpath_server.config.app_config import AppConfig


@asynccontextmanager
async def lifespan(app: FastAPI, config_path:str=None) -> AsyncGenerator[None, None]:
    app_config = AppConfig.me(config_path)
    app_config.logger.info("Starting")
    try:
        app.state.app_config = app_config
        yield
        app.state.app_config.logger.info("Shutting down FlightPath Server")
    except Exception as ex:
        import traceback
        print(traceback.format_exc())
        app_config.logger.error(f"Error in lifespan: {ex}")
