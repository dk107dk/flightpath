import os
import json
from datetime import datetime
from uuid import UUID, uuid4

from csvpath import CsvPaths
from csvpath.util.log_utility import LogUtility as lout

from flightpath_server.keys.key_manager import KeyManager
from flightpath_server.config.app_config import AppConfig


class CsvPathsLoader:
    @classmethod
    def get_csvpaths(
        self, *, app_config: AppConfig, api_key: str, project_name: str
    ) -> CsvPaths:
        if app_config is None:
            raise ValueError("App config cannot be None")
        if api_key is None:
            raise ValueError("Api key cannot be None")
        if project_name is None:
            raise ValueError("Project name cannot be None")
        self.key_manager = KeyManager(app_config=app_config)
        key_data = self.key_manager.get_key_data(api_key)
        if key_data is None:
            raise ValueError("Invalid key")
        if project_name not in key_data.config_file_paths:
            raise ValueError("Unknown project name")
        config_path = key_data.config_file_paths[project_name]
        csvpaths = CsvPaths()
        csvpaths.config.set_config_path_and_reload(config_path)
        csvpaths.project = project_name
        csvpaths.project_context = self.key_manager.hash_key(api_key)
        name = f"{api_key}.{project_name}.logger"
        csvpaths.logger = lout.config_logger(
            config=csvpaths.config,
            name=name,
            level=csvpaths.config.get(section="logging", name="level"),
        )
        csvpaths.logger.info(
            f"CsvPathsLoader: log path: {csvpaths.config.get(section='logging', name='log_file')}"
        )
        self._print_log_handlers(csvpaths)
        return csvpaths

    @classmethod
    def _print_log_handlers(cls, csvpaths) -> None:
        logger = csvpaths.logger
        print(f"Logger: {logger}")
        import logging

        for handler in logger.handlers:
            if isinstance(handler, logging.FileHandler):
                print(f"Logging to file: {handler.baseFilename}")
            elif isinstance(handler, logging.StreamHandler):
                print(f"Logging to stream: {handler.stream.name}")
            elif isinstance(handler, logging.handlers.RotatingFileHandler):
                print(f"Logging to rotating file: {handler.baseFilename}")
            elif isinstance(handler, logging.handlers.TimedRotatingFileHandler):
                print(f"Logging to timed rotating file: {handler.baseFilename}")
            else:
                print(f"Logging to unknown handler type: {type(handler)}")
