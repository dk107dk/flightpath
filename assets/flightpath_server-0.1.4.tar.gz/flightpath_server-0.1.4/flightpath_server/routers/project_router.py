import base64
from pydantic import BaseModel
from fastapi import APIRouter, Depends, HTTPException

from flightpath_server.projects.project_manager import ProjectManager
from flightpath_server.keys.key_manager import KeyManager
from flightpath_server.keys.key import Key
from flightpath_server.config.app_config import AppConfig
from flightpath_server.dependencies import get_api_key, get_key_manager, get_optional_api_key
from flightpath_server.dependencies import get_app_config

project_router = APIRouter()

class NewProjectRequest(BaseModel):
    name: str
    config_str: str

class DeleteProjectRequest(BaseModel):
    name: str

class SetProjectConfigRequest(BaseModel):
    name: str
    config_str: str

class GetProjectConfigRequest(BaseModel):
    name: str

class SetEnvFileRequest(BaseModel):
    name: str
    env_str: str

class GetEnvFileRequest(BaseModel):
    name: str

class SetEnvKeyRequest(BaseModel):
    name: str
    key: str
    value: str

class AddFileRequest(BaseModel):
    name: str
    file_path: str
    file_content: str

class GetFileRequest(BaseModel):
    name: str
    file_path: str

class SuccessResponse(BaseModel):
    message: str

class FileResponse(BaseModel):
    file_content: str

class ProjectNamesResponse(BaseModel):
    names: list[str]



@project_router.post("/new_project")
async def new_project(
    request: NewProjectRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
    key_manager: KeyManager = Depends(get_key_manager)
) -> SuccessResponse:
    """Creates a project associated with an API key. Projects are essentially config files; however, they can hold other arbitrary files as needed. The config files in a project are config.ini, the main CsvPath Framework config file, and env.json, a file that stands in for OS env vars. """
    try:
        project_manager = ProjectManager(app_config=app_config, key_manager=key_manager)
        path = project_manager.create_new_project(api_key=api_key, name=request.name, config_str=request.config_str)
        #
        # not passing the path back because atm it isn't clear it would help and security may factor
        #
        return {"message": f"Config '{request.name}' created."}
    except ValueError as e:
        raise app_config.http_error(name=__name__, code=400, msg=str(e))

@project_router.post("/delete_project")
async def delete_project(
    request: DeleteProjectRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
    key_manager: KeyManager = Depends(get_key_manager)
) -> SuccessResponse:
    """ Permanently deletes a project with no recovery possible."""
    try:
        project_manager = ProjectManager(app_config=app_config, key_manager=key_manager)
        project_manager.delete_project(api_key=api_key, name=request.name)
        return {"message": f"Config '{request.name}' deleted."}
    except ValueError as e:
        raise app_config.http_error(name=__name__, code=400, msg=str(e))

@project_router.post("/set_project_config")
async def set_project_config(
    request: SetProjectConfigRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
    key_manager: KeyManager = Depends(get_key_manager)
) -> SuccessResponse:
    """ Sets the config file for a project. This is the CsvPath Framework config.ini. FlightPath Server modifies the uploaded config file to make it safe for a multi-project, multi-user server environment. In particular, local file access is turned off by default. Unless you configure permission, your files must be loaded from one of the other backends, SFTP, S3 Azure Blob, or Google Cloud Storage.
    """
    try:
        project_manager = ProjectManager(app_config=app_config, key_manager=key_manager)
        project_manager.set_project_config(api_key, request.name, request.config_str)
        return {"message": f"Config '{request.name}' updated."}
    except ValueError as e:
        raise app_config.http_error(name=__name__, code=400, msg=str(e))

@project_router.post("/get_project_names")
async def get_project_names(
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
    key_manager: KeyManager = Depends(get_key_manager)
) -> ProjectNamesResponse:
    """ Returns a list of project names associated with the API key used for the request """
    try:
        project_manager = ProjectManager(app_config=app_config, key_manager=key_manager)
        return project_manager.get_project_names(api_key)
    except ValueError as e:
        raise app_config.http_error(name=__name__, code=400, msg=str(e))

@project_router.post("/get_project_config")
async def get_project_config(
    request: GetProjectConfigRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
    key_manager: KeyManager = Depends(get_key_manager)
) -> str:
    """ Returns the config.ini of a project, overwriting it if already present."""
    try:
        project_manager = ProjectManager(app_config=app_config, key_manager=key_manager)
        return project_manager.get_project_config(api_key, request.name)
    except ValueError as e:
        raise app_config.http_error(name=__name__, code=400, msg=str(e))

@project_router.post("/set_env_file")
async def set_env_file(
    request: SetEnvFileRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
    key_manager: KeyManager = Depends(get_key_manager)
) -> SuccessResponse:
    """Sets the env.json file, overwriting it if already present. `env.json` holds values that you would otherwise get from OS environment variables. Because FlightPath Server is a multi-project environment the OS env vars are not used. Instead when you deploy a project you copy the env vars into env.json, where they can be used in exactly the same way."""
    try:
        project_manager = ProjectManager(app_config=app_config, key_manager=key_manager)
        project_manager.set_env_file(api_key, request.name, request.env_str)
        return {"message": f"Environment file for project '{request.name}' updated."}
    except ValueError as e:
        raise app_config.http_error(name=__name__, code=400, msg=str(e))

@project_router.post("/get_env_file")
async def get_env_file(
    request: GetEnvFileRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
    key_manager: KeyManager = Depends(get_key_manager)
) -> str:
    """Returns a project's env.json file."""
    try:
        project_manager = ProjectManager(app_config=app_config, key_manager=key_manager)
        return project_manager.get_env_file(api_key, request.name)
    except ValueError as e:
        raise app_config.http_error(name=__name__, code=400, msg=str(e))

@project_router.post("/set_env_key")
async def set_env_key(
    request: SetEnvKeyRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
    key_manager: KeyManager = Depends(get_key_manager)
) -> SuccessResponse:
    """Sets an variable in env.json that can be used within a project's config.ini file in the same way as an OS env var. """
    try:
        project_manager = ProjectManager(app_config=app_config, key_manager=key_manager)
        project_manager.set_env_key(api_key, request.name, request.key, request.value)
        return {"message": f"Environment key '{request.key}' set for project '{request.name}'."}
    except ValueError as e:
        raise app_config.http_error(name=__name__, code=400, msg=str(e))

@project_router.post("/add_file")
async def add_file(
    request: AddFileRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
    key_manager: KeyManager = Depends(get_key_manager)
) -> SuccessResponse:
    """ Stores an arbitrary base64 encoded file in a project. The file can go in a folder, which is created if needed, but it cannot be put in the config folder. """
    try:
        project_manager = ProjectManager(app_config=app_config, key_manager=key_manager)
        file_content = base64.b64decode(request.file_content)
        project_manager.add_file(api_key, request.name, request.file_path, file_content)
        return {"message": f"File '{request.file_path}' added to project '{request.name}'."}
    except ValueError as e:
        raise app_config.http_error(name=__name__, code=400, msg=str(e))
    except Exception as e:
        raise app_config.http_error(name=__name__, code=500, msg=str(e))

@project_router.post("/get_file")
async def get_file(
    request: GetFileRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
    key_manager: KeyManager = Depends(get_key_manager)
) -> FileResponse:
    """ Returns a base64 encoded file from the project. The file cannot be in the config directory. Keep in mind that you cannot get named-files, named-paths group files, or results using this endpoint. Those files aren't __in__ the project, even if they were generated by the project. """
    try:
        project_manager = ProjectManager(app_config=app_config, key_manager=key_manager)
        file_content = project_manager.get_file(api_key, request.name, request.file_path)
        encoded_content = base64.b64encode(file_content).decode('utf-8')
        return {"file_content": encoded_content}
    except ValueError as e:
        raise app_config.http_error(name=__name__, code=400, msg=str(e))
    except Exception as e:
        raise app_config.http_error(name=__name__, code=500, msg=str(e))




