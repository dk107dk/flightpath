import base64
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from flightpath_server.framework_manager import FrameworkManager
from flightpath_server.dependencies import get_api_key, get_app_config
from flightpath_server.config.app_config import AppConfig
from pydantic import BaseModel
import asyncio

find_router = APIRouter()


class FindRequest(BaseModel):
    project_name: str
    reference: str


class GetFileRequest(BaseModel):
    project_name: str
    reference: str


class GetResultRequest(BaseModel):
    project_name: str
    reference: str


class FindFilesResponse(BaseModel):
    files: list[str]


class FindFileResponse(BaseModel):
    file: str


class FindResultsResponse(BaseModel):
    results: list[str]


class FindResultResponse(BaseModel):
    result: str


@find_router.post("/find_files", tags=["find"])
def find_files(
    request: FindRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> FindFilesResponse:
    """Finds the paths of registered named-files based on a reference. References pick out files within the named-file based on arrival time, ordinal position, hash fingerprint, and/or file path."""
    try:
        framework_manager = FrameworkManager(
            api_key=api_key, project_name=request.project_name, app_config=app_config
        )
        ret = asyncio.run(
            framework_manager.find_registered_files(reference=request.reference)
        )
        if ret.get("success") is True:
            return {"files": ret.get("files")}
        else:
            errors = ret.get("errors")
            if errors is None:
                errors = (
                    [ret.get("message")]
                    if ret.get("message") is not None
                    else ["Unknown server error"]
                )
            elif not isinstance(errors, list):
                errors = [str(errors)]
            raise Exception(",".join(errors))
    except ValueError as e:
        import traceback

        print(traceback.format_exc())
        raise app_config.http_error(name=__name__, code=403, msg=str(e))
    except Exception as e:
        import traceback

        print(traceback.format_exc())
        raise app_config.http_error(name=__name__, code=500, msg=str(e))


@find_router.post("/get_file", tags=["find"])
def get_file(
    request: GetFileRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> FindFileResponse:
    """Returns the base64 encoded content of a file found by a named-file reference."""
    try:
        framework_manager = FrameworkManager(
            api_key=api_key, project_name=request.project_name, app_config=app_config
        )
        ret = asyncio.run(
            framework_manager.get_registered_file(reference=request.reference)
        )
        if ret.get("success") is True:
            file = ret.get("file")
            print(f"filessx is: {file}")
            if not isinstance(file, bytes):
                file = file.encode("utf-8")
            encoded_content = base64.b64encode(file).decode("utf-8")
            return {"file": encoded_content}
        else:
            errors = ret.get("errors")
            if errors is None:
                errors = (
                    [ret.get("message")]
                    if ret.get("message") is not None
                    else ["Unknown server error"]
                )
            elif not isinstance(errors, list):
                errors = [str(errors)]
            raise Exception(",".join(errors))
    except ValueError as e:
        import traceback

        print(traceback.format_exc())
        raise app_config.http_error(name=__name__, code=403, msg=str(e))
    except Exception as e:
        import traceback

        print(traceback.format_exc())
        raise app_config.http_error(name=__name__, code=500, msg=str(e))


@find_router.post("/find_results", tags=["find"])
def find_results(
    request: FindRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> FindResultsResponse:
    """Returns a single set of results found within the archive under a specific named-results name. Each
    result in the set represents the output of one csvpath within the named-paths group.
    (Named-results are named the same as the named-paths group that generated them.)
    Runs are identified by run date, ordinal position, and/or partial or exact file system path.
    Each result is a path to the data.csv output of a csvpath in the group from that run. In this case you
    cannot use a reference that points specifically to the data.csv or unmatched.csv files generated during
    a run. If your reference points to more than one run the first run found is the one results are returned for."""
    try:
        framework_manager = FrameworkManager(
            api_key=api_key, project_name=request.project_name, app_config=app_config
        )
        ret = asyncio.run(framework_manager.find_results(reference=request.reference))
        if ret.get("success") is True:
            return {"results": ret.get("results")}
        else:
            errors = ret.get("errors")
            if errors is None:
                errors = (
                    [ret.get("message")]
                    if ret.get("message")
                    else ["Unknown server error"]
                )
            elif not isinstance(errors, list):
                errors = [str(errors)]
            raise Exception(",".join(errors))
    except ValueError as e:
        import traceback

        print(traceback.format_exc())
        raise app_config.http_error(name=__name__, code=403, msg=str(e))
    except Exception as e:
        import traceback

        print(traceback.format_exc())
        raise app_config.http_error(name=__name__, code=500, msg=str(e))


@find_router.post("/get_result", tags=["find"])
def get_result(
    request: GetResultRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> FindResultResponse:
    """Returns the content of a run data file result based on a reference to the run. The content returned is the set of matching lines from the run. (Or, if so configured, the unmatched lines)."""
    try:
        framework_manager = FrameworkManager(
            api_key=api_key, project_name=request.project_name, app_config=app_config
        )
        ret = asyncio.run(framework_manager.get_result(reference=request.reference))
        if ret.get("success") is True:
            result = ret.get("result")
            return {"result": result}
        else:
            errors = ret.get("errors")
            if errors is None:
                errors = (
                    [ret.get("message")]
                    if ret.get("message") is not None
                    else ["Unknown server error"]
                )
            elif not isinstance(errors, list):
                errors = [str(errors)]
            raise Exception(",".join(errors))
    except ValueError as e:
        import traceback

        print(traceback.format_exc())
        raise app_config.http_error(name=__name__, code=403, msg=str(e))
    except Exception as e:
        import traceback

        print(traceback.format_exc())
        raise app_config.http_error(name=__name__, code=500, msg=str(e))
