import asyncio
from typing import Optional, Any
from enum import Enum
import traceback
from pydantic import BaseModel
from fastapi import APIRouter, Depends, HTTPException
from flightpath_server.framework_manager import FrameworkManager
from flightpath_server.dependencies import get_api_key, get_app_config
from flightpath_server.config.app_config import AppConfig

csvpath_router = APIRouter()


class Method(str, Enum):
    fast_forward_paths = "fast_forward_paths"
    collect_paths = "collect_paths"
    fast_forward_by_line = "fast_forward_by_line"
    collect_by_line = "collect_by_line"


class RegisterFileRequest(BaseModel):
    project_name: str
    name: str
    file_location: str
    template: Optional[str] = None


class RegisterCsvpathsRequest(BaseModel):
    project_name: str
    name: str
    file_location: str
    append: Optional[bool] = False
    template: Optional[str] = None


class RunRequest(BaseModel):
    project_name: str
    file_name: str
    path_name: str
    method: Optional[str] = Method.collect_paths.value
    template: Optional[str] = None


class RegisterAndRunRequest(BaseModel):
    project_name: str
    file_location: str
    file_name: str
    csvpaths_group_name: str
    method: Optional[str] = Method.collect_paths
    file_template: Optional[str] = None
    run_template: Optional[str] = None


class RunReferenceRequest(BaseModel):
    project_name: str
    run_reference: str


class RunReferencePrintRequest(BaseModel):
    project_name: str
    run_reference: str
    printstream: Optional[str] = None


class RunPathRequest(BaseModel):
    project_name: str
    run_reference: str


class ReferenceResponse(BaseModel):
    reference: str


class ReferencesResponse(BaseModel):
    message: str
    run_reference: str
    register_reference: str


class PathResponse(BaseModel):
    path: str


class ErrorsResponse(BaseModel):
    errors: list[dict]


class MetadataResponse(BaseModel):
    metadata: dict[str, Any]


class VariablesResponse(BaseModel):
    variables: dict[str, Any]


class PrintoutsResponse(BaseModel):
    printouts: list[str]


@csvpath_router.post("/register_file", tags=["register"])
def register_file(
    request: RegisterFileRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> ReferenceResponse:
    """Registers a new version of a named file. In CsvPath Framework terms, this is CsvPaths.FileManager.add_named_file()."""
    try:
        framework_manager = FrameworkManager(
            api_key=api_key, project_name=request.project_name, app_config=app_config
        )
        ret = asyncio.run(
            framework_manager.register_file(
                named_file_name=request.name,
                file_location=request.file_location,
                template=request.template,
            )
        )
        if ret.get("success") is True:
            return {"reference": ret.get("reference")}
        else:
            errors = ret.get("errors")
            if errors is None:
                errors = ["Unknown server error"]
            elif not isinstance(errors, list):
                errors = [str(errors)]
            raise Exception(",".join(ret["errors"]))
    except ValueError as e:
        print(traceback.format_exc())
        raise app_config.http_error(name=__name__, code=403, msg=str(e))
    except Exception as e:
        print(traceback.format_exc())
        raise app_config.http_error(name=__name__, code=500, msg=str(e))


@csvpath_router.post("/register_csvpath_group", tags=["register"])
def register_csvpath_group(
    request: RegisterCsvpathsRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> ReferenceResponse:
    """Registers a named-paths group, creating a new version if the named-paths group already exists. In CsvPath Framework terms, this is CsvPaths.PathsManager.add_named_paths()."""
    try:
        framework_manager = FrameworkManager(
            api_key=api_key, project_name=request.project_name, app_config=app_config
        )
        ret = asyncio.run(
            framework_manager.register_csvpath_group(
                named_paths_name=request.name,
                file_location=request.file_location,
                template=request.template,
                append=request.append,
            )
        )
        if ret.get("success") is True:
            return {"reference": ret.get("reference")}
        else:
            errors = ret.get("errors")
            if errors is None:
                errors = ["Unknown server error"]
            elif not isinstance(errors, list):
                errors = [str(errors)]
            raise Exception(",".join(ret["errors"]))
    except ValueError as e:
        raise app_config.http_error(name=__name__, code=403, msg=str(e))
    except Exception as e:
        raise app_config.http_error(name=__name__, code=500, msg=str(e))


@csvpath_router.post("/run", tags=["run"])
def run(
    request: RunRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> ReferenceResponse:
    """Runs a named-file through a named-paths group. In CsvPath Framework terms, this is one of the following:
    <ul>
        <li> CsvPaths.collect_paths()
        <li> CsvPaths.fast_forward_paths()
        <li> CsvPaths.collect_by_line()
        <li> CsvPaths.fast_forward_by_line()
    </ul>
    """
    try:
        framework_manager = FrameworkManager(
            api_key=api_key, project_name=request.project_name, app_config=app_config
        )
        ret = asyncio.run(
            framework_manager.run(
                named_file_name=request.file_name,
                named_paths_name=request.path_name,
                method=request.method,
                override_template=request.template,
            )
        )
        if ret and ret.get("success") is True:
            return {"reference": ret.get("reference")}
        else:
            errors = ret.get("errors")
            if errors is None:
                errors = ["Unknown server error"]
            elif not isinstance(errors, list):
                errors = [str(errors)]
            raise Exception(",".join(ret["errors"]))
    except ValueError as e:
        raise app_config.http_error(name=__name__, code=403, msg=str(e))
    except Exception as e:
        raise app_config.http_error(name=__name__, code=500, msg=str(e))


@csvpath_router.post("/register_and_run", tags=["register", "run"])
def register_and_run(
    request: RegisterAndRunRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> ReferencesResponse:
    """Registers a new version of a named-file and then runs it through a named-paths group. This endpoint can be used by MFT servers or other file arrival-watching tools to both collect a file and start a run in one action."""
    try:
        framework_manager = FrameworkManager(
            api_key=api_key, project_name=request.project_name, app_config=app_config
        )
        register_result: dict = None
        register_result = asyncio.run(
            framework_manager.register_file(
                named_file_name=request.file_name,
                file_location=request.file_location,
                template=request.file_template,
            )
        )
        if not register_result or not register_result.get("success"):
            raise app_config.http_error(
                name=__name__, code=500, msg=register_result.get("errors")
            )
        #
        # this needs to take the result of the register -- an absolute named-file reference --
        # to use as the file name. sadly, CsvPath doesn't provide that yet. until the next
        # release we can only do :last, which is implied by just using the simple name. :/
        #
        run_result: dict = None
        run_result = asyncio.run(
            framework_manager.run(
                named_file_name=request.file_name,
                named_paths_name=request.csvpaths_group_name,
                method=request.method,
                override_template=request.run_template,
            )
        )
        if not run_result or not run_result.get("success"):
            raise app_config.http_error(
                name=__name__, code=500, msg=run_result.get("errors")
            )
        return {
            "message": "File registered and run initiated successfully",
            "run_reference": run_result.get("reference"),
            "register_reference": register_result.get("reference"),
        }
    except ValueError as e:
        raise app_config.http_error(name=__name__, code=403, msg=str(e))
    except Exception as e:
        print(traceback.format_exc())
        raise app_config.http_error(name=__name__, code=500, msg=str(e))


@csvpath_router.post("/get_run_path", tags=["results"])
def get_run_path(
    request: RunPathRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> PathResponse:
    """Returns the path to a run's `run_dir`. `run_dir` is the name of the directory where a runs results live. It is a date-stamp name below the named-paths name in the form YYYY-MM_DD_HH-MM-SS."""
    result: dict = None
    try:
        framework_manager = FrameworkManager(
            api_key=api_key, project_name=request.project_name, app_config=app_config
        )
        result = asyncio.run(framework_manager.get_run_path(request.run_reference))
    except ValueError as e:
        raise app_config.http_error(name=__name__, code=403, msg=str(e))
    except Exception as e:
        raise app_config.http_error(name=__name__, code=500, msg=str(e))
    if result and result.get("success"):
        return {"path": result.get("path")}
    else:
        raise app_config.http_error(
            name=__name__,
            code=500,
            msg="No results" if not result else result.get("errors"),
        )


@csvpath_router.post("/get_run_errors", tags=["results"])
def get_run_errors(
    request: RunReferenceRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> ErrorsResponse:
    """Returns the contents of all the errors.json files generated during a run. Each csvpath in a named-paths group has its own errors.json file, if errors happened during the run. This endpoint aggregates them."""
    result: dict = None
    try:
        framework_manager = FrameworkManager(
            api_key=api_key, project_name=request.project_name, app_config=app_config
        )
        result = asyncio.run(framework_manager.get_run_errors(request.run_reference))
    except ValueError as e:
        raise app_config.http_error(name=__name__, code=403, msg=str(e))
    except Exception as e:
        raise app_config.http_error(name=__name__, code=500, msg=str(e))
    if result and result.get("success"):
        return {"errors": result.get("errors")}
    else:
        raise app_config.http_error(name=__name__, code=500, msg=result.get("errors"))


@csvpath_router.post("/get_run_metadata", tags=["results"])
def get_run_metadata(
    request: RunReferenceRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> MetadataResponse:
    """Returns the metadata fields and runtime data generated during the run. Metadata fields are settings and user-defined content embedded in comments of a csvpath. Runtime data tracks validity, lines matched, headers, and other metadata that is generated as the run happens. This endpoint aggregates the metadata of all csvpaths within the named-paths group that was run."""
    result: dict = None
    try:
        framework_manager = FrameworkManager(
            api_key=api_key, project_name=request.project_name, app_config=app_config
        )
        result = asyncio.run(framework_manager.get_run_metadata(request.run_reference))
    except ValueError as e:
        raise app_config.http_error(name=__name__, code=403, msg=str(e))
    except Exception as e:
        raise app_config.http_error(name=__name__, code=500, msg=str(e))
    if result and result.get("success"):
        return {"metadata": result.get("metadata")}
    else:
        raise app_config.http_error(name=__name__, code=500, msg=result.get("errors"))


@csvpath_router.post("/get_run_variables", tags=["results"])
def get_run_variables(
    request: RunReferenceRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> VariablesResponse:
    """Returns the run variables. Run variables are user-defined values set within csvpaths, line-by-line. This endpoint aggregates the variables.json files of each of the csvpaths in the named-paths group that was run."""
    result: dict = None
    try:
        framework_manager = FrameworkManager(
            api_key=api_key, project_name=request.project_name, app_config=app_config
        )
        result = asyncio.run(framework_manager.get_run_variables(request.run_reference))
    except ValueError as e:
        raise app_config.http_error(name=__name__, code=403, msg=str(e))
    except Exception as e:
        raise app_config.http_error(name=__name__, code=500, msg=str(e))
    if result and result.get("success"):
        return {"variables": result.get("variables")}
    else:
        raise app_config.http_error(name=__name__, code=500, msg=result.get("errors"))


@csvpath_router.post("/get_run_printouts", tags=["results"])
def get_run_printouts(
    request: RunReferencePrintRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> PrintoutsResponse:
    """Returns the printouts of a printstream, aggregated from all the csvpaths in the named-paths group that was run."""
    result: dict = None
    try:
        framework_manager = FrameworkManager(
            api_key=api_key, project_name=request.project_name, app_config=app_config
        )
        result = asyncio.run(
            framework_manager.get_run_printouts(
                run_reference=request.run_reference, printstream=request.printstream
            )
        )
    except ValueError as e:
        raise app_config.http_error(name=__name__, code=403, msg=str(e))
    except Exception as e:
        print(traceback.format_exc())
        raise app_config.http_error(name=__name__, code=500, msg=str(e))
    if result and result.get("success"):
        return {"printouts": result.get("printouts")}
    else:
        raise app_config.http_error(name=__name__, code=500, msg=result.get("errors"))
