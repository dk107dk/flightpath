import os
import uvicorn
from datetime import datetime
from fastapi import FastAPI
import traceback
from flightpath_server.routers.project_router import project_router
from flightpath_server.routers.csvpath_router import csvpath_router
from flightpath_server.routers.admin_router import admin_router
from flightpath_server.routers.find_router import find_router
from flightpath_server.config.app_config import AppConfig
from flightpath_server.lifespan import lifespan


app = FastAPI(
    title="FlightPath Server",
    description="The <a href='https://www.csvpath.org'>CsvPath Framework</a> automation backend for <a href='https://www.flightpathdata.com'>FlightPath Data</a> projects.",
    contact={
        "Support": "FlightPath Support",
        "url": "https://www.csvpath.org/getting-started/a-helping-hand",
        "email": "info@csvpath.org",
    },
    lifespan=lambda app: lifespan(app, config_path=None),
)

app.include_router(project_router, prefix="/projects", tags=["projects"])
app.include_router(csvpath_router, prefix="/csvpath")
app.include_router(admin_router, prefix="/admin", tags=["admin"])
app.include_router(find_router, prefix="/find", tags=["find"])

LIVE_SINCE = datetime.now()


@app.get("/")
async def root() -> dict:
    kp = app.state.app_config.get(
        section="security", name="key_file_path", default="default"
    )
    kp = "default location" if (kp is None or kp.strip() == "") else kp
    return {
        "message": {
            "name": "FlightPath Server",
            "started": LIVE_SINCE,
            "cwd": os.getcwd(),
            "config": app.state.app_config.configpath,
            "keyfile": kp,
        }
    }


class Main:
    def serve(self):
        try:
            app_config = AppConfig.me()
            port = app_config.get(section="server", name="port", default=8000)
            host = app_config.get(section="server", name="host", default="localhost")
            workers = app_config.get(section="server", name="workers", default=1)
            workers = int(workers) if workers else 1
            args = {}
            args["host"] = host
            args["port"] = int(port)
            args["workers"] = workers

            ssl_keyfile = app_config.get(section="security", name="ssl_keyfile")
            if ssl_keyfile and str(ssl_keyfile).strip() != "":
                args["ssl_keyfile"] = ssl_keyfile

            ssl_certfile = app_config.get(section="security", name="ssl_certfile")
            if ssl_certfile and str(ssl_certfile).strip() != "":
                args["ssl_certfile"] = ssl_certfile

            ssl_keyfile_password = app_config.get(
                section="security", name="ssl_keyfile_password"
            )
            if ssl_keyfile_password and str(ssl_keyfile_password).strip() != "":
                args["ssl_keyfile_password"] = ssl_keyfile_password

            ssl_version = app_config.get(section="security", name="ssl_version")
            if ssl_version and not str(ssl_version).strip() == "":
                args["ssl_version"] = int(ssl_version)

            print(f"FlightPath Server: args: {args}")
            uvicorn.run(app, **args)
        except Exception:
            print(traceback.format_exc())


def run():
    main = Main()
    main.serve()


if __name__ == "__main__":
    run()
