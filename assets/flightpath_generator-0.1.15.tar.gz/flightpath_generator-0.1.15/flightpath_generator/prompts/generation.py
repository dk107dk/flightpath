import datetime
import traceback
import os
import json
from typing import Any

import jsonpickle

from litellm import completion_cost
from litellm import token_counter

from flightpath_generator.util.counter_utility import CounterUtility
from flightpath_generator.prompts.prompt import Prompt
from flightpath_generator.util.exceptions import PromptException
from flightpath_generator.util.file_utility import FileUtility


class Generation:


    def __init__(self, *,
        generator,
        context,
        prompt,
        response,
        generation_name=None,
        store_results=True,
        started_at:datetime=None,
        turn_number:int=-1,
        errors:str=None,
        messages=None
    ):
        if started_at is None:
            started_at = datetime.datetime.now()
        if prompt.name is None:
            raise PromptException("Name cannot be None")
        self.started_at = started_at
        self.runtime_delta = None
        self.generations_root = os.path.join(generator.root, "generations")
        self._tools_used = []
        self._name = None
        self._response_text = None
        self._assessment = None
        self._response = None
        self._tokens = None
        self._messages = messages
        self._cost = None
        self._manifest = None
        self.name = generation_name if generation_name is not None else str(CounterUtility.increment())
        self.generator = generator
        self.my_root = None
        self.context = context
        self.prompt = prompt
        self.store_results = store_results
        self.set_root_if()
        self.set_response(response)
        self.turn_number = turn_number
        self._errors = None
        self.errors = errors
        self.saved = False
        self.tool_calls = self.get_tool_call_names()


    #====================
    # properties
    #====================

    @property
    def errors(self) -> str:
        return self._errors

    @errors.setter
    def errors(self, es:str) -> None:
        if es is not None and str(es).strip() =="":
            es = None
        self._errors = es

    @property
    def tokens(self) -> int:
        if self._tokens is None:
            self._tokens = token_counter(model=self.generator.model, messages=self.messages)
        return self._tokens

    @property
    def cost(self) -> float:
        if self._cost is None:
            try:
                self._cost = completion_cost(completion_response=self.response)
            except Exception:
                print(traceback.format_exc())
                print("continuing")
        return self._cost

    @property
    def messages(self):
        return self._messages

    @property
    def manifest(self) -> dict[str,str]:
        if self._manifest is None:
            self.create_manifest()
        return self._manifest

    @manifest.setter
    def manifest(self, m:dict[str,str]):
        self._manifest = m

    @property
    def tools_used(self) -> list[str]:
        return self._tools_used

    @tools_used.setter
    def tools_used(self, tools:list[str]) -> None:
        self._tools_used = tools

    @property
    def response(self) -> dict:
        return self._response

    @response.setter
    def response(self, r: dict) -> None:
        self._response = r

    @property
    def response_text(self) -> str:
        return self._response_text

    @response_text.setter
    def response_text(self, r: str) -> None:
        self._response_text = r

    @property
    def context(self) -> dict:
        return self._context

    @context.setter
    def context(self, c: dict) -> None:
        self._context = c

    @property
    def prompt(self) -> dict:
        return self._prompt

    @prompt.setter
    def prompt(self, p: dict) -> None:
        self._prompt = p

    @property
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, name:str) -> None:
        self._name = name

    @property
    def assessment(self) -> dict[str, str | int]:
        return self._assessment

    @assessment.setter
    def assessment(self, a: dict[str, str | int]) -> None:
        self._assessment = a
        if self.store_results:
            self.save_assessment()


    #====================
    # other methods
    #====================


    def get_tool_calls(self):
        response = self.response
        if not response or not response.choices or len(response.choices) == 0:
            return None
        message = response.choices[0].message
        tool_calls = message.tool_calls
        return tool_calls

    def get_tool_call_names(self) -> list[str]:
        calls = self.get_tool_calls()
        names = []
        if calls is None:
            return names
        for tool_call in calls:
            tool_name = tool_call.function.name
            names.append(tool_name)
        return names

    def tool_calls_count(self) -> int:
        return 0 if self.tool_calls is None else len(self.tool_calls )

    def add_tool_used(self, tool_name:str) -> None:
        self.tools_used.append(tool_name)

    def add_error(self, error:str) -> None:
        if error is None:
            return
        error = str(error).strip()
        if error == "":
            return
        if self.errors is None or str(self.errors).strip() == "":
            self.errors = error
        else:
            self.errors += "\n\n================================\n\n"
            self.errors += error
        if self.saved is True:
            self.write_if(name="errors.txt", content=self.errors)

    def set_response(self, response) -> None:
        print("")
        if response is None:
            print(f"Generation.__init__: cannot set response because response is None")
            return
        self.response = response
        try:
            if  isinstance(response, str):
                self.response_text = response
            elif response is None:
                self.response_text = "Error: response is None"
                for i, _ in enumerate(response.choices):
                    print(f"   no contentx: _[{i}]: {_}")
            else:
                _ = str(response)
                _ = _[0:120 if len(_)>120 else 10]
                _ = response.choices[0].finish_reason
                if _.find("tool") > -1:
                    self.response_text = str(response.choices[0].message)
                else:
                    self.response_text = response.choices[0].message.content


        except Exception as ex:
            print(traceback.format_exc())
            print(f"Generation.__init__: couldn't get response text: {ex}")

    def save_assessment(self, a: dict[str, str | int] = None) -> None:
        if a is None:
            a = self.assessment
        if a is None:
            raise PromptException("Assessment cannot be None")
        FileUtility.save_file(
            file="assessment.json", path=self.my_root, content=json.dumps(a)
        )

    def set_root_if(self) -> None:
        if self.store_results is not True:
            return
        root = os.path.join(self.generations_root, self.name)
        self.my_root = root
        self.assure_root_if()

    def assure_root_if(self) -> None:
        if self.store_results is not True:
            return
        if os.path.exists(self.my_root):
            return
        os.makedirs(self.my_root)

    def save_if(self) -> None:
        if self.store_results is True:
            self.save()

    def save(self) -> None:
        self.create_manifest()
        self.write_if(name="manifest.txt", content=self.text_manifest())
        self.write_if(name="manifest.json", content=self.json_manifest())
        if self.errors:
            self.write_if(name="errors.txt", content=self.errors)
        if self.response:
            json_friendly_response = str(self.response)
            self.write_if(name="response.txt", content=self.response_text)
            self.write_if(name="response-raw.txt", content=json_friendly_response)
        c = self.context.json_friendly_messages()
        if c is None:
            print(f"No jsonfriendly messages in context: {c}")
        self.write_if(
            name="outbound-msg.json",
            content=c,
            tojson=True,
        )
        # we don't need these here because we have them in the prompts tree -- and
        # the prompts and context files should not change -- but having them here is
        # maybe a bit more secure and easier?
        self.write_if(name=Prompt.EXAMPLE_NAME, content=self.prompt.example)
        self.write_if(name=Prompt.RULES_NAME, content=self.prompt.rules)
        print(f"Generation: save: saved generation {self.name}: {self.my_root}")
        self.saved = True

    def write_if(self, *, name: str, content: str | Any, tojson=False) -> None:
        if self.store_results is not True:
            print("Generation: write_if: not storing results")
            return
        if content is None:
            print(f"Generation: write_if: for {name} the content is None")
            return
        try:
            if tojson:
                content = json.dumps(content, indent=4)
            FileUtility.save_file(path=self.my_root, file=name, content=content)
        except Exception:
            print(traceback.format_exc())


    def run_time_delta(self) -> tuple[datetime.datetime, datetime.timedelta]:
        if self.runtime_delta is None:
            now = datetime.datetime.now()
            td = now - self.started_at
            self.runtime_delta = (now, td)
        return self.runtime_delta

    def create_manifest(self) -> None:
        now, td = self.run_time_delta()
        mani = {}
        mani["path"] = self.my_root
        mani["model"] = self.generator.model
        mani["context"] = self.context.name
        mani["prompt"] = self.prompt.name
        mani["generation"] = self.name
        mani["tool_calls"] = self.get_tool_call_names()
        mani["estimated_tokens"] = self.tokens
        mani["estimated_cost"] = self.cost
        mani["started_at"] = self.started_at
        mani["finished_at"] = now
        mani["run_seconds"] = td.total_seconds()
        self.manifest = mani

    def json_manifest(self) -> str:
        s = jsonpickle.encode(self.manifest, unpicklable=False, indent=2)
        return s

    def text_manifest(self) -> str:
        mani = self.manifest
        txt = f"""
Manifest
-----------
Generation path    {mani["path"]}
Model:             {mani["model"]}
Context:           {mani["context"]}
Prompt:            {mani["prompt"]}
Generation:        {mani["generation"]}
Tool calls:        {mani["tool_calls"]}
Estimated tokens:  {mani["estimated_tokens"]}
Estimated cost:    {mani["estimated_cost"]}
Started at:        {mani["started_at"]}
Finished at:       {mani["finished_at"]}
Run seconds:       {mani["run_seconds"]}
"""
        return txt

