import os
import logging
from logging import Logger
from logging.handlers import RotatingFileHandler
from configparser import ConfigParser
from typing import Any, Self
from pythonjsonlogger.json import JsonFormatter
from fastapi import HTTPException
from csvpath.util.file_writers import DataFileWriter
from csvpath.util.nos import Nos

class ConfigException(Exception):
    ...


class AppConfig:
    config_data: dict[str, dict[str, Any]]

    FLIGHTPATH_SERVER_CONFIG = "FLIGHTPATH_SERVER_CONFIG"
    LOG_FILE = "flightpath_server.log"
    CONFIG_FILE = "app_config.ini"

    BOOT_SVR_MSG = False

    @classmethod
    def me(cls, config_path:str=None) -> Self:
        if config_path is None or str(config_path).strip() == "":
            config_path = os.getenv(AppConfig.FLIGHTPATH_SERVER_CONFIG)
            if config_path is None or str(config_path).strip() == "":
                config_path = os.path.join(cls.app_config_dir, cls.CONFIG_FILE)
                #config_path = os.path.expanduser('~/FlightPathServer/config/app_config.ini')
        if AppConfig.BOOT_SVR_MSG is False:
            print(f"FlightPath Server: loading config at: {config_path}")
            AppConfig.BOOT_SVR_MSG = True
        app_config = AppConfig(config_path)
        return app_config


    @classmethod
    @property
    def app_home_dir(cls) -> str:
        return os.path.expanduser('~/FlightPathServer')

    @classmethod
    @property
    def app_config_dir(cls) -> str:
        return os.path.join(cls.app_home_dir, "config")

    @classmethod
    @property
    def app_log_dir(cls) -> str:
        return os.path.join(cls.app_home_dir, "logs")



    def __init__(self, path) -> None:
        self._config = None
        if path is None:
            raise ConfigException("Path cannot be None")
        self.configpath = path
        #
        # bag is for anything we need to share temporarily
        #
        self._bag = {}
        self._logger = None
        self._log_level = None
        self.logger
        self.load()
        #
        # we have to have a log level before we have a config
        # in order to get a config so we use the default "info"
        # but then we should reset to the actual level configured
        #
        self._logger = None
        self.logger

    @property
    def logger(self) -> Logger:
        if self._logger is None:
            logger = logging.getLogger(__name__)
            level = self.log_level
            self._set_log_level(logger, level)
            path = os.path.join(AppConfig.app_log_dir, AppConfig.LOG_FILE)
            if not os.path.exists(AppConfig.app_log_dir):
                os.makedirs(AppConfig.app_log_dir)
            handler = RotatingFileHandler(
                path,
                maxBytes=1024 * 1024,  # 1MB
                backupCount=100
            )
            handler.setFormatter(JsonFormatter("%(asctime)s - %(levelname)s - %(threadName)s - %(module)s - %(message)s"))
            logger.addHandler(handler)
            self._logger = logger
        return self._logger

    @property
    def log_level(self) -> str:
        if self._log_level is None:
            try:
                self._log_level = self.get(section="logging", name="level", default="info")
            except Exception:
                self._log_level = "info"
        return self._log_level

    @log_level.setter
    def log_level(self, level:str) -> None:
        if level != self._log_level:
            self._log_level = level
            self._set_log_level(self._logger, level)

    def _set_log_level(self, logger:Logger, level:str) -> None:
        if level not in ["debug", "info", "warning", "error"]:
            raise ValueError("Logging level must be one of debug, info, warning, error")
        if level == "debug":
            logger.setLevel(logging.DEBUG)
        elif level == "info":
            logger.setLevel(logging.INFO)
        elif level == "warning":
            logger.setLevel(logging.WARNING)
        elif level == "error":
            logger.setLevel(logging.ERROR)

    def http_error(self, name:str, code:int, msg:str) -> HTTPException:
        self._logger.error(f"HTTP error: {msg}", extra={"code":code, "source":name})
        return HTTPException(status_code=code, detail=msg)

    @property
    def bag(self) -> dict:
        return self._bag

    @bag.setter
    def bag(self, b:dict[str, Any]) -> None:
        self._bag = b

    def load(self) -> None:
        #
        # check and explode if
        #
        if not os.path.exists(self.configpath):
            try:
                self._logger.warning(f"There is no config file at {self.configpath}. Creating a default.")
            except:
                ...
            dirpath = os.path.dirname(self.configpath)
            nos = Nos(dirpath)
            if not nos.exists():
                nos.makedirs()
            with DataFileWriter( path=self.configpath ) as n:
                n.write(self._get_default_config_string())
        self._config = ConfigParser()
        self._logger.info(f"FlightPath Server: loading config at {self.configpath}")
        self._config.read(self.configpath)


    def _get_default_config_string(self) -> str:
        #
        # in principle we could check here if we have an assets/app_config.ini
        # but for now just returning a string is much easier and we're far
        # from when it will become too problematic.
        #
        return f"""
#
# use ALL-CAPS to point to an env var. e.g.:
#
# key_file_path=FLIGHTPATH_API_KEY_FILE
#
[security]
localhost_files_allowed=True
#
# key_file_path points to a json file of FlightPath Server's user API keys
#
key_file_path=
#
# see Uvicorn docs
#
ssl_keyfile=
ssl_certfile=
ssl_keyfile-password=
ssl_version=

[server]
host=localhost
port=8000
workers=1
#
# largest file that can be uploaded by API. this limitation does not
# affect the CsvPath backends, only posting files to the API.
#
max_file_size_kb=1024

[logging]
level=debug
        """

    #
    # todo: note that this does not save the updated config.
    #
    def set(self, *, section: str, name: str, value:Any) -> None:
        self._config[section][name] = value

    def get(self, *, section: str, name: str, default:Any=None) -> Any:
        if self._config is None:
            raise ConfigException("No config available")
        try:
            s = self._config[section][name]
            ret = None
            if s and isinstance(s, str) and s.find(",") > -1:
                ret = [s.strip() for s in s.split(",")]
            elif isinstance(s, str):
                ret = s.strip()
            else:
                ret = s
            if ret and isinstance(ret, str) and ret.isupper():
                v2 = os.getenv(ret)
                if v2 is None:
                    raise ValueError(f"All cap ini values are converted to env var values, which must exist. {ret} is unknown." )
                else:
                    ret = v2.strip()
            return ret
        except KeyError:
            if self._logger and default is None:
                self._logger.warning(f"Unknown config: [{section}] {name}")
            elif self._logger:
                self._logger.info(f"Unknown config: [{section}] {name}. Returning default: {default}")
            else:
                print(f"WARNING: unkown config: [{section}] {name}")
            return default




