import os
import io
import shutil
import tempfile
import json
from configparser import ConfigParser
from csvpath.util.nos import Nos
from csvpath.util.file_writers import DataFileWriter
from flightpath_server.keys.key_manager import KeyManager
from flightpath_server.keys.key import Key
from flightpath_server.config.app_config import AppConfig

class ProjectManager:


    @classmethod
    def config_from_str(self, config_str:str) -> ConfigParser:
        config = ConfigParser()
        config.read_string(config_str)
        return config

    @classmethod
    def config_to_str(self, config:ConfigParser) -> str:
        string_buffer = io.StringIO()
        config.write(string_buffer)
        config_str = string_buffer.getvalue()
        return config_str

    def __init__(self, *, app_config: AppConfig, key_manager: KeyManager=None) -> None:
        if app_config is None:
            raise ValueError("App config cannot be None")
        self.app_config: AppConfig = app_config
        if key_manager is None:
            key_manager = KeyManager(app_config=app_config)
        self.key_manager = key_manager

    def create_new_project(self, *, api_key: str, name: str, config_str: str) -> str:
        if api_key is None:
            raise ValueError("API key cannot be None")
        key = self.key_manager.get_key_data(api_key)
        if not key:
            raise ValueError("Invalid API Key")
        config_file_paths = key.config_file_paths
        if name in config_file_paths:
            raise ValueError(f"Config '{name}' already exists for key")

        projects_dir = os.path.expanduser('~/FlightPathServer/projects')

        hash_key = self.key_manager.hash_key(api_key)
        new_config_path = os.path.join(projects_dir, hash_key, name, "config", "config.ini")
        #
        # we have exist_ok but it shouldn't be needed. if we delete a project we clean up the filesystem.
        # if a project is in the key an error is thrown. projects are namespaced by key hash(uuid) so
        # there won't be conflicts.
        #
        os.makedirs(os.path.dirname(new_config_path), exist_ok=True)
        #
        # config has several settings that must be managed in a server context
        #
        config_str = self._modify_config(
            config_str=config_str,
            config_path=new_config_path,
            project_name=name,
            projects_dir=projects_dir,
            hash_key=hash_key
        )

        with open(new_config_path, "w") as f:
            f.write(config_str)
        config_file_paths[name] = new_config_path
        self.key_manager.update_key_data(api_key, key)
        return new_config_path

    def _modify_config(self, *, config_str:str, config_path:str, project_name:str, projects_dir:str, hash_key:str) -> str:
        #
        # we modify these config keys both defensively and to give access to the correct project
        # context.
        #
        config_str = self._update_config_path(config_str=config_str, target_config_path=config_path)
        config_str = self._update_inputs_paths(config_str=config_str, projects_dir=projects_dir, hash_key=hash_key, project_name=project_name)
        config_str = self._update_results_paths(config_str=config_str, projects_dir=projects_dir, hash_key=hash_key, project_name=project_name)
        config_str = self._set_no_local_no_http(config_str=config_str)
        config_str = self._set_no_cache_no_imports_no_scripts(config_str=config_str)
        #
        # we allow var subbing and set the source to a local config/env.json file. the contents of the file
        # will need to be settable by API
        #
        config_str = self._set_var_source(config_str=config_str, projects_dir=projects_dir, hash_key=hash_key, project_name=project_name)
        return config_str

    def _relative_path(self, path:str) -> bool:
        if path is None:
            raise ValueError("Path cannot be None")
        path = path.strip().lower()
        if path == "":
            return True
        if path[0] == "/":
            return False
        if path[0:1] == "\\":
            return False
        if path.startswith("s3://") or path.startswith("azure://") or path.startswith("gcs://") or path.startswith("sftp://"):
            return False
        if path[1:2] == ":\\":
            return False
        return True

    def _set_var_source(self, *, config_str:str, projects_dir:str, hash_key:str, project_name:str) -> str:
        config = ConfigParser()
        config.read_string(config_str)
        try:
            config["config"]["allow_var_sub"] = "yes"
        except Exception:
            ...
        try:
            path = os.path.join(projects_dir, hash_key, project_name, "config", "env.json")
            config["config"]["var_sub_source"] = path
            nos = Nos(path)
            if not nos.exists():
                with DataFileWriter(path) as file:
                    json.dump({}, file.sink, indent=4)
        except Exception:
            ...
        string_buffer = io.StringIO()
        config.write(string_buffer)
        config_str = string_buffer.getvalue()
        return config_str

    def _set_no_cache_no_imports_no_scripts(self, config_str:str) -> str:
        config = ConfigParser()
        config.read_string(config_str)
        #
        # there shouldn't be a time when these sections don't exist.
        #
        try:
            config["cache"]["use_cache"] = "no"
        except Exception:
            ...
        try:
            config["scripts"]["run_scripts"] = "no"
        except Exception:
            ...
        try:
            config["functions"]["imports"] = ""
        except Exception:
            ...
        string_buffer = io.StringIO()
        config.write(string_buffer)
        config_str = string_buffer.getvalue()
        return config_str

    def _set_no_local_no_http(self, config_str:str) -> str:
        config = ConfigParser()
        config.read_string(config_str)
        config["inputs"]["allow_http_files"] = "no"
        config["inputs"]["allow_local_files"] = "no"
        string_buffer = io.StringIO()
        config.write(string_buffer)
        config_str = string_buffer.getvalue()
        return config_str

    def _update_inputs_paths(self, *, config_str:str, projects_dir:str, hash_key:str, project_name:str) -> str:
        config = ConfigParser()
        config.read_string(config_str)
        files = config["inputs"]["files"]
        paths = config["inputs"]["csvpaths"]
        if self._relative_path(files):
            files = os.path.join(projects_dir, hash_key, project_name, files)
        if self._relative_path(paths):
            paths = os.path.join(projects_dir, hash_key, project_name, paths)
        config["inputs"]["files"] = files
        config["inputs"]["csvpaths"] = paths
        string_buffer = io.StringIO()
        config.write(string_buffer)
        config_str = string_buffer.getvalue()
        return config_str

    def _update_results_paths(self, *, config_str:str, projects_dir:str, hash_key:str, project_name:str) -> str:
        config = ConfigParser()
        config.read_string(config_str)
        archive = config["results"]["archive"]
        transfers = config["results"]["transfers"]
        if self._relative_path(archive):
            archive = os.path.join(projects_dir, hash_key, project_name, archive)
        if self._relative_path(transfers):
            transfers = os.path.join(projects_dir, hash_key, project_name, transfers)
        config["results"]["archive"] = archive
        config["results"]["transfers"] = transfers
        string_buffer = io.StringIO()
        config.write(string_buffer)
        config_str = string_buffer.getvalue()
        return config_str

    def _update_config_path(self, *, config_str:str, target_config_path:str) -> str:
        config = ConfigParser()
        config.read_string(config_str)
        #
        # set the configpath value to target_config_path
        #
        config["config"]["path"] = target_config_path
        #
        # write the configpath to string
        #
        string_buffer = io.StringIO()
        config.write(string_buffer)
        config_str = string_buffer.getvalue()
        return config_str

    def delete_project(self, *, api_key: str, name: str) -> None:
        if api_key is None:
            raise ValueError("API key cannot be None")
        if name is None:
            raise ValueError("Project name cannot be None")

        key = self.key_manager.get_key_data(api_key)
        if not key:
            raise ValueError("Invalid API key")
        config_file_paths = key.config_file_paths
        if name not in config_file_paths:
            raise ValueError(f"Config '{name}' not found.")

        config_file_path = config_file_paths[name]
        project_path_to_delete = os.path.dirname(os.path.dirname(config_file_path))
        #
        # todo: save a last backup zip of the project
        #
        if os.path.isdir(project_path_to_delete):
            shutil.rmtree(project_path_to_delete)
        del config_file_paths[name]
        self.key_manager.update_key_data(api_key, key)

    def get_project_names(self, api_key: str) -> list[str]:
        if api_key is None:
            raise ValueError("API key cannot be None")
        key = self.key_manager.get_key_data(api_key)
        if not key:
            raise ValueError("Invalid API Key")
        return list(key.config_file_paths.keys())

    def set_project_config(self, api_key: str, name: str, config_str: str) -> None:
        if api_key is None:
            raise ValueError("API key cannot be None")
        if name is None:
            raise ValueError("Project name cannot be None")
        if config_str is None:
            raise ValueError("Project config cannot be None")

        key = self.key_manager.get_key_data(api_key)
        if not key:
            raise ValueError("Invalid API Key")
        hash_key = self.key_manager.hash_key(api_key)
        config_file_paths = key.config_file_paths
        if name not in config_file_paths:
            raise ValueError(f"Config '{name}' not found.")

        projects_dir = os.path.expanduser('~/FlightPathServer/projects')
        config_path = config_file_paths[name]
        config_str = self._modify_config(
            config_str=config_str,
            config_path=config_path,
            project_name=name,
            projects_dir=projects_dir,
            hash_key=hash_key
        )

        with open(config_path, "w") as f:
            f.write(config_str)
        self.key_manager.update_key_data(api_key, key)

    def get_project_config(self, api_key: str, name: str) -> str:
        if api_key is None:
            raise ValueError("API key cannot be None")
        if name is None:
            raise ValueError("Project name cannot be None")
        key = self.key_manager.get_key_data(api_key)
        if not key:
            raise ValueError("Invalid API Key")
        config_file_paths = key.config_file_paths
        if name not in config_file_paths:
            raise ValueError(f"Config '{name}' not found.")
        with open(config_file_paths[name], "r") as f:
            return f.read()

    def _get_env_path(self, api_key: str, name: str) -> str:
        key = self.key_manager.get_key_data(api_key)
        if not key:
            raise ValueError("Invalid API Key")
        config_file_paths = key.config_file_paths
        if name not in config_file_paths:
            raise ValueError(f"Config '{name}' not found.")

        project_dir = os.path.dirname(os.path.dirname(config_file_paths[name]))
        return os.path.join(project_dir, "config", "env.json")

    def set_env_file(self, api_key: str, name: str, env_str: str) -> None:
        if env_str is None:
            raise ValueError("Env file content cannot be None")
        env_path = self._get_env_path(api_key, name)
        with open(env_path, "w") as f:
            f.write(env_str)

    def get_env_file(self, api_key: str, name: str) -> str:
        env_path = self._get_env_path(api_key, name)
        if not os.path.exists(env_path):
            with open(env_path, "w") as file:
                json.dump({}, file)
        with open(env_path, "r") as f:
            return f.read()

    def set_env_key(self, api_key: str, name: str, key: str, value: str) -> None:
        if key is None:
            raise ValueError("Key cannot be None")
        env_path = self._get_env_path(api_key, name)
        if not os.path.exists(env_path):
            with open(env_path, "w") as file:
                json.dump({}, file)
        with open(env_path, "r") as f:
            data = json.load(f)
        data[key] = value
        with open(env_path, "w") as f:
            json.dump(data, f, indent=4)

    def _get_project_path(self, api_key: str, name: str) -> str:
        key = self.key_manager.get_key_data(api_key)
        if not key:
            raise ValueError("Invalid API Key")
        config_file_paths = key.config_file_paths
        if name not in config_file_paths:
            raise ValueError(f"Config '{name}' not found.")

        return os.path.dirname(os.path.dirname(config_file_paths[name]))

    def add_file(self, api_key: str, name: str, file_path: str, file_content: bytes) -> None:
        if file_path is None:
            raise ValueError("File path cannot be None")
        if file_content is None:
            raise ValueError("File content cannot be None")

        if file_path in ["config/config.ini", "config/env.json"]:
            raise ValueError(f"Cannot modify protected file: {file_path}")

        max_size_kb = int(self.app_config.get(section="server", name="max_file_size_kb", default=1024))
        if len(file_content) > max_size_kb * 1024:
            raise ValueError(f"File size exceeds the limit of {max_size_kb}KB")

        project_path = self._get_project_path(api_key, name)
        full_path = os.path.join(project_path, file_path)

        os.makedirs(os.path.dirname(full_path), exist_ok=True)

        with open(full_path, "wb") as f:
            f.write(file_content)

    def get_file(self, api_key: str, name: str, file_path: str) -> bytes:
        if file_path is None:
            raise ValueError("File path cannot be None")

        if file_path in ["config/config.ini", "config/env.json"]:
            raise ValueError(f"Cannot access protected file: {file_path}")

        project_path = self._get_project_path(api_key, name)
        full_path = os.path.join(project_path, file_path)

        if not os.path.exists(full_path):
            raise ValueError(f"File not found: {file_path}")

        with open(full_path, "rb") as f:
            return f.read()


