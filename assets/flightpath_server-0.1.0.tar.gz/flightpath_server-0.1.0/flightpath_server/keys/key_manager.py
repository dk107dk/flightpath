import os
import shutil
import hashlib
from .key_store import KeyStore
from .key import Key
from flightpath_server.config.app_config import AppConfig
from .key_store import FileKeyStore

class KeyManager:
    def __init__(self, *, app_config: AppConfig, key_store: KeyStore=None) -> None:
        self.app_config: AppConfig = app_config
        if key_store is None:
            key_store = FileKeyStore(app_config)
        self.key_store: KeyStore = key_store

    def has_keys(self) -> bool:
        return self.key_store.has_keys()

    def hash_key(self, api_key: str) -> str:
        h = hashlib.sha256(api_key.encode()).hexdigest()
        return h

    def validate_key(self, api_key: str) -> bool:
        return self.get_key_data(api_key) is not None

    def get_key_data(self, api_key: str) -> Key | None:
        return self.key_store.get_key_data(api_key)

    def update_key_data(self, api_key:str, key:Key) -> None:
        if api_key is None:
            raise ValueError("API key cannot be None")
        if key is None:
            raise ValueError("Key cannot be None")
        self.key_store.update_key_data(api_key, key)

    def create_key(self, *, key: Key, api_key:str=None) -> str:
        if self.has_keys():
            if api_key is None:
                raise ValueError("API key cannot be None when keys exist")
            if not self.validate_key(api_key):
                raise ValueError("Invalid API key. You must have a valid API key to create a new API key.")
            key.admin = False
        else:
            key.admin = True
        return self.key_store.add_key(key)

    def is_admin(self, admin_key:str) -> bool:
        return self.key_store.is_admin(admin_key)

    def delete_key(self, *, admin_key: str, delete_key:str) -> bool:
        admin = self.key_store.is_admin(admin_key)
        if admin is not True:
            raise ValueError("Invalid admin API key. You must have a valid admin API key to delete an API key.")
        return self.key_store.delete_key(delete_key)

    def set_admin_status(self, *, api_key: str, is_admin: bool = True) -> None:
        key_data = self.get_key_data(api_key)
        if key_data is None:
            raise ValueError("API key not found.")
        key_data.admin = is_admin
        self.update_key_data(api_key, key_data)


