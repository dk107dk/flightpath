import io
from configparser import ConfigParser

class ConfigUpdater:
    @classmethod
    def update(self, *, path:str=None, config_str:str=None, section:str, name:str, value:str) -> str:
        if path is None and config_str is None:
            raise ValueError("You must provide a path or content of a config file")
        #
        # make certain the project allows local files. by default projects do not.
        #
        c = ConfigParser()
        #
        # if we have a path and a config str we assume we're modifying
        # the string and writing to the path; otherwise, if a path and no
        # string, we load from path; and if a string and no path we just
        # return the updated config content
        #
        if path and not config_str:
            c.read(path)
        else:
            c.read_string(config_str)
        c[section][name] = value
        string_buffer = io.StringIO()
        c.write(string_buffer)
        config_str = string_buffer.getvalue()
        if path:
            with open(path, 'w') as f:
                c.write(f)
        return config_str
