import traceback
from csvpath import CsvPaths
from csvpath.util.log_utility import LogUtility as lout


class InfoDumper:
    @classmethod
    def dump_info(
        cls,
        *,
        app_config,
        hash_key: str,
        project_name: str = None,
        csvpaths: CsvPaths = None,
    ) -> str:
        app_config.logger.debug(
            cls.dump_info_string(
                app_config=app_config,
                project_name=project_name,
                csvpaths=csvpaths,
                hash_key=hash_key,
            )
        )

    @classmethod
    def dump_info_string(
        cls,
        *,
        app_config,
        hash_key: str,
        project_name: str = None,
        csvpaths: CsvPaths = None,
    ) -> str:
        if app_config is None:
            raise ValueError("App config cannot be None")
        if hash_key is None:
            raise ValueError("Api key cannot be None")
        if not app_config.verbose():
            return
        if not project_name or str(project_name).strip() == "":
            project_name = "Project unset"
        string = "Info at error state: "
        string = f"{string}\n Key hash: {hash_key}"
        if csvpaths:
            string = f"{string}\n {csvpaths}"
        string = f"{string}\n {app_config}"
        string = f"{string}\n Project: {project_name}"
        try:
            string = f"{string}\n Trace:\n{traceback.format_exc()}"
        except Exception:
            ...
        return string
