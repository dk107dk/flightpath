import re
import os
import csv
from flightpath_generator.prompts.prompt import Prompt
from flightpath_generator.util.file_utility import FileUtility
from flightpath_generator.prompts import Generation


class Assessor:
    def __init__(self) -> None:
        """
        self._context = "5"
        self._prompt = "4"
        self._generator = None
        """
        self._gen = None
        self._funcs = None

    @property
    def generation(self) -> Generation:
        return self._gen

    @generation.setter
    def generation(self, generation: Generation) -> None:
        self._gen = generation

    def do_assessment(self) -> dict[str, str | int]:
        a = self.assess()
        self._gen.set_assessment(a)
        return a

    @property
    def funcs(self) -> list:
        if self._funcs is None:
            fs = FileUtility.load(path="notes/functions.txt", recurse=False)
            self._funcs = fs.split("\n")
        return self._funcs

    def assess(self) -> dict[str, str | int]:
        assessment = {}
        assessment["func_count"] = self.count_functions(self.generation.csvpath)
        assessment["func_percent"] = self.percent_functions(self.generation.csvpath)
        assessment["distinct_headers"] = self.count_distinct_headers(
            self.generation.csvpath
        )
        assessment["percent_distinct_headers"] = self.percent_distinct_headers(
            self.generation.csvpath
        )
        assessment["csvpath_count"] = self.count_csvpaths(self.generation.csvpath)
        assessment["headers_to_csvpaths"] = self.headers_to_csvpaths(
            self.generation.csvpath
        )
        assessment["comments_per_csvpath"] = self.comments_per_csvpath(
            self.generation.csvpath
        )
        assessment["comment_count"] = self.count_comments(self.generation.csvpath)
        assessment["lines_per_comment"] = self.lines_per_comment(
            self.generation.csvpath
        )
        assessment["illegal_operators"] = self.count_illegal_operators(
            self.generation.csvpath
        )
        self.assesment = assessment
        return assessment

    def count_illegal_operators(self, txt) -> int:
        return (
            txt.count(" != ")
            + txt.count(" >= ")
            + txt.count(" <= ")
            + txt.count(" > ")
            + txt.count(" < ")
        )

    def count_comments(self, txt) -> int:
        try:
            return txt.count("~") / 2
        except ZeroDivisionError:
            return -1

    def count_csvpaths(self, txt) -> int:
        return txt.count("$[")

    def comments_per_csvpath(self, txt) -> int:
        try:
            co = self.count_comments(txt)
            cs = self.count_csvpaths(txt)
            return round(co / cs, 1)
        except ZeroDivisionError:
            return -1

    def lines_per_comment(self, txt) -> int:
        try:
            c = self.count_comments(txt)
            ls = txt.count("\n")
            ls += txt.count(r"\n")
            return round(ls / c, 1)
        except ZeroDivisionError:
            return -1

    def count_distinct_headers(self, txt) -> int:
        dh = {}
        for m in re.finditer(r"""#"?[a-zA-Z0-9]*""", txt):
            v = m.group(0)
            dh[v] = v
        return len(dh)

    def percent_distinct_headers(self, txt) -> int:
        try:
            dh = self.count_distinct_headers(txt)
            return round(dh / self.number_of_headers() * 100, 1)
        except ZeroDivisionError:
            return -1

    def headers_to_csvpaths(self, txt) -> int:
        try:
            h = self.number_of_headers()
            c = self.count_csvpaths(txt)
            return round(h / c, 1)
        except ZeroDivisionError:
            return -1

    def number_of_headers(self) -> int:
        print(f"Assesssss: self.generation.my_root: {self.generation.my_root}")
        path = os.path.join(self.generation.my_root, Prompt.EXAMPLE_NAME)
        with open(path, "r") as f:
            reader = csv.reader(f)
            for line in reader:
                i = len(line)
                return i

    def count_functions(self, txt) -> int:
        i = 0
        for f in self.funcs:
            i += txt.count(f" {f}(") > 0
        return i

    def percent_functions(self, txt) -> int:
        try:
            i = 0
            for f in self.funcs:
                i += txt.count(f" {f}(") > 0
            return round(i / len(self.funcs) * 100, 1)
        except ZeroDivisionError:
            return -1


