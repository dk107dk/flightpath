from abc import ABC, abstractmethod


class GeneratorTool(ABC):

    @abstractmethod
    def tool_definition(self) -> dict:
        ...

class LiteLLMCsvPathTool(GeneratorTool):

    def tool_definition(self) -> dict:
        return {
                "type": "function",
                "function": {
                    "name": "check_csvpath_is_valid",
                    "description": "Compiles a csvpath statement to make sure it is correct",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "csvpath": {
                                "type": "string",
                                "description": "The csvpath to check",
                            }
                        },
                        "required": ["csvpath"]
                    }
                }
            }



