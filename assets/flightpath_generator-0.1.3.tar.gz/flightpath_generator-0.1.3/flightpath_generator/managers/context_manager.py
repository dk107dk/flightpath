# from __future__ import annotations
import os
import json
from json import JSONDecodeError
from csvpath.util.nos import Nos
from flightpath_generator.prompts import Context
from flightpath_generator.prompts import Message
from flightpath_generator.prompts import Block
from flightpath_generator.util.exceptions import PromptException


class ContextManager:
    def __init__(self, generator):
        if generator is None:
            raise ValueError("Generator cannot be None")
        self._generator = generator
        self._my_root = None
        self.assure_context_root()

    def assure_context_root(self) -> None:
        path = self.context_root
        if not os.path.exists(path):
            os.makedirs(path)

    @property
    def generator(self) -> None:
        return self._generator

    @property
    def context_root(self) -> str:
        if self._my_root is None and self._generator is not None:
            self._my_root = os.path.join(self._generator.root, "contexts")
        return self._my_root

    @context_root.setter
    def context_root(self, root: str) -> None:
        self._my_root = root

    def create_context(self) -> Context:
        return Context(self._generator)

    def manifest(self, directory) -> list:
        path = os.path.join(directory, "manifest.json")
        with open(path) as file:
            return json.load(file)

    def get_context(self, name: str=None) -> Context:
        if name is None:
            v = self.generator.version_key
            name = self.generator.config.get("version", f"{v}.context")

        directory = os.path.join(self.context_root, name)
        ctx = Context(name=name)
        lst = self.manifest(directory)
        for b in lst:
            path = os.path.join(directory, b["file"])
            nos = Nos(path)
            if not nos.exists():
                continue
            c = ""
            m = Message()
            m.role = b["role"]
            m.name = b.get("name")
            ttype = b.get("type")
            ctx.add_message(m)
            if nos.isfile():
                with open(path, "r") as f:
                    c = f.read()
            else:
                m2 = os.path.join(path, "manifest.json")
                if not Nos(m2).exists():
                    continue
                __ = None
                with open(m2, "r") as file:
                    __ = json.load(file)
                for _ in __:
                    with open(os.path.join(path, _), "r") as f:
                        t = f.read()
                        t = str(t).strip()
                        c = f"{c}\n\n{t}"
            block = Block()
            block.block_type = "text" if ttype is None else ttype
            block.text = c
            m.add_content(block)
        return ctx


