class GeneratorException(Exception):
    pass


class PromptException(Exception):
    pass


class ConfigurationException(Exception):
    pass




