import datetime
import traceback
import os
import json
from typing import Any
from flightpath_generator.prompts.prompt import Prompt
from flightpath_generator.util.exceptions import PromptException
from flightpath_generator.util.file_utility import FileUtility


class Generation:

    NO_ERRORS = "No errors"

    def __init__(self, *,
        generator,
        context,
        prompt,
        response,
        generation_name=None,
        store_results=True,
        started_at:datetime=None,
        turn_number:int=-1,
        errors:str=None
    ):
        if started_at is None:
            started_at = datetime.datetime.now()
        if prompt.name is None:
            raise PromptException("Name cannot be None")
        self.started_at = started_at
        self.runtime_delta = None
        self.generations_root = os.path.join(generator.root, "generations")
        self._name = None
        self.name = generation_name if generation_name is not None else prompt.name
        self.generator = generator
        self.my_root = None
        self._assessment = None
        self.context = context
        self.prompt = prompt
        self.store_results = store_results
        self.set_root_if()
        self._response = None
        self.set_response(response)
        self.turn_number = turn_number
        self.errors = errors
        self.saved = False

    def add_error(self, error:str) -> None:
        if error is None:
            return
        error = str(error).strip()
        if error == "":
            return
        if self.errors is None or self.errors == Generation.NO_ERRORS or str(self.errors).strip() == "":
            self.errors = error
        else:
            self.errors += "\n\n================================\n\n"
            self.errors += error
        if self.saved is True:
            self.write_if(name="errors.txt", content=self.errors)

    def set_response(self, response) -> None:
        if response is None:
            print(f"Generation.__init__: cannot set response because response is None")
            return
        try:
            self.response = response if not isinstance(response, str) else None
            if response.choices[0].finish_reason.find("tool") > -1:
                self.response_text = str(response.choices[0].message)
            else:
                self.response_text = response.choices[0].message.content

            if self.response_text is None:
                print("Generation: set_response: self.response_text is None. listing choices.")
                for i, _ in enumerate(response.choices):
                    print(f"   no contentx: _[{i}]: {_}")
            else:
                print(f"Generation: set response_text: {self.response_text}")
        except Exception as ex:
            print(traceback.format_exc())
            print(f"Generation.__init__: couldn't get response text: {ex}")

    @property
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, name:str) -> None:
        self._name = name

    @property
    def assessment(self) -> dict[str, str | int]:
        return self._assessment

    @assessment.setter
    def assessment(self, a: dict[str, str | int]) -> None:
        self._assessment = a
        if self.store_results:
            self.save_assessment()

    def save_assessment(self, a: dict[str, str | int] = None) -> None:
        if a is None:
            a = self.assessment
        if a is None:
            raise PromptException("Assessment cannot be None")
        FileUtility.save_file(
            file="assessment.json", path=self.my_root, content=json.dumps(a)
        )

    def set_root_if(self) -> None:
        if self.store_results is not True:
            return
        root = os.path.join(self.generations_root, self.name)
        self.my_root = root
        self.assure_root_if()

    def assure_root_if(self) -> None:
        if self.store_results is not True:
            return
        if os.path.exists(self.my_root):
            return
        os.makedirs(self.my_root)

    def save_if(self) -> None:
        if self.store_results is True:
            self.save()

    def save(self) -> None:
        self.create_manifest()
        self.write_if(name="manifest.txt", content=self.manifest)
        if self.errors is None:
            self.errors = Generation.NO_ERRORS
        self.write_if(name="errors.txt", content=self.errors)
        if self.response:
            json_friendly_response = str(self.response)
            self.write_if(name="response.txt", content=self.response_text)
            self.write_if(name="response-raw.txt", content=json_friendly_response)
        c = self.context.json_friendly_messages()
        if c is None:
            print(f"No jsonfriendly messages in context: {c}")
        self.write_if(
            name="outbound-msg.json",
            content=c,
            tojson=True,
        )
        # we don't need these here because we have them in the prompts tree -- and
        # the prompts and context files should not change -- but having them here is
        # maybe a bit more secure and easier?
        self.write_if(name=Prompt.EXAMPLE_NAME, content=self.prompt.example)
        self.write_if(name=Prompt.RULES_NAME, content=self.prompt.rules)
        print(f"Generation: save: saved generation {self.name}")
        self.saved = True


    def write_if(self, *, name: str, content: str | Any, tojson=False) -> None:
        if self.store_results is not True:
            print("Generation: write_if: not storing results")
            return
        if content is None:
            print(f"Generation: write_if: for {name} the content is None")
            return
        try:
            if tojson:
                content = json.dumps(content, indent=4)
            FileUtility.save_file(path=self.my_root, file=name, content=content)
        except Exception:
            print(traceback.format_exc())


    def run_time_delta(self) -> tuple[datetime.datetime, datetime.timedelta]:
        if self.runtime_delta is None:
            now = datetime.datetime.now()
            td = now - self.started_at
            self.runtime_delta = (now, td)
        return self.runtime_delta

    def create_manifest(self) -> None:
        now, td = self.run_time_delta()
        #
        # there are some things we could capture. total time may not be
        # inclusive of all tools calls, LiteLLM gives us some token use
        # info that might be worth keeping, etc.
        #
        mani = f"""
Manifest
-----------
Model:         {self.generator.model}
Context:       {self.context.name}
Prompt:        {self.prompt.name}
Generation:    {self.name}
Started at:    {self.started_at}
Finished at:   {now}
Run seconds:   {td.total_seconds()}
"""
        self.manifest = mani

    @property
    def response(self) -> dict:
        return self._response

    @response.setter
    def response(self, r: dict) -> None:
        self._response = r

    @property
    def context(self) -> dict:
        return self._context

    @context.setter
    def context(self, c: dict) -> None:
        self._context = c

    @property
    def prompt(self) -> dict:
        return self._prompt

    @prompt.setter
    def prompt(self, p: dict) -> None:
        self._prompt = p
