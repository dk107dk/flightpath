from pydantic import BaseModel

class Key(BaseModel):
    key_name:str
    key_owner_name:str
    key_owner_contact:str
    config_file_paths:dict[str,str]
    admin: bool = False



