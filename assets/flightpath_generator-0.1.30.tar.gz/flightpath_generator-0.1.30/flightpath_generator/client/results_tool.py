from abc import ABC, abstractmethod
import tempfile
import os
import traceback

from csvpath import CsvPaths
from csvpath.util.file_readers import DataFileReader
from csvpath.util.nos import Nos

from flightpath_generator.client.tools import GeneratorTool, AssistantError
from flightpath_generator import Generator

from pydantic import BaseModel


class Results(BaseModel):
    # the metadata will be a json string. this could be a problem.
    run_metadata: Optional[str] = None
    runs_log_metadata: Optional[str] = None
    results: list[Result] = []

class Result(BaseModel):
    result_metadata: Optional[str] = None
    paths: list[File] = []

class File(BaseModel):
    name:Optional[str] = None
    path:Optional[str] = None
    size:Optional[int] = -1

class LiteLLMResultsTool(GeneratorTool):

    NAME = "get_run_results_info"

    def __init__(self) -> None:
        GeneratorTool.TOOLS[LiteLLMResultsTool.NAME] = self

    def tool_definition(self) -> dict:
        props = {
            "reference": {
                "type": "string",
                "description": "The reference to a run",
            }
        }
        return self._tool_def(
            name=LiteLLMResultsTool.NAME,
            desc="Uses a reference to pull information about a named-paths group run's results",
            properties=props,
            required=["reference"]
        )

    def name(self) -> str:
        return LiteLLMResultsTool.NAME

    def use(self, generation:Generation, tool_call, args:dict) -> dict:
        if not "csv" in args:
            raise AssistantError("No CSV data provided")
        if not "csvpath" in args:
            raise AssistantError("No csvpath statement provided")
        msg, error = self._use(
            id=tool_call.id,
            reference=args["reference"],
            generator=generation.generator
        )
        if error is not None:
            generation.add_error(error)
        return msg

    def _use(self, *, id:str, reference:str, generator:Generator=None) -> tuple[dict, str|None]:
        function_response = None
        try:
            paths = csut.new_csvpaths(generator)
            results = paths.results_manager.get_named_results(reference)
            jrs = Results()
            if results is None or len(results) == 0:
                ...
            else:
                mdata = Nos(results[0].run_dir).join("manifest.json")
                with DataFileReader(mdata) as file:
                    jrs.run_metadata = file.source.read()

                for result in results:
                    jr = Result()
                    jrs.append(jr)
                    mdata = Nos(result.instance_home).join("manifest.json")
                    with DataFileReader(mdata) as file:
                        jr.run_metadata = file.source.read()

            function_response = jrs.model_dump()

        except Exception as ex:
            function_response = f"Error: {ex}"
            error = traceback.format_exc()
            print(error)
        print(f"================\n{LiteLLMResultsTool.NAME} done\n================\n")
        ret = {
            "tool_call_id": id,
            "role": "tool",
            "name": LiteLLMResultsTool.NAME,
            "content": function_response,
        }
        return (ret, error)


