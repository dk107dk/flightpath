import os
import logging
from logging import Logger
from logging.handlers import RotatingFileHandler
from pythonjsonlogger.json import JsonFormatter


class LoggerProvider:

    LOG_FILE = "flightpath_server.log"
    LOGGER = logging.getLogger(__name__)

    @classmethod
    def app_home_dir(cls) -> str:
        return os.path.expanduser("~/FlightPathServer")

    @classmethod
    def app_log_dir(cls) -> str:
        return os.path.join(cls.app_home_dir(), "logs")

    def __init__(cls) -> None:
        if len(cls.LOGGER.handlers) == 0:
            path = os.path.join(cls.app_log_dir(), cls.LOG_FILE)
            if not os.path.exists(cls.app_log_dir()):
                os.makedirs(cls.app_log_dir())
            handler = RotatingFileHandler(
                path, maxBytes=1024 * 1024, backupCount=100  # 1MB
            )
            handler.setFormatter(
                JsonFormatter(
                    "%(asctime)s - %(levelname)s - %(threadName)s - %(module)s - %(message)s"
                )
            )
            handler.setLevel(logging.DEBUG)
            cls.LOGGER.addHandler(handler)
            cls.LOGGER.setLevel(logging.DEBUG)
