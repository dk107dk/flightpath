from csvpath import CsvPaths
from flightpath_generator import Generator


class CsvpathsUtility:

    @classmethod
    def new_csvpaths(cls, generator: Generator) -> CsvPaths:
        paths = CsvPaths()
        paths.config = generator.csvpath_config
        paths.logger = generator.csvpath_logger
        return paths
