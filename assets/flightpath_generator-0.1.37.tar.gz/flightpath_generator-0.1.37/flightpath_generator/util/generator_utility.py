import os
from typing import Callable

from csvpath import CsvPaths
from csvpath.util.config import Config as CsvPathConfig

from flightpath_generator import Generator
from flightpath_generator.util.config import Config as GeneratorConfig


class GeneratorUtility:

    @classmethod
    def new_generator_config(cls, csvpath_config: CsvPathConfig) -> GeneratorConfig:
        path = os.path.dirname(csvpath_config.configpath)
        path = os.path.join(path, "generator.ini")
        config = GeneratorConfig(cfg=csvpath_config, configpath=path)
        return config

    @classmethod
    def default_generator(
        cls, *, callbacks: list[Callable] = None, tools: list = None
    ) -> Generator:
        return cls.new_generator(csvpaths=CsvPaths(), callbacks=callbacks, tools=tools)

    @classmethod
    def new_generator(
        cls, *, csvpaths: CsvPaths, callbacks: list[Callable] = None, tools: list = None
    ) -> Generator:
        config = cls.new_generator_config(csvpaths.config)
        generator = Generator(config)
        for c in callbacks if callbacks else []:
            generator.add_callback(c)
        generator.csvpath_config = csvpaths.config
        generator.csvpath_logger = csvpaths.logger
        generator.tools = tools
        return generator
