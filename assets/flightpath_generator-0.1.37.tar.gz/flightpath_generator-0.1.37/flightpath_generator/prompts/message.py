import json
from typing import List
from flightpath_generator.prompts.block import Block


class Message:
    def __init__(self):
        self._role: str = "user"
        self._content: List[Block] = []

    def __str__(self) -> str:
        return f"""Message(role={self._role},content={self.content_to_json()})"""

    @property
    def role(self) -> str:
        return self._role

    @role.setter
    def role(self, role: str) -> str:
        self._role = role

    @property
    def content(self) -> List[Block]:
        return self._content

    @content.setter
    def content(self, blocks: List[Block]) -> None:
        self._content = blocks

    def content_to_json(self) -> str:
        j = "["
        for i, b in enumerate(self.content):
            j += b.to_json()
            if i < len(self.content) - 1:
                j += ","
        j += "]"
        return j

    def __dict__(self):
        d = {
            "role": self._role,
            "content": [block.__dict__() for block in self._content],
        }
        if hasattr(self, "tool_calls"):
            d["tool_calls"] = self.tool_calls
        return d

    def to_json(self):
        msg = '{"role":"'
        msg += self.role
        msg += '", "content":'
        msg += self.content_to_json()
        if hasattr(self, "tool_calls") and self.tool_calls:
            msg += json.dumps(self.tool_calls, indent=2)
        msg += "}"
        return msg

    def add_text_content(self, txt: str) -> None:
        b = Block()
        b.block_type = "text"
        b.text = txt
        self.add_content(b)

    def add_content(self, c: Block) -> None:
        self.content.append(c)
