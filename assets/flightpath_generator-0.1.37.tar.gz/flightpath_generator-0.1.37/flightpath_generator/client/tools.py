from abc import ABC, abstractmethod
from typing import Self
from flightpath_generator.prompts import Generation


#
# raise when assistant failed to behave as expected; e.g. not passing
# a required param.
#
class AssistantError(Exception):
    pass


#
# (re)raise when the tool is checking for errors and found one
#
class ExpectedError(Exception):
    pass


class GeneratorTool(ABC):

    TOOLS = {}

    @abstractmethod
    def tool_definition(self) -> dict:
        pass

    @abstractmethod
    def name(self) -> str:
        pass

    @abstractmethod
    def use(self, generation: Generation, tool_call, args: dict) -> dict:
        pass

    @classmethod
    def tool_for_name(cls, name: str) -> Self:
        if name in GeneratorTool.TOOLS:
            return GeneratorTool.TOOLS[name]
        return None

    def _tool_def(
        self, *, name: str, desc: str, properties: dict[str, dict], required: list[str]
    ) -> dict:
        return {
            "type": "function",
            "function": {
                "name": name,
                "description": desc,
                "parameters": {
                    "type": "object",
                    "properties": properties,
                    "required": required,
                },
            },
        }
