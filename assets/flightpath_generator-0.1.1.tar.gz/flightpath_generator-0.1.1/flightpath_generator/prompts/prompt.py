import os
from flightpath_generator.util.exceptions import PromptException
from flightpath_generator.util.counter_utility import CounterUtility
from flightpath_generator.util.file_utility import FileUtility
from flightpath_generator.prompts.block import Block


class Prompt:
    EXAMPLE_CHAR_MAX = 8192
    RULES_CHAR_MAX = 1024
    EXAMPLE_NAME = "example.txt"
    RULES_NAME = "rules.txt"

    def __init__(self, *, generator, name=None):
        self._generator = generator
        if name is None:
            self._name = f"{CounterUtility.increment()}"
        else:
            self._name = name
        self._csv_example: str = None
        self._example_path: str = None
        self._rules: str = None
        self._rules_path: str = None

    def __str__(self) -> str:
        return f"""{self.__class__}: name: {self._name}: {self._example_path}, {self._rules_path}"""

    def to_json(self) -> str:
        e = self.get_example_block()
        r = self.get_rules_block()
        j = ""
        j += e.to_json()
        if r is not None:
            j += ","
            j += r.to_json()
        return j

    def save(self, path: str = None) -> None:
        if self.rules is None or self.example is None:
            raise PromptException(
                "Rules and example must exist. The empty string is acceptable."
            )
        FileUtility.save(path=self.rules_path, content=self.rules)
        FileUtility.save(path=self.example_path, content=self.example)

    def get_example_block(self) -> Block:
        if self.example is None:
            raise ValueError("Example CSV cannot be None")
        e = "The example data file is everything below this line. Base your CsvPath statements on it. Before you respond, think carefully about how CsvPath Language works and be sure you write statements that conform to CsvPath's structure and functions.\n\n"
        e = f"{e}{self.example}"
        block = Block()
        block.block_type = "text"
        block.text = e.replace('"', r"\"")
        return block

    def get_rules_block(self) -> Block:
        if self.rules is not None and self.rules.strip() != "":
            block = Block()
            block.block_type = "text"
            txt = "The CsvPath statement(s) you write must implement these rules: "
            txt += self.rules.replace('"', r"\"")
            block.text = txt
            return block
        return None

    @property
    def name(self) -> str:
        return self._name

    @property
    def rules(self) -> str:
        if self._rules is None:
            txt = self.load_rules()
            self._rules = txt
        return self._rules

    @property
    def rules_path(self) -> str:
        if self._rules_path is None:
            self._rules_path = os.path.join(
                self._generator.prompt_manager.prompt_root, self.name
            )
            self._rules_path = os.path.join(self._rules_path, Prompt.RULES_NAME)
        return self._rules_path

    @rules_path.setter
    def rules_path(self, path: str) -> None:
        self._rules_path = path

    def load_rules(self) -> str:
        return FileUtility.load(
            path=self.rules_path,
            recurse=None,
            max_length=Prompt.RULES_CHAR_MAX,
            escape_quotes=True,
            default="",
        )

    @rules.setter
    def rules(self, text: str) -> None:
        self._rules = text

    @property
    def example_path(self) -> str:
        if self._example_path is None:
            path = self._generator.prompt_manager.prompt_root
            self._example_path = os.path.join(path, self.name)
            self._example_path = os.path.join(self._example_path, Prompt.EXAMPLE_NAME)
        return self._example_path

    @example_path.setter
    def example_path(self, path: str) -> None:
        self._example_path = path

    def _load_example(self, recurse=True) -> str:
        csv = FileUtility.load(
            path=self.example_path, max_length=Prompt.EXAMPLE_CHAR_MAX, max_lines=30
        )
        return csv

    @property
    def example(self) -> str:
        if self._csv_example is None:
            self._csv_example = self._load_example()
        return self._csv_example

    @example.setter
    def example(self, lines: str) -> None:
        self._csv_example = lines
