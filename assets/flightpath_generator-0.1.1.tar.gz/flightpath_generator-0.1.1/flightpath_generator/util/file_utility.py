import os
import shutil
from typing import Any


class FileUtility:
    NO_DEFAULT = -101010

    @classmethod
    def load_file(
        cls,
        *,
        path: str,
        file: str,
        recurse=True,
        max_length: int = -1,
        max_lines: int = -1,
        escape_quotes: bool = False,
        default: Any = NO_DEFAULT,
    ) -> str:
        """
        recurse means write default or "" and try again one time
        default=NO_DEFAULT means no default. a file not found exception will be raised"""
        return cls.load(
            path=os.path.join(path, file),
            recurse=False,
            max_length=max_length,
            max_lines=max_lines,
            escape_quotes=escape_quotes,
            default=default,
        )

    @classmethod
    def load(
        cls,
        *,
        path: str,
        recurse=True,  # now we have default, do we need this?
        max_length: int = -1,
        max_lines: int = -1,
        escape_quotes: bool = False,
        default: Any = NO_DEFAULT,
    ) -> str:
        """
        recurse means write default or "" and try again one time
        default=NO_DEFAULT means no default. a file not found exception will be raised"""
        # print(f"""FileUtility:load(path:{path},recurse:{recurse},max_lines:{max_lines},max_lenth:{max_length},escape_quotes:{escape_quotes},default:{default})""")
        if path is None:
            raise Exception("Path cannot be None")
        if os.path.exists(path):
            # print(f"FileUtil.load: path: {path} exists")
            with open(path) as file:
                content = file.read()
                content = cls.assure_length(
                    content=content, max_length=max_length, max_lines=max_lines
                )
                if escape_quotes:
                    content = f"{content}".replace('"', r"\"")
                return content
        else:
            # print(f"FileUtil.load: path: {path} not exists")
            if recurse is True:
                # print(f"FileUtil.load: saving and retrying")
                cls.save(
                    path=path, content=default if default is not cls.NO_DEFAULT else ""
                )
                return cls.load(
                    path=path,
                    recurse=False,
                    max_length=max_length,
                    max_lines=max_lines,
                    escape_quotes=escape_quotes,
                    default=default,
                )
            elif default == cls.NO_DEFAULT:
                raise FileNotFoundError(f"Cannot load {path}")
        # print(f"FileUtil.load: returning default: {default}")
        return default

    @classmethod
    def save_file(
        cls,
        *,
        path: str,
        file: str,
        content: str,
        max_length: int = -1,
        max_lines: int = -1,
    ) -> None:
        if path is None:
            raise ValueError(f"Path cannot be None")
        if file is None:
            raise ValueError(f"File cannot be None")
        cls.save(
            path=os.path.join(path, file),
            content=content,
            max_length=max_length,
            max_lines=max_lines,
        )

    @classmethod
    def save(
        cls, *, path: str, content: str, max_length: int = -1, max_lines: int = -1
    ) -> None:
        if path is None:
            raise Exception("Path cannot be None")
        if content is None:
            raise Exception(
                "Content to save cannot be None. Empty string is acceptable."
            )
        cls.assure_dir(path)
        with open(path, "w") as file:
            content = cls.assure_length(
                content=content, max_length=max_length, max_lines=max_lines
            )
            file.write(content)

    @classmethod
    def assure_dir(cls, path) -> None:
        if path.rfind(os.sep) == -1:
            return
        d = path[0 : path.rfind(os.sep)]
        if not os.path.exists(d):
            os.makedirs(d, exist_ok=True)

    @classmethod
    def remove(cls, path, path_exists=True) -> None:
        if path_exists is True and path is None:
            raise Exception("Path cannot be None")
        if path_exists is True and not os.path.exists(path):
            raise Exception("Path must exist")
        elif path_exists is False and not os.path.exists(path):
            return
        if os.path.isfile(path):
            os.remove(path)
        else:
            shutil.rmtree(path)

    @classmethod
    def remove_if(cls, path: str) -> None:
        cls.remove(path, path_exists=False)

    @classmethod
    def remove_file(cls, *, directory: str, file: str, file_exists=True) -> None:
        path = os.path.join(directory, file)
        cls.remove_file(path, file_exists)

    @classmethod
    def assure_length(cls, *, content: str, max_length=-1, max_lines=-1) -> str:
        if content is None:
            return ""
        if 0 < max_length and max_length < len(content):
            content = content[0:max_length]
        if max_lines > 0:
            feeds = 0
            for i, c in enumerate(content):
                if c == "\n" or c == "\r":
                    feeds = feeds + 1
                if feeds >= max_lines:
                    content = content[0:i]
                    break
        return content
