import os
import datetime
import json
import traceback
from typing import Callable

import litellm

from ratelimit import limits
from csvpath import CsvPath
from csvpath.util.config import Config as CsvPathConfig
from csvpath.util.nos import Nos

from flightpath_generator.managers.context_manager import ContextManager
from flightpath_generator.managers.generation_manager import GenerationManager
from flightpath_generator.managers.prompt_manager import PromptManager
from flightpath_generator.prompts import Prompt, Context, Generation
from flightpath_generator.util.config import Config
from flightpath_generator.util.storage_utility import StorageUtility as stut

from flightpath_generator.client.tools import GeneratorTool, AssistantError, ExpectedError

from flightpath_generator.client.llm_client import LiteLLMClient


class Generator:
    """
    Use like:
        #
        # set up the two config objects. csvpath config sets the AI.
        # generator config sets the context and prompt template versions
        #
        csvpath = CsvPath()
        cc = csvpath.config
        path = os.path.dirname(cc.configpath)
        config = Config(os.path.join(path, "generator.ini"))
        #
        # set up generator. version key identities context, template pairs
        # so that we can configure multiple uses of generators.
        #
        generator = Generator(config)
        generator.csvpath_config = cc
        generator.version_key="question"
        #
        # create a context. mainly used for system prompt inputs. can also
        # create user/assistant back-and-forth.
        #
        context = generator.context_manager.get_context()
        #
        # create a prompt obj from the user's input and save it for future
        # reference. context and templates are preexisting. prompts are
        # created saved and then used. inside generator prompt and context
        # are merged to make the API call that results in a generation.
        #
        prompt = generator.prompt_manager.create_prompt()
        prompt.rules = "How do I check if a date is from last week?"
        prompt.example = "..."
        prompt.save()
        #
        # run the prompt and receive a generation obj with results. the
        # generation is a collection of inputs and outputs of one API call.
        #
        generation = generator.do_send(context=context, prompt=prompt)
    """
    def __init__(self, config=None, ignore_context_and_template_versions=False) -> None:
        self._config = config if config is not None else Config()
        self._root = self._config.get("storage", "root")
        if self._root is None:
            raise ValueError(f"Storage root cannot be None in {self._config.configpath}")
        self.context_manager = ContextManager(generator=self)
        self.prompt_manager = PromptManager(generator=self)
        self._csvpath_config = None
        self._csvpath_logger = None
        self._prod = None
        self._context = None
        self._context_name = None
        self._version_key = "default"
        self._model = None
        self._api_base = None
        self._tools = None
        self._generations = None
        self._callbacks = None
        self._verbose = False
        #
        # these two stut methods setup the storage dirs for prompts, generations, etc.
        # they will overwrite to get the templates and contexts to the level expected
        # by the installed version of the library, based on
        # flightpath_generator/storage/version.txt. users can customize prompts easily
        # but they should create new prompt template and context names and use those in
        # generator.ini in order to not be overwritten by the library's numbered
        # versions
        #
        #
        # ignore_context_and_template_versions=True means Generator won't check and overwrite its
        # context and prompt template files from zip.
        #
        if ignore_context_and_template_versions is False:
            print("gen: assuring path")
            stut.assure_paths(self)
            print("gen: setting up context and templates")
            stut.assure_context_and_templates(self)
            print("gen: done with setting up")



#=============
# properties
#=============

    @property
    def verbose(self) -> bool:
        return self._verbose

    @verbose.setter
    def verbose(self, v:bool) -> None:
        self._verbose = v

    @property
    def root(self) -> str:
        return self._root

    @root.setter
    def root(self, root: str) -> None:
        self._root = root

    @property
    def config(self) -> Config:
        return self._config

    @property
    def model(self) -> str:
        return self._model

    @model.setter
    def model(self, m:str) -> None:
        self._model = m

    @property
    def api_base(self) -> str:
        return self._api_base

    @api_base.setter
    def api_base(self, a:str) -> None:
        self._api_base = a

    @property
    def prod(self) -> bool:
        if self._prod is None:
            prod = self.config.get("env", "prod")
            self._prod = f"{prod}".strip().lower() == "true"
        return self._prod

    @prod.setter
    def prod(self, prod: bool) -> None:
        self._prod = prod

    @property
    def context_name(self) -> str:
        if self._context_name is None:
            self._context_name = self.config.get("version", "context")
        return self._context_name

    @context_name.setter
    def context_name(self, c: str) -> None:
        self._context_name = c

    @property
    def context(self) -> str:
        if self._context is None:
            self._context = self.context_manager.get_context(self.context_name)
        return self._context

    @context.setter
    def context(self, context: Context) -> None:
        self._context = context

    @property
    def tools(self) -> dict:
        return self._tools

    @tools.setter
    def tools(self, t:dict) -> None:
        self._tools = t

    @property
    def version_key(self) -> str:
        return self._version_key

    @version_key.setter
    def version_key(self, key:str) -> None:
        self._version_key = key

    @property
    def manifest(self) -> list:
        path = os.path.join(self._root, "manifest.json")
        if not os.path.exists(path):
            with open(path, "w") as file:
                json.dump([],file)
        with open (path, "r") as file:
            return json.load(file)

    @manifest.setter
    def manifest(self, mani:list ) -> None:
        path = os.path.join(self._root, "manifest.json")
        with open(path, "w") as file:
            json.dump(mani, file, indent=2)

    @property
    def csvpath_logger(self) -> CsvPathConfig:
        if self._csvpath_logger is None:
            self._csvpath_logger = CsvPath().logger
        return self._csvpath_logger

    @csvpath_logger.setter
    def csvpath_logger(self, log ) -> None:
        self._csvpath_logger = log

    @property
    def csvpath_config(self) -> CsvPathConfig:
        if self._csvpath_config is None:
            self._csvpath_config = CsvPath().config
        return self._csvpath_config

    @csvpath_config.setter
    def csvpath_config(self, c:CsvPathConfig ) -> None:
        self._csvpath_config = c

    @property
    def turns_limit(self) -> int:
        n = self.config.get("generations", "turns_limit", -1)
        if n is None or str(n).strip() == "":
            n = -1
        return int(n)

    @property
    def generations(self) -> list:
        if self._generations is None:
            self._generations = []
        return self._generations

    @property
    def callbacks(self) -> list[Callable]:
        if self._callbacks is None:
            self._callbacks = []
        return self._callbacks

#================
# util methods
#================

    def get_turns(self, text_list:bool=True) -> list[str|dict]:
        #
        # if text_list is true we serialize the manifests and return
        # a list of string. otherwise, a list of dict.
        #
        gs = self.generations
        lst = []
        for g in gs:
            _ = g.json_manifest() if text_list is True else g.manifest
            lst.append(g.json_manifest())
        return lst

    def dump(self) -> None:
        print(self)

    def __str__(self) -> str:
        return f"""Generator (root:{self.root}, prod:{self.prod}, context_name:{self.context_name}, config:{self.config.configpath})"""

    def assure_root(self) -> None:
        if self.root is None:
            raise ValueError(f"Storage root cannot be None")
        if not os.path.exists(self.root):
           os.makedirs(self.root)

    def create_prompt(self) -> Prompt:
        prompt = self.prompt_manager.create_prompt()
        return prompt

    def create_context(self) -> Context:
        return self.context_manager.create_context()

    def exceeds_turns_limit(self, turn:int) -> int:
        limit = self.turns_limit
        if limit == -1:
            return False
        if limit < turn:
            return True
        return False

    def _track(self, generation:Generation) -> None:
        now, td = generation.run_time_delta()
        mani = self.manifest
        #
        # TODO: add token use here
        #
        stats = {
            "model":self.model,
            "api_base":self.api_base,
            "context": f"{os.path.join(self._root, "contexts", generation.context.name)}",
            "prompt": f"{os.path.join(self._root, "prompts", generation.prompt.name)}",
            "generation": f"{os.path.join(self._root, "generations", generation.name)}",
            "started_at": str(generation.started_at),
            "ended_at": str(now),
            "duration": td.total_seconds(),
            "errors": generation.errors
        }
        mani.append(stats)
        #
        # writes as well as sets property
        #
        self.manifest = mani

    def collect_generation(self, generation:Generation) -> None:
        self.generations.append(generation)
        self._track(generation)

    def add_callback(self, c:Callable) -> None:
        if self.callbacks is None:
            self._callbacks = []
        self.callbacks.append(c)

    def callback_if(self) -> None:
        g = self.generations[len(self.generations)-1]
        for c in self.callbacks:
            c(g)

#===================
# sending methods
#===================

    @limits(calls=10, period=900)
    def do_send(self, *,
        context=None,
        prompt=None,
        datapath:str=None,
        messages=None,
        store_results=True,
        turn_number=0
    ) -> Generation:
        if context is None:
            raise ValueError("Context cannot be none")
        if prompt is None:
            raise ValueError("Prompt cannot be none")
        #
        # if we have messages we are recursing and should call back. this
        # gives the caller the chance to inspect the work so far.
        #
        if messages:
            self.callback_if()
        messages = self._get_messages(context=context, datapath=datapath, prompt=prompt, messages=messages)
        start_time = datetime.datetime.now()
        client = LiteLLMClient(generator=self)
        errors = ""
        response = None
        #
        # we use tools. they are not in the message flow. have
        # to re-add each request cycle so they exist for the model.
        #
        client.tools = self.tools
        error_msg = None
        try:
            #
            # verbose is depreciated in favor of an OS env var setting. for now it still works.
            #
            if self.verbose is True:
                litellm.set_verbose = True
            response = client.completion(messages)
        except litellm.exceptions.ServiceUnavailableError as ex:
            error_msg = str(ex)
            print(f">> Error: Cannot send: {ex}")
            errors=traceback.format_exc()
            print(errors)
        except Exception as ex:
            error_msg = str(ex)
            print(f">> Error: Cannot send: {ex}")
            errors=traceback.format_exc()
            print(errors)
        #
        #
        #
        generation = Generation(
            generator=self,
            context=context,
            prompt=prompt,
            response=response,
            started_at=start_time,
            turn_number=turn_number,
            errors=errors,
            messages=messages
        )
        print(f"Created generation: {generation} for turn #{turn_number}")
        if generation.errors is not None:
            generation.response_text = f"Error in AI request: {generation.errors}: {error_msg}"
            generation.save()
            return generation
        #
        #
        #
        self.collect_generation(generation)
        generation.save()
        print(f"Done with turn #{turn_number}")
        if errors != "" or not response:
            print(f"Error state on turn #{turn_number} of {self.turns_limit}: errors: {errors}, response: {response}")
            return generation
        print(f"Doing tool calls, if any, for {generation.name}, {response} at turn #{turn_number} of {self.turns_limit}")
        ng = self._do_tool_calls_if(
            response=response,
            generation = generation,
            context=context,
            prompt=prompt,
            turn_number=turn_number,
            messages=messages
        )
        #
        # we do this here so we have any errors from the tool call. in particular, going over
        # limit. however.... this will disrupt the order, right? hmmm.
        #
        if ng is None:
            #
            # this is probably the last turn, but it could be an error state
            #
            print(f"Generator: no further calls: Returning generation.")
            self.callback_if()
            return generation
        stut.cleanup_generations_if(self)
        return ng

    def _get_messages(self, *, context:Context, datapath:str=None, prompt:Prompt=None, messages:dict=None):
        #
        # apply prompt adds the user generated prompt to the
        # context object that constructs the whole api prompt
        # from versioned context files containing system
        # instructions, etc.
        #
        if messages:
            #
            # if messages were passed in we need to push them to the LLM, but
            # we also need to backfil into the context so that the generation
            # can serialize the context with the most current messages.
            #
            context.from_json(messages)
        else:
            #
            # give the message templates a chance to use the path of the
            # current data file. this is so a generated csvpath file can
            # include a use-data: or test-data: metadata field.
            #
            if datapath:
                context.background["datapath"] = datapath
            #
            #
            #
            context.apply_prompt(prompt)
            messages = context.json_friendly_messages()
        return messages

    def _do_tool_calls_if(self, *, response, generation, messages, context, prompt, turn_number) -> Generation:
        ok = self._check_tool_calls(
            response=response,
            generation = generation,
            context=context,
            prompt=prompt,
            turn_number=turn_number,
            messages=messages
        )
        if ok:
            return self.do_send(messages=messages, context=context, prompt=prompt, turn_number=turn_number)
        return None

    def _check_tool_calls(self, *, response, generation, messages, context, prompt, turn_number) -> Generation:
        response_message = response.choices[0].message
        tool_calls = response_message.tool_calls
        if tool_calls is None:
            return False
        if len(tool_calls) == 0:
            return False
        #
        # we add the assistant's response to the messages because we're
        # going to reply, unless the turns limit is exceeded.
        #
        self._add_response_to_messages(
            generation=generation,
            messages=messages,
            response_message=response_message,
            tool_calls=tool_calls
        )
        turn_number += 1
        print(f"Continuing with tool response to do turn #{turn_number} of {self.turns_limit}")
        if self.exceeds_turns_limit(turn_number):
            print(f"Turns limit exceeded. {len(tool_calls)} tool calls being dropped at #{turn_number}.")
            generation.add_error("Conversation turns limit reached, including tool use. Cutting things short.")
            return False
        #
        # response_message must go into the messages chain here so
        # that claude or another LLM has the tool call id to refer back to
        #
        return self._tool_calls(generation, messages, response_message)

    def _add_response_to_messages(self, *, generation, messages, response_message, tool_calls) -> None:
        #
        # this response is needed for the message chain. it will be
        # pulled into into the context's messages, also, so that it
        # will be serialized to the generation's results as part of
        # the turns.
        #
        m = {
              "role": "assistant",
              "content": None,
              "tool_calls": []
            }
        for tool_call in tool_calls:
            m["tool_calls"].append({
                  "id": tool_call.id,
                  "type": "function",
                  "function": {
                    "name": tool_call.function.name,
                    "arguments": tool_call.function.arguments
                  }
            })
        messages.append(m)

    def _tool_calls(self, generation, messages:list, response_message:list) -> bool:
        tool_calls = response_message.tool_calls
        #
        # we already checked
        #
        """
        if len(tool_calls) == 0:
            return False
        """
        ret = True
        for tool_call in tool_calls:
            try:
                tool_name = tool_call.function.name
                generation.add_tool_used(tool_name)
                args = json.loads(tool_call.function.arguments)
                t = GeneratorTool.tool_for_name(tool_name)
                if t is None:
                    messages.append({
                        "tool_call_id": tool_call.id,
                        "role": "tool",
                        "name": tool_name,
                        "content": "Error: unknown tool"
                    })
                else:
                    m = t.use(generation, tool_call, args)
                    messages.append(m)
            except AssistantError:
                print(f"Error during tool call due to assistant's incorrect use of tool: {tool_call}: {ex}")
                messages.append({
                        "tool_call_id": tool_call.id,
                        "role": "tool",
                        "name": tool_name,
                        "content": "Error: your tool-use request was incorrectly made."
                    })
                return True
            except ExpectedError:
                print(f"Error during tool call: likely due to bad inputs from assistant: {tool_call}: {ex}")
                messages.append({
                        "tool_call_id": tool_call.id,
                        "role": "tool",
                        "name": tool_name,
                        "content": "Error: the tool did not perform as exected. Check your inputs."
                    })
                return True
            except Exception as ex:
                print(traceback.format_exc())
                print(f"Unexpected error in tool call: {tool_call}: {ex}")
                ret = False
        return ret


