import os
from flightpath_generator.util.exceptions import PromptException
from flightpath_generator.util.counter_utility import CounterUtility
from flightpath_generator.util.file_utility import FileUtility
from flightpath_generator.prompts.block import Block


class Prompt:
    EXAMPLE_CHAR_MAX = 8192
    RULES_CHAR_MAX = 1024
    EXAMPLE_NAME = "example.txt"
    RULES_NAME = "rules.txt"


    #
    # prompts have two parts: examples (data) and rules (input
    # from user).
    #
    # prompt template rule and example files have replacement
    # markers in the form %%%varname%%%. after the template is
    # applied the prompt files are saved for future reference.
    #
    def __init__(self, *, generator, name=None):
        self._generator = generator
        #
        # name is typically a number we generate in sequence
        #
        self._name = None
        #
        # example is the text that gives the LLM a model for
        # what its output should be. it may not have %%% vars.
        # example is automatically added to self.example_values
        # under the key "example".
        #
        self._example: str = None
        self._example_path: str = None
        #
        # values are the name=value pairs that replace %%% vars
        #
        self._example_values = None
        #
        # rules are the narrative instructions the user gives to
        # the LLM. rules text may not have %%% vars. it is added
        # to rules_values automatically under the key "rules".
        #
        self._rules: str = None
        self._rules_path: str = None
        self._rules_values = None
        #
        # set using the property so we get a new name if name is
        # None.
        #
        self.name = name

    def __str__(self) -> str:
        return f"""{self.__class__}: name: {self._name}: {self._example_path}, {self._rules_path}"""


    #================
    # properties
    #================

    @property
    def generator(self) -> None:
        return self._generator

    @property
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, name:str=None) -> None:
        if name is None:
            self._name = f"{CounterUtility.increment()}"
        else:
            self._name = name

    @property
    def rules_path(self) -> str:
        if self._rules_path is None:
            self._rules_path = os.path.join(
                self.generator.prompt_manager.prompt_root, self.name
            )
            self._rules_path = os.path.join(self._rules_path, Prompt.RULES_NAME)
        return self._rules_path

    @rules_path.setter
    def rules_path(self, path: str) -> None:
        self._rules_path = path

    @property
    def rules(self) -> str:
        if self._rules is None:
            self._rules = FileUtility.load(
                path=self.rules_path, recurse=None, max_length=Prompt.RULES_CHAR_MAX, escape_quotes=True, default="",
            )
        return self._rules

    @rules.setter
    def rules(self, text: str) -> None:
        self._rules = text

    @property
    def example_path(self) -> str:
        if self._example_path is None:
            path = self.generator.prompt_manager.prompt_root
            self._example_path = os.path.join(path, self.name)
            self._example_path = os.path.join(self._example_path, Prompt.EXAMPLE_NAME)
        return self._example_path

    @example_path.setter
    def example_path(self, path: str) -> None:
        self._example_path = path

    @property
    def example(self) -> str:
        if self._example is None:
            print(f"WARNING: loading max length: {Prompt.EXAMPLE_CHAR_MAX} and max lines: 30. ")
            self._example = FileUtility.load(
                path=self.example_path, max_length=Prompt.EXAMPLE_CHAR_MAX, max_lines=30
            )
        return self._example

    @example.setter
    def example(self, data: str) -> None:
        self._example = data

    @property
    def example_values(self) -> dict:
        if self._example_values is None:
            self._example_values = {}
        return self._example_values

    @example_values.setter
    def example_values(self, data: dict) -> None:
        self._example_values = data

    @property
    def rules_values(self) -> dict:
        if self._rules_values is None:
            self._rules_values = {}
        return self._rules_values

    @rules_values.setter
    def rules_values(self, data: dict) -> None:
        self._rules_values = data


    #================
    # other methods
    #================


    def to_json(self) -> str:
        e = self.get_example_block()
        r = self.get_rules_block()
        j = ""
        j += e.to_json()
        if r is not None:
            j += ","
            j += r.to_json()
        return j

    def save(self, path: str = None) -> None:
        if self.rules is None or self.example is None:
            raise PromptException(
                "Rules and example must exist. The empty string is acceptable."
            )
        #
        # getting the text from the blocks makes sure we apply the template.
        # we're saving the prompt inputs. the context will format them into a
        # message block. the goal is to capture what will be sent. we're not
        # trying to save the raw rules and examples string we received pre-
        # template.
        #
        rules = self.get_rules_block().text
        example = self.get_example_block().text
        FileUtility.save(path=self.rules_path, content=rules)
        FileUtility.save(path=self.example_path, content=example)

    def template_path(self, name:str) -> str:
        return self.generator.prompt_manager.prompt_template_path(name)

    def template(self, name:str) -> str:
        return self.generator.prompt_manager.prompt_template(name)

    def get_example_block(self, values:dict=None) -> Block:
        template = self.template("example")
        if values is None:
            values = self.example_values
        else:
            values = values | self.example_values
        block = self._build_block(ttype="example", template=template, content=self.rules, values=values)
        return block

    def get_rules_block(self, values:dict=None) -> Block:
        template = self.template("rules")
        if values is None:
            values = self.rules_values
        else:
            values = values | self.rules_values
        if "instructions" not in values:
            raise ValueError("No 'instructions' token in rules block values")
        block = self._build_block(ttype="rules", template=template, content=self.rules, values=values)
        return block

    def _build_block(self, *, ttype:str, template:str, values:dict=None, content:str) -> Block:
        if template is None:
            raise ValueError("Template cannot be none")
        if content is not None:
            content = str(content).strip()
            if content == "":
                content = None
        block = None
        if template.find("%%%") == -1:
            if values:
                print(f"There are unused values because there is no replacement tokens in the template")
                #raise ValueError(f"Cannot apply values to a {ttype} block text with no placeholders: {values}")
            block = Block()
            block.block_type = "text"
            block.text = template
        else:
            block = self._get_block(ttype=ttype, template=template, content=content, values=values)
        if block.block_type is None:
            raise ValueError("Type cannot be None")
        return block

    def _get_block(self, *, ttype:str, template:str, content:str=None, values:dict=None) -> Block:
        if content is None:
            content = ""
        if values is None:
            values = {}
        if content != "":
            values[ttype] = content
        txt = self.apply_template(template=template, values=values)
        block = Block()
        block.block_type = "text"
        block.text = txt
        return block

    def apply_template(self, *, template:str, values:dict) -> None:
        #
        # when we apply a template we do a very simple variable sub using
        # the form %%%varname%%%. this is way simpler than jinja and
        # presumably is (much?) quicker, though I haven't checked that.
        #
        if values is None:
            raise ValueError("Values cannot be None")
        if template is None:
            raise ValueError("Template cannot be None")
        for k, v in values.items():
            template = template.replace(f"%%%{k}%%%", str(v))
        if template.find("%%%") > -1:
            print(f"apply_template: template: {template}")
            raise ValueError(f"Values didn't match all replacement tokens: {values}")
        return template


