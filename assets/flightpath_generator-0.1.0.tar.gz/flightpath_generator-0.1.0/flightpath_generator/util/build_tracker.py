import os
from .file_utility import FileUtility
from .counter_utility import CounterUtility


class BuildTracker:
    NO_BUILD_NUMBER = "No build number found"

    @classmethod
    def assure_build_number(cls) -> None:
        FileUtility.load(path=f"build{os.sep}major.txt", recurse=True, default="0")
        FileUtility.load(path=f"build{os.sep}minor.txt", recurse=True, default="0")
        FileUtility.load(path=f"build{os.sep}build.txt", recurse=True, default="0.0.0")

    @classmethod
    def next_build_number(cls) -> str:
        cls.assure_build_number()
        # print(f"\nassured build number exists. next, collecting it")
        major = FileUtility.load_file(path="build", file="major.txt")
        # print(f"\nmajor: {major}")
        minor = FileUtility.load_file(path="build", file="minor.txt")
        # print(f"\nminor: {minor}")
        build = CounterUtility.next(identifier="build")
        # print(f"\nbuild: {build}")
        return f"{major}.{minor}.{build}"

    @classmethod
    def set_next_build_number(cls) -> str:
        cls.assure_build_number()
        number = cls.next_build_number()
        name = "build.txt"
        FileUtility.save_file(path="build", file=name, content=number)
        #
        # put in two places. the build number directory for everyone esp. the
        # builds. and in the webapp for immediate use. the webapp will get into
        # git, but the release generating script will copy the file from the
        # build number dir into the docker image to make sure we have the latest
        # number
        #
        tsx = "export default function BuildPage(){return(<div>"
        tsx = f"{tsx}{number}"
        tsx = tsx + "</div>)}"
        FileUtility.save_file(path="build", file="page.tsx", content=tsx)
        FileUtility.save_file(path="autogenui/app/build", file="page.tsx", content=tsx)
        return number

    @classmethod
    def get_build_number(cls) -> str:
        cls.assure_build_number()
        build = FileUtility.load_file(
            path="build", file="build.txt", default=cls.NO_BUILD_NUMBER
        )
        # print(f"Tracker.get_build_number: build: {build}")
        return build


if __name__ == "__main__":
    BuildTracker.set_build_number()
