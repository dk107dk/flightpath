import datetime
import traceback
import os
import json
from typing import Any
from flightpath_generator.prompts.prompt import Prompt
from flightpath_generator.util.exceptions import PromptException
from flightpath_generator.util.file_utility import FileUtility


class Generation:
    def __init__(self, *,
        generator,
        context,
        prompt,
        response,
        generation_name=None,
        store_results=True,
        started_at:datetime=None
    ):
        if started_at is None:
            started_at = datetime.datetime.now()
        if prompt.name is None:
            raise PromptException("Name cannot be None")
        self.started_at = started_at
        self.runtime_delta = None
        self.generations_root = os.path.join(generator.root, "generations")
        self.name = generation_name if generation_name is not None else prompt.name
        self.generator = generator
        self.my_root = None
        self.context = context
        self.prompt = prompt
        self.response = response if not isinstance(response, str) else None
        self.response_text = response if isinstance(response, str) else None
        self.store_results = store_results
        self.set_root_if()
        try:
            self.response_text = response.choices[0].message.content
        except:
            ...
        self._assessment = None

    @property
    def assessment(self) -> dict[str, str | int]:
        return self._assessment

    @assessment.setter
    def assessment(self, a: dict[str, str | int]) -> None:
        self._assessment = a
        if self.store_results:
            self.save_assessment()

    def save_assessment(self, a: dict[str, str | int] = None) -> None:
        if a is None:
            a = self.assessment
        if a is None:
            raise PromptException("Assessment cannot be None")
        FileUtility.save_file(
            file="assessment.json", path=self.my_root, content=json.dumps(a)
        )

    def set_root_if(self) -> None:
        if self.store_results is not True:
            return
        root = os.path.join(self.generations_root, self.name)
        self.my_root = root
        self.assure_root_if()

    def assure_root_if(self) -> None:
        if self.store_results is not True:
            return
        if os.path.exists(self.my_root):
            return
        os.makedirs(self.my_root)

    def save_if(self) -> None:
        if self.store_results is True:
            self.save()

    def save(self) -> None:
        print(f"Generation.save: my root: {self.my_root}")
        self.create_manifest()
        self.write_if(name="manifest.txt", content=self.manifest)
        if self.response:
            json_friendly_response = str(self.response)
            self.write_if(name="response.txt", content=self.response_text)
            self.write_if(name="response-raw.txt", content=json_friendly_response)
        self.write_if(
            name="outbound-msg.json",
            content=self.context.json_friendly_messages(),
            tojson=True,
        )
        # we don't need these here because we have them in the prompts tree -- and
        # the prompts and context files should not change -- but having them here is
        # maybe a bit more secure and easier?
        self.write_if(name=Prompt.EXAMPLE_NAME, content=self.prompt.example)
        self.write_if(name=Prompt.RULES_NAME, content=self.prompt.rules)

    def write_if(self, *, name: str, content: str | Any, tojson=False) -> None:
        if self.store_results is not True:
            return
        if content is None:
            print(f"Content for {name} should not be none")
            return
        try:
            if tojson:
                content = json.dumps(content, indent=4)
            FileUtility.save_file(path=self.my_root, file=name, content=content)
        except Exception:
            print(traceback.format_exc())


    def run_time_delta(self) -> tuple[datetime.datetime, datetime.timedelta]:
        if self.runtime_delta is None:
            now = datetime.datetime.now()
            td = now - self.started_at
            self.runtime_delta = (now, td)
        return self.runtime_delta

    def create_manifest(self) -> None:
        now, td = self.run_time_delta()
        mani = f"""
Manifest
-----------
Context:       {self.context.name}
Prompt:        {self.prompt.name}
Generation:    {self.name}
Started at:    {self.started_at}
Finished at:   {now}
Run seconds:   {td.total_seconds()}
"""
        self.manifest = mani

    @property
    def response(self) -> dict:
        return self._response

    @response.setter
    def response(self, r: dict) -> None:
        self._response = r

    @property
    def context(self) -> dict:
        return self._context

    @context.setter
    def context(self, c: dict) -> None:
        self._context = c

    @property
    def prompt(self) -> dict:
        return self._prompt

    @prompt.setter
    def prompt(self, p: dict) -> None:
        self._prompt = p
