from datetime import datetime
from enum import Enum
from typing import Any, Optional
from pydantic import BaseModel


# ---------------------------------------------------------------------------
# Request models
# ---------------------------------------------------------------------------

class CreateProjectRequest(BaseModel):
    name: str
    config_str: Optional[str] = None


class SetValueRequest(BaseModel):
    value: str


class RegisterFileRequest(BaseModel):
    project_name: str
    file_location: str
    template: Optional[str] = None


class RegisterValidationRequest(BaseModel):
    project_name: str
    file_location: str
    append: Optional[bool] = False
    template: Optional[str] = None


class CreateKeyRequest(BaseModel):
    key_name: str
    key_owner_name: str
    key_owner_contact: str


class PromoteKeyRequest(BaseModel):
    api_key: str


class SetLocalFilesRequest(BaseModel):
    allowed: bool


class RunMethod(str, Enum):
    fast_forward_paths = "fast_forward_paths"
    collect_paths = "collect_paths"
    fast_forward_by_line = "fast_forward_by_line"
    collect_by_line = "collect_by_line"


class StartRunRequest(BaseModel):
    project_name: str
    file_name: str
    validation_name: str
    file_location: Optional[str] = None
    file_template: Optional[str] = None
    method: Optional[RunMethod] = RunMethod.collect_paths
    run_template: Optional[str] = None
    delimiter: Optional[str] = None
    quotechar: Optional[str] = None


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------


class MessageResponse(BaseModel):
    message: str


class ErrorResponse(BaseModel):
    error: str


class ValueResponse(BaseModel):
    value: str


class NamesResponse(BaseModel):
    names: list[str]


class ReferenceResponse(BaseModel):
    reference: str


class FilesResponse(BaseModel):
    files: list[str]


class PathsResponse(BaseModel):
    paths: list[str]


class RunAcceptedResponse(BaseModel):
    run_uuid: str
    registration_reference: Optional[str] = None


class RegistrationAcceptedResponse(BaseModel):
    uuid: str


class RunStatusResponse(BaseModel):
    run_uuid: str
    project_name: str
    validation_name: str
    file_name: str
    run_method: str
    start_time: Optional[datetime]
    end_time: Optional[datetime]
    result_reference: Optional[str]


class RunsResponse(BaseModel):
    runs: list[RunStatusResponse]


class NewKeyResponse(BaseModel):
    api_key: str


class ErrorsResponse(BaseModel):
    errors: list[Any]


class MetaResponse(BaseModel):
    meta: dict[str, Any]


class VariablesResponse(BaseModel):
    variables: dict[str, Any]
