import base64
import json
from typing import Any, Optional

from csvpath.util.file_readers import DataFileReader
from csvpath.util.nos import Nos

from fastapi import APIRouter, Depends, Query

from flightpath_server.v2.models import (
    ErrorsResponse,
    MetaResponse,
    NamesResponse,
    VariablesResponse,
    ValueResponse,
)
from flightpath_server.routers.framework_context import fm_context as _fm
from flightpath_server.config.app_config import AppConfig
from flightpath_server.dependencies import get_api_key, get_app_config

archive_router = APIRouter()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _ref(name: str, run_dir: str = None) -> str:
    return f"${name}.results.:all" if run_dir is None else f"${name}.results.{run_dir}"


def _sep(path: str) -> str:
    return Nos(path).sep[0]


def _resolve_csvpath_dir(
    api_key: str,
    project_name: str,
    name: str,
    run_dir: str,
    csvpath_id: str,
    app_config: AppConfig,
) -> str:
    """Returns the result directory for the given csvpath_id within a run, or raises 404."""
    with _fm(api_key, project_name, app_config) as fm:
        ret = fm.find_results(_ref(name, run_dir))
    if not ret.get("success"):
        raise app_config.http_error(
            name=__name__,
            code=404,
            msg=ret.get("message") or f"Run '{run_dir}' not found for '{name}'",
        )
    for path in (ret.get("results") or []):
        sep = _sep(path)
        csvpath_dir = path.rpartition(sep)[0]
        if csvpath_dir.rpartition(sep)[2] == csvpath_id:
            return csvpath_dir
    raise app_config.http_error(
        name=__name__,
        code=404,
        msg=f"Csvpath '{csvpath_id}' not found in run '{run_dir}'",
    )


def _read_json(path: str, fallback: Any) -> Any:
    if not Nos(path).exists():
        return fallback
    with DataFileReader(path) as f:
        return json.loads(f.read())


def _read_b64(path: str) -> Optional[str]:
    if not Nos(path).exists():
        return None
    with DataFileReader(path) as f:
        content = f.read()
    if not isinstance(content, bytes):
        content = content.encode("utf-8")
    return base64.b64encode(content).decode("utf-8")


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@archive_router.get("")
def list_named_results(
    project_name: str,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> NamesResponse:
    """Returns the names of all named-results groups for the project."""
    with _fm(api_key, project_name, app_config) as fm:
        ret = fm.list_result_names()
        if ret.get("success") is True:
            return NamesResponse(names=ret.get("names") or [])
        raise app_config.http_error(
            name=__name__, code=500, msg=",".join(ret.get("errors") or ["Unknown error"])
        )


@archive_router.get("/{name}")
def list_runs(
    name: str,
    project_name: str,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> NamesResponse:
    """Lists run_dirs for a named-paths group (most recent first)."""
    with _fm(api_key, project_name, app_config) as fm:
        ret = fm.find_completed_runs(_ref(name))
    if ret.get("success"):
        runs = ret.get("runs") or []
        return NamesResponse(names=[r.rpartition(_sep(r))[2] for r in runs])
    raise app_config.http_error(
        name=__name__, code=500, msg=",".join(ret.get("errors") or ["Unknown error"])
    )


@archive_router.get("/{name}/{run_dir}")
def list_csvpath_ids(
    name: str,
    run_dir: str,
    project_name: str,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> NamesResponse:
    """Lists the csvpath IDs that produced results in a specific run."""
    with _fm(api_key, project_name, app_config) as fm:
        ret = fm.find_results(_ref(name, run_dir))
    if ret.get("success"):
        paths = ret.get("results") or []
        ids = [p.rpartition(_sep(p))[0].rpartition(_sep(p))[2] for p in paths]
        return NamesResponse(names=ids)
    raise app_config.http_error(
        name=__name__,
        code=404,
        msg=ret.get("message") or f"Run '{run_dir}' not found for '{name}'",
    )


@archive_router.get("/{name}/{run_dir}/{csvpath_id}/errors")
def get_errors(
    name: str,
    run_dir: str,
    csvpath_id: str,
    project_name: str,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> ErrorsResponse:
    """Returns errors recorded during this csvpath's run. Returns an empty list if no errors occurred."""
    d = _resolve_csvpath_dir(api_key, project_name, name, run_dir, csvpath_id, app_config)
    errors = _read_json(f"{d}{_sep(d)}errors.json", [])
    return ErrorsResponse(errors=errors if isinstance(errors, list) else [])


@archive_router.get("/{name}/{run_dir}/{csvpath_id}/meta")
def get_meta(
    name: str,
    run_dir: str,
    csvpath_id: str,
    project_name: str,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> MetaResponse:
    """Returns the metadata recorded during this csvpath's run."""
    d = _resolve_csvpath_dir(api_key, project_name, name, run_dir, csvpath_id, app_config)
    meta = _read_json(f"{d}{_sep(d)}meta.json", {})
    return MetaResponse(meta=meta if isinstance(meta, dict) else {})


@archive_router.get("/{name}/{run_dir}/{csvpath_id}/variables")
def get_variables(
    name: str,
    run_dir: str,
    csvpath_id: str,
    project_name: str,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> VariablesResponse:
    """Returns the variables set during this csvpath's run."""
    d = _resolve_csvpath_dir(api_key, project_name, name, run_dir, csvpath_id, app_config)
    variables = _read_json(f"{d}{_sep(d)}vars.json", {})
    return VariablesResponse(variables=variables if isinstance(variables, dict) else {})


@archive_router.get("/{name}/{run_dir}/{csvpath_id}/data")
def get_data(
    name: str,
    run_dir: str,
    csvpath_id: str,
    project_name: str,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> ValueResponse:
    """Returns the base64-encoded content of data.csv (the matched rows) for this csvpath's run."""
    d = _resolve_csvpath_dir(api_key, project_name, name, run_dir, csvpath_id, app_config)
    content = _read_b64(f"{d}{_sep(d)}data.csv")
    if content is None:
        raise app_config.http_error(
            name=__name__, code=404, msg="data.csv not found for this run"
        )
    return ValueResponse(value=content)


@archive_router.get("/{name}/{run_dir}/{csvpath_id}/unmatched")
def get_unmatched(
    name: str,
    run_dir: str,
    csvpath_id: str,
    project_name: str,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> ValueResponse:
    """Returns the base64-encoded content of unmatched.csv (the non-matching rows) for this csvpath's run."""
    d = _resolve_csvpath_dir(api_key, project_name, name, run_dir, csvpath_id, app_config)
    content = _read_b64(f"{d}{_sep(d)}unmatched.csv")
    if content is None:
        raise app_config.http_error(
            name=__name__, code=404, msg="unmatched.csv not found for this run"
        )
    return ValueResponse(value=content)


@archive_router.get("/{name}/{run_dir}/{csvpath_id}/printouts")
def get_printouts(
    name: str,
    run_dir: str,
    csvpath_id: str,
    project_name: str,
    printstream: Optional[str] = Query(default=None),
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> ValueResponse:
    """Returns the base64-encoded printouts for this csvpath's run.

    Pass printstream to retrieve a named printstream file (e.g. printstream=report returns
    report.txt). Omit printstream to retrieve the default printouts.txt."""
    d = _resolve_csvpath_dir(api_key, project_name, name, run_dir, csvpath_id, app_config)
    if printstream is None:
        filename = "printouts.txt"
    elif printstream.endswith(".txt"):
        filename = printstream
    else:
        filename = f"{printstream}.txt"
    sep = _sep(d)
    content = _read_b64(f"{d}{sep}{filename}")
    if content is None:
        raise app_config.http_error(
            name=__name__, code=404, msg=f"{filename} not found for this run"
        )
    return ValueResponse(value=content)


@archive_router.get("/{name}/{run_dir}/{csvpath_id}/files/{filename:path}")
def get_file(
    name: str,
    run_dir: str,
    csvpath_id: str,
    filename: str,
    project_name: str,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> ValueResponse:
    """Returns any file in the run result directory as base64-encoded content.

    Use this to retrieve Parquet files or any other output files generated during the run."""
    d = _resolve_csvpath_dir(api_key, project_name, name, run_dir, csvpath_id, app_config)
    content = _read_b64(f"{d}{_sep(d)}{filename}")
    if content is None:
        raise app_config.http_error(
            name=__name__, code=404, msg=f"{filename} not found for this run"
        )
    return ValueResponse(value=content)
