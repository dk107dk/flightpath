from typing import Optional
from uuid import uuid4

from fastapi import APIRouter, BackgroundTasks, Depends, Query, status

from csvpath.util.box import Box

from flightpath_server.framework_manager import FrameworkManager
from flightpath_server.routers.framework_context import fm_context as _fm
from flightpath_server.runs.run_manager import RunManager
from flightpath_server.runs.run import Run
from flightpath_server.v2.models import ReferenceResponse, RunAcceptedResponse, RunMethod, RunStatusResponse, RunsResponse, StartRunRequest
from flightpath_server.config.app_config import AppConfig
from flightpath_server.dependencies import get_api_key, get_app_config

runs_router = APIRouter()


def _run_to_status(run: Run) -> RunStatusResponse:
    return RunStatusResponse(
        run_uuid=run.run_uuid,
        project_name=run.project_name,
        validation_name=run.pathsname,
        file_name=run.filename,
        run_method=run.run_method,
        start_time=run.start_time,
        end_time=run.end_time,
        result_reference=run.result_reference,
    )


def _execute_run(
    *,
    run_uuid: str,
    project_name: str,
    file_name: str,
    validation_name: str,
    method: str,
    template: Optional[str],
    delimiter: Optional[str],
    quotechar: Optional[str],
    api_key: str,
    app_config: AppConfig,
) -> None:
    try:
        fm = FrameworkManager(api_key=api_key, app_config=app_config, project_name=project_name)
        if delimiter is not None:
            fm.csvpaths.delimiter = delimiter
        if quotechar is not None:
            fm.csvpaths.quotechar = quotechar
        run = fm.run_manager.new_run(
            csvpaths=fm.csvpaths,
            run_method=method,
            pathsname=validation_name,
            filename=file_name,
            template=template,
            api_key=api_key,
            project_name=project_name,
            run_uuid=run_uuid,
            extra_data={"uuid": run_uuid},
        )
        fm.run_manager.do_run(run)
    except Exception as e:
        app_config.logger.exception("Background run %s failed: %s", run_uuid, e)
    finally:
        Box().empty_my_stuff()


@runs_router.post("", status_code=status.HTTP_202_ACCEPTED)
async def start_run(
    request: StartRunRequest,
    background_tasks: BackgroundTasks,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> RunAcceptedResponse:
    """Starts a run in the background. Returns 202 immediately with a run_uuid for polling.

    When file_location is provided, the file is registered synchronously before the run is
    dispatched. The response includes both the run_uuid and the registration_reference."""
    registration_reference = None
    if request.file_location is not None:
        with _fm(api_key, request.project_name, app_config) as fm:
            ret = fm.register_file(
                named_file_name=request.file_name,
                file_location=request.file_location,
                template=request.file_template,
            )
            if not ret.get("success"):
                raise app_config.http_error(
                    name=__name__,
                    code=500,
                    msg=",".join(ret.get("errors") or ["Registration failed"]),
                )
            registration_reference = ret.get("reference")
    run_uuid = str(uuid4())
    background_tasks.add_task(
        _execute_run,
        run_uuid=run_uuid,
        project_name=request.project_name,
        file_name=request.file_name,
        validation_name=request.validation_name,
        method=request.method.value,
        template=request.run_template,
        delimiter=request.delimiter,
        quotechar=request.quotechar,
        api_key=api_key,
        app_config=app_config,
    )
    return RunAcceptedResponse(run_uuid=run_uuid, registration_reference=registration_reference)


@runs_router.get("")
def list_active_runs(
    validation_name: Optional[str] = Query(default=None),
    file_name: Optional[str] = Query(default=None),
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> RunsResponse:
    """Returns all active (in-progress) runs for the authenticated key, optionally filtered by validation_name or file_name."""
    rm = RunManager(app_config=app_config)
    runs = rm.get_active_runs(api_key=api_key, pathsname=validation_name, filename=file_name)
    return RunsResponse(runs=[_run_to_status(r) for r in runs])


@runs_router.get("/{run_uuid}")
def get_run(
    run_uuid: str,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> RunStatusResponse:
    """Returns the status of a run by UUID. Works for both active and completed runs. Returns 404 if the UUID is unknown."""
    rm = RunManager(app_config=app_config)
    # Find across all history, then verify it belongs to this key
    run = rm.find_run(run_uuid)
    if run is None:
        raise app_config.http_error(name=__name__, code=404, msg=f"Run '{run_uuid}' not found")
    hashed = rm.key_manager.hash_key(api_key)
    if run.api_key != hashed:
        raise app_config.http_error(name=__name__, code=404, msg=f"Run '{run_uuid}' not found")
    return _run_to_status(run)


@runs_router.get("/{name}/reference")
def find_reference_for_uuid(
    name: str,
    uuid: str = Query(...),
    project_name: str = Query(...),
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> ReferenceResponse:
    """Returns the permanent run reference for a completed run, looked up by UUID.

    The search is scoped to the named-paths group (name) to bound the archive crawl.
    Returns 404 if the run is still active or if no archived run matching the UUID is found."""
    rm = RunManager(app_config=app_config)
    run = rm.find_run(uuid)
    if run is not None:
        hashed = rm.key_manager.hash_key(api_key)
        if run.api_key != hashed:
            raise app_config.http_error(name=__name__, code=404, msg=f"Run '{uuid}' not found")
        if run.end_time is None:
            raise app_config.http_error(
                name=__name__, code=404, msg=f"Run '{uuid}' is still active; reference not yet available"
            )
    with _fm(api_key, project_name, app_config) as fm:
        ret = fm.find_reference_by_uuid(name=name, run_uuid=uuid)
    if not ret.get("success"):
        raise app_config.http_error(
            name=__name__, code=500, msg=",".join(ret.get("errors") or ["Unknown error"])
        )
    reference = ret.get("reference")
    if reference is None:
        raise app_config.http_error(
            name=__name__, code=404, msg=f"No archived run found for uuid '{uuid}' under '{name}'"
        )
    return ReferenceResponse(reference=reference)
