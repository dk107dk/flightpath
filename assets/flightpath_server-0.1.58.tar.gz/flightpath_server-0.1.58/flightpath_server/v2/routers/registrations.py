import base64
from typing import Optional
from uuid import uuid4

from fastapi import APIRouter, BackgroundTasks, Depends, Query, status
from csvpath.util.box import Box
from csvpath.util.references.reference_parser import ReferenceParser

from flightpath_server.framework_manager import FrameworkManager
from flightpath_server.v2.models import (
    FilesResponse,
    NamesResponse,
    RegistrationAcceptedResponse,
    ReferenceResponse,
    RegisterFileRequest,
    ValueResponse,
)
from flightpath_server.routers.framework_context import fm_context as _fm
from flightpath_server.config.app_config import AppConfig
from flightpath_server.dependencies import get_api_key, get_app_config

registrations_router = APIRouter()


def _execute_registration(
    *,
    uuid: str,
    name: str,
    project_name: str,
    file_location: str,
    template: Optional[str],
    api_key: str,
    app_config: AppConfig,
) -> None:
    try:
        fm = FrameworkManager(api_key=api_key, app_config=app_config, project_name=project_name)
        ret = fm.registration_manager.register_file(
            named_file_name=name,
            file_location=file_location,
            template=template,
            uuid=uuid,
        )
        if not ret.get("success"):
            app_config.logger.error(
                "Background registration %s failed: %s",
                uuid,
                ",".join(ret.get("errors") or []),
            )
    except Exception as e:
        app_config.logger.exception("Background registration %s failed: %s", uuid, e)
    finally:
        Box().empty_my_stuff()


def _name_from_reference(reference: str) -> str:
    if reference and not reference[0] == "$":
        reference = f"${reference}.files.:last"
    ref = ReferenceParser(reference)
    return ref.root_major


def _assert_reference_name(name: str, reference: str, app_config: AppConfig) -> None:
    ref_name = _name_from_reference(reference)
    if ref_name != name:
        raise app_config.http_error(
            name=__name__,
            code=400,
            msg=f"Reference name '{ref_name}' does not match path name '{name}'",
        )


@registrations_router.get("")
def list_registrations(
    project_name: str,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> NamesResponse:
    """Returns the names of all registered named-files for the project."""
    with _fm(api_key, project_name, app_config) as fm:
        ret = fm.list_file_names()
        if ret.get("success") is True:
            return NamesResponse(names=ret.get("names") or [])
        raise app_config.http_error(
            name=__name__, code=500, msg=",".join(ret.get("errors") or ["Unknown error"])
        )


@registrations_router.post("/{name}", status_code=status.HTTP_202_ACCEPTED)
async def register_file(
    name: str,
    request: RegisterFileRequest,
    background_tasks: BackgroundTasks,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> RegistrationAcceptedResponse:
    """Starts file registration in the background. Returns 202 immediately with a uuid for polling.

    Use GET /{name}/reference?uuid=<uuid> to retrieve the permanent reference once registration completes."""
    registration_uuid = str(uuid4())
    background_tasks.add_task(
        _execute_registration,
        uuid=registration_uuid,
        name=name,
        project_name=request.project_name,
        file_location=request.file_location,
        template=request.template,
        api_key=api_key,
        app_config=app_config,
    )
    return RegistrationAcceptedResponse(uuid=registration_uuid)


@registrations_router.get("/{name}/reference")
def find_file_reference(
    name: str,
    uuid: str = Query(...),
    project_name: str = Query(...),
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> ReferenceResponse:
    """Returns the permanent reference for a registered file, looked up by UUID.

    Returns 404 if the registration is still in progress or if no registration matching the UUID is found."""
    with _fm(api_key, project_name, app_config) as fm:
        ret = fm.find_file_reference_by_uuid(name=name, uuid=uuid)
    if not ret.get("success"):
        raise app_config.http_error(
            name=__name__, code=500, msg=",".join(ret.get("errors") or ["Unknown error"])
        )
    reference = ret.get("reference")
    if reference is None:
        raise app_config.http_error(
            name=__name__, code=404, msg=f"No completed registration found for uuid '{uuid}' under '{name}'"
        )
    return ReferenceResponse(reference=reference)


@registrations_router.get("/{name}")
def find_files(
    name: str,
    project_name: str,
    reference: Optional[str] = Query(default=None),
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> FilesResponse:
    """Returns the paths of registered named-file versions matching the reference. Omitting reference returns exactly one path — the most recent version of the named-file (equivalent to $name.files.:last). Supplying a reference allows finer selection: any number of versions, by arrival time, ordinal position, hash fingerprint, or file path."""
    if reference is not None:
        _assert_reference_name(name, reference, app_config)
    with _fm(api_key, project_name, app_config) as fm:
        ret = fm.find_registered_files(reference=reference or name)
        if ret.get("success") is True:
            return FilesResponse(files=ret.get("files") or [])
        raise app_config.http_error(
            name=__name__, code=500, msg=",".join(ret.get("errors") or [ret.get("message")] or ["Unknown error"])
        )


@registrations_router.get("/{name}/content")
def get_file_content(
    name: str,
    project_name: str,
    reference: Optional[str] = Query(default=None),
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> ValueResponse:
    """Returns the base64-encoded content of the registered file identified by the reference. Omitting reference returns the most recent file. The reference must resolve to exactly one file."""
    if reference is not None:
        _assert_reference_name(name, reference, app_config)
    with _fm(api_key, project_name, app_config) as fm:
        ret = fm.get_registered_file(reference=reference or name)
        if ret.get("success") is True:
            file = ret.get("file")
            if not isinstance(file, bytes):
                file = file.encode("utf-8")
            return ValueResponse(value=base64.b64encode(file).decode("utf-8"))
        if ret.get("message"):
            raise app_config.http_error(name=__name__, code=404, msg=ret.get("message"))
        raise app_config.http_error(
            name=__name__, code=500, msg=",".join(ret.get("errors") or ["Unknown error"])
        )
