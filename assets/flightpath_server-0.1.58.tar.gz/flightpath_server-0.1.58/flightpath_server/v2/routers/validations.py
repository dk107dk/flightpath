from typing import Optional
from fastapi import APIRouter, Depends, Query, status

from flightpath_server.v2.models import NamesResponse, PathsResponse, ReferenceResponse, RegisterValidationRequest
from flightpath_server.routers.framework_context import fm_context as _fm
from flightpath_server.config.app_config import AppConfig
from flightpath_server.dependencies import get_api_key, get_app_config

validations_router = APIRouter()


@validations_router.get("")
def list_validations(
    project_name: str,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> NamesResponse:
    """Returns the names of all registered named-paths groups for the project."""
    with _fm(api_key, project_name, app_config) as fm:
        ret = fm.list_validation_names()
        if ret.get("success") is True:
            return NamesResponse(names=ret.get("names") or [])
        raise app_config.http_error(
            name=__name__, code=500, msg=",".join(ret.get("errors") or ["Unknown error"])
        )


@validations_router.post("/{name}", status_code=status.HTTP_201_CREATED)
def register_validation(
    name: str,
    request: RegisterValidationRequest,
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> ReferenceResponse:
    """Registers a named-paths group (the csvpath expressions for a validation). Creates a new version if the group already exists."""
    with _fm(api_key, request.project_name, app_config) as fm:
        ret = fm.register_csvpath_group(
            named_paths_name=name,
            file_location=request.file_location,
            template=request.template,
            append=request.append,
        )
        if ret.get("success") is True:
            return ReferenceResponse(reference=ret.get("reference"))
        raise app_config.http_error(
            name=__name__, code=400, msg=",".join(ret.get("errors") or ["Registration failed"])
        )


@validations_router.get("/{name}")
def get_validation(
    name: str,
    project_name: str,
    reference: Optional[str] = Query(default=None),
    api_key: str = Depends(get_api_key),
    app_config: AppConfig = Depends(get_app_config),
) -> PathsResponse:
    """Returns the csvpath expressions in the named-paths group. Omitting reference returns the full group. Passing a reference (e.g. $name.csvpaths.:2:from) returns a subset by index."""
    with _fm(api_key, project_name, app_config) as fm:
        ret = fm.get_validation_paths(reference or name)
        if ret.get("success") is True:
            return PathsResponse(paths=ret.get("paths") or [])
        raise app_config.http_error(
            name=__name__,
            code=404,
            msg=ret.get("message") or f"Validation group '{name}' not found",
        )
