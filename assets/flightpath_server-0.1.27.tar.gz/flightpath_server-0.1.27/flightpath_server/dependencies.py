from fastapi import Depends, Security, Request
from fastapi.security.api_key import APIKeyHeader
from flightpath_server.keys.key_manager import KeyManager
from flightpath_server.config.app_config import AppConfig

API_KEY_NAME: str = "access_token"
API_KEY_HEADER: APIKeyHeader = APIKeyHeader(name=API_KEY_NAME, auto_error=False)


def get_app_config(request: Request) -> AppConfig:
    if (
        not hasattr(request.app.state, "app_config")
        or request.app.state.app_config is None
    ):
        raise RuntimeError("AppConfig not loaded. Ensure startup event has run.")
    return request.app.state.app_config


def get_key_manager(app_config: AppConfig = Depends(get_app_config)) -> KeyManager:
    return KeyManager(app_config=app_config)


async def get_api_key(
    api_key_header: str = Security(API_KEY_HEADER),
    key_manager: KeyManager = Depends(get_key_manager),
    app_config: AppConfig = Depends(get_app_config),
) -> str:
    if api_key_header is None:
        msg = "API Key is missing. Please provide an 'access_token' in the request header."
        raise app_config.http_error(name=__name__, code=401, msg=msg)
    if key_manager.validate_key(api_key_header):
        return api_key_header
    else:
        msg = "Could not validate API key"
        raise app_config.http_error(name=__name__, code=403, msg=msg)


async def get_optional_api_key(
    api_key_header: str = Security(API_KEY_HEADER),
    key_manager: KeyManager = Depends(get_key_manager),
    app_config: AppConfig = Depends(get_app_config),
) -> str | None:
    if not api_key_header:
        return None
    if key_manager.validate_key(api_key_header):
        return api_key_header
    else:
        msg = "Invalid API key"
        raise app_config.http_error(name=__name__, code=403, msg=msg)


async def require_admin_key(
    api_key: str = Depends(get_api_key),
    key_manager: KeyManager = Depends(get_key_manager),
    app_config: AppConfig = Depends(get_app_config),
) -> None:
    key_data = key_manager.get_key_data(api_key)
    if not key_data or not key_data.admin:
        msg = "Admin privileges required"
        raise app_config.http_error(name=__name__, code=403, msg=msg)
