import os
import datetime
import json
import traceback

from ratelimit import limits
from csvpath import CsvPath
from csvpath.util.config import Config as CsvPathConfig
from csvpath.util.nos import Nos

from flightpath_generator.managers.context_manager import ContextManager
from flightpath_generator.managers.generation_manager import GenerationManager
from flightpath_generator.managers.prompt_manager import PromptManager
from flightpath_generator.prompts import Prompt, Context, Generation
from flightpath_generator.util.config import Config

from flightpath_generator.client.tools import GeneratorTool

from flightpath_generator.client.llm_client import LiteLLMClient


class Generator:
    """
    Use like:
        #
        # set up the two config objects. csvpath config sets the AI.
        # generator config sets the context and prompt template versions
        #
        csvpath = CsvPath()
        cc = csvpath.config
        path = os.path.dirname(cc.configpath)
        config = Config(os.path.join(path, "generator.ini"))
        #
        # set up generator. version key identities context, template pairs
        # so that we can configure multiple uses of generators.
        #
        generator = Generator(config)
        generator.csvpath_config = cc
        generator.version_key="question"
        #
        # create a context. mainly used for system prompt inputs. can also
        # create user/assistant back-and-forth.
        #
        context = generator.context_manager.get_context()
        #
        # create a prompt obj from the user's input and save it for future
        # reference. context and templates are preexisting. prompts are
        # created saved and then used. inside generator prompt and context
        # are merged to make the API call that results in a generation.
        #
        prompt = generator.prompt_manager.create_prompt()
        prompt.rules = "How do I check if a date is from last week?"
        prompt.example = "..."
        prompt.save()
        #
        # run the prompt and receive a generation obj with results. the
        # generation is a collection of inputs and outputs of one API call.
        #
        generation = generator.do_send(context=context, prompt=prompt)
    """
    def __init__(self, config=None) -> None:
        self._config = config if config is not None else Config()
        self._root = self._config.get("storage", "root")
        if self._root is None:
            raise ValueError(f"Storage root cannot be None in {self._config.configpath}")
        self.context_manager = ContextManager(generator=self)
        self.prompt_manager = PromptManager(generator=self)
        self._csvpath_config = None
        self._csvpath_logger = None
        self._prod = None
        self._context = None
        self._context_name = None
        self.assure_paths()
        self._version_key = "default"
        self._model = None
        self._api_base = None
        self._tools = None

#=============
# properties
#=============

    @property
    def root(self) -> str:
        return self._root

    @root.setter
    def root(self, root: str) -> None:
        self._root = root

    @property
    def config(self) -> Config:
        return self._config

    @property
    def model(self) -> str:
        return self._model

    @model.setter
    def model(self, m:str) -> None:
        self._model = m

    @property
    def api_base(self) -> str:
        return self._api_base

    @api_base.setter
    def api_base(self, a:str) -> None:
        self._api_base = a

    @property
    def prod(self) -> bool:
        if self._prod is None:
            prod = self.config.get("env", "prod")
            self._prod = f"{prod}".strip().lower() == "true"
        return self._prod

    @prod.setter
    def prod(self, prod: bool) -> None:
        self._prod = prod

    @property
    def context_name(self) -> str:
        if self._context_name is None:
            self._context_name = self.config.get("version", "context")
        return self._context_name

    @context_name.setter
    def context_name(self, c: str) -> None:
        self._context_name = c

    @property
    def context(self) -> str:
        if self._context is None:
            self._context = self.context_manager.get_context(self.context_name)
        return self._context

    @context.setter
    def context(self, context: Context) -> None:
        self._context = context

    @property
    def tools(self) -> dict:
        return self._tools

    @tools.setter
    def tools(self, t:dict) -> None:
        self._tools = t

    @property
    def version_key(self) -> str:
        return self._version_key

    @version_key.setter
    def version_key(self, key:str) -> None:
        self._version_key = key

    @property
    def manifest(self) -> list:
        path = os.path.join(self._root, "manifest.json")
        if not os.path.exists(path):
            with open(path, "w") as file:
                json.dump([],file)
        with open (path, "r") as file:
            return json.load(file)

    @manifest.setter
    def manifest(self, mani:list ) -> None:
        path = os.path.join(self._root, "manifest.json")
        with open(path, "w") as file:
            json.dump(mani, file, indent=2)

    @property
    def csvpath_logger(self) -> CsvPathConfig:
        if self._csvpath_logger is None:
            self._csvpath_logger = CsvPath().logger
        return self._csvpath_logger

    @csvpath_logger.setter
    def csvpath_logger(self, log ) -> None:
        self._csvpath_logger = log

    @property
    def csvpath_config(self) -> CsvPathConfig:
        if self._csvpath_config is None:
            self._csvpath_config = CsvPath().config
        return self._csvpath_config

    @csvpath_config.setter
    def csvpath_config(self, c:CsvPathConfig ) -> None:
        self._csvpath_config = c

#================
# other methods
#================

    def assure_paths(self) -> None:
        self.assure_root()
        self.context_manager.assure_context_root()
        self.prompt_manager.assure_prompt_root()
        genmgr = GenerationManager(self)
        genmgr.assure_generation_root()

    def dump(self) -> None:
        print(self)

    def __str__(self) -> str:
        return f"""Generator (root:{self.root}, prod:{self.prod}, context_name:{self.context_name}, config:{self.config.configpath})"""

    def assure_root(self) -> None:
        if self.root is None:
            raise ValueError(f"Storage root cannot be None")
        if not os.path.exists(self.root):
           os.makedirs(self.root)

    def create_prompt(self) -> Prompt:
        prompt = self.prompt_manager.create_prompt()
        return prompt

    def create_context(self) -> Context:
        return self.context_manager.create_context()

    def send(self, *, context_name=None, prompt_name=None, store_results=True) -> Generation:
        context = self.context_manager.get_context()
        prompt = self.prompt_manager.get_prompt(prompt_name)
        generation = self.do_send(context, prompt)
        return generation

    @property
    def turns_limit(self) -> int:
        n = self.config.get("generations", "limit", -1)
        if n is None or str(n).strip() == "":
            n = -1
        return int(n)

    def exceeds_turns_limit(self, turn:int) -> int:
        limit = self.turns_limit
        if limit == -1:
            return False
        if limit < turn:
            return True
        return False

    @limits(calls=10, period=900)
    def do_send(self, *,
        context=None,
        prompt=None,
        datapath:str=None,
        messages=None,
        store_results=True,
        turn_number=0
    ) -> Generation:
        if context is None:
            raise ValueError("Context cannot be none")
        if prompt is None:
            raise ValueError("Prompt cannot be none")
        #
        # apply prompt adds the user generated prompt to the
        # context object that constructs the whole api prompt
        # from versioned context files containing system
        # instructions, etc.
        #
        use_tools = False
        if messages:
            #
            # if messages were passed in we need to push them to the LLM, but
            # we also need to backfil into the context so that the generation
            # can serialize the context with the most current messages.
            #
            context.from_json(messages)
        else:
            #
            # give the message templates a chance to use the path of the
            # current data file. this is so a generated csvpath file can
            # include a use-data: or test-data: metadata field.
            #
            if datapath:
                context.background["datapath"] = datapath
            #
            #
            #
            context.apply_prompt(prompt)
            messages = context.json_friendly_messages()
            use_tools = True

        start_time = datetime.datetime.now()
        client = LiteLLMClient(generator=self)
        #
        # we use tools. they are not in the message flow. have
        # to re-add each request cycle so they exist for the model.
        #
        errors = ""
        response = None
        client.tools = self.tools
        try:
            response = client.completion(messages)
        except Exception as ex:
            print(f"Error: Cannot send: {ex}")
            errors=traceback.format_exc()
        generation = Generation(
            generator=self,
            context=context,
            prompt=prompt,
            response=response,
            started_at=start_time,
            turn_number=turn_number,
            errors=errors
        )
        self._track(generation)
        generation.save()
        if errors != "" or not response:
            return generation

        response_message = response.choices[0].message
        tool_calls = response_message.tool_calls
        if tool_calls is not None and len(tool_calls) > 0:
            self._add_response_to_messages(
                generation=generation,
                messages=messages,
                response_message=response_message,
                tool_calls=tool_calls
            )
            #
            # response_message must go into the messages chain here so
            # that claude or another LLM has the tool call id to refer back to
            #
            ok = self._tool_calls(generation, messages, response_message)
            if ok:
                #
                # setting None causes name() to generate a new name
                #
                prompt.name = None
                turn_number += 1
                if self.exceeds_turns_limit(turn_number):
                    generation.add_error("Conversation turns limit reached, including tool use. Cutting things short.")
                    #
                    # signaled above with a flag on the generation.
                    #
                    return generation
                else:
                    generation = self.do_send(messages=messages, context=context, prompt=prompt, turn_number=turn_number)
        self._cleanup_generations_if()
        return generation

    def _add_response_to_messages(self, *, generation, messages, response_message, tool_calls) -> None:
        #
        # this response is needed for the message chain. it will be
        # pulled into into the context's messages, also, so that it
        # will be serialized to the generation's results as part of
        # the turns.
        #
        m = {
              "role": "assistant",
              "content": None,
              "tool_calls": []
            }
        for tool_call in tool_calls:
            m["tool_calls"].append({
                  "id": tool_call.id,
                  "type": "function",
                  "function": {
                    "name": tool_call.function.name,
                    "arguments": tool_call.function.arguments
                  }
            })
        messages.append(m)

    def _tool_calls(self, generation, messages:list, response_message:list) -> bool:
        tool_calls = response_message.tool_calls
        if len(tool_calls) == 0:
            return False
        for tool_call in tool_calls:
            tool_name = tool_call.function.name
            args = json.loads(tool_call.function.arguments)
            t = GeneratorTool.tool_for_name(tool_name)
            if t is None:
                messages.append({
                    "tool_call_id": tool_call.id,
                    "role": "tool",
                    "name": tool_name,
                    "content": "Error: unknown tool"
                })
            else:
                m = t.use(generation, tool_call, args)
                messages.append(m)
        return True


    def _track(self, generation:Generation) -> None:
        now, td = generation.run_time_delta()
        mani = self.manifest
        stats = {
            "model":self.model,
            "api_base":self.api_base,
            "context": f"{os.path.join(self._root, "contexts", generation.context.name)}",
            "prompt": f"{os.path.join(self._root, "prompts", generation.prompt.name)}",
            "generation": f"{os.path.join(self._root, "generations", generation.name)}",
            "started_at": str(generation.started_at),
            "ended_at": str(now),
            "duration": td.total_seconds()
        }
        mani.append( stats )
        self.manifest = mani

    def _cleanup_generations_if(self) -> None:
        n = self.config.get("generations", "limit", -1)
        n = int(n)
        if n < 0:
            return
        mani = self.manifest
        if len(mani) < n:
            return
        mani = mani[len(mani)-n:]
        self.manifest = mani
        #
        # clean up prompts
        #
        prompts_path = os.path.join(self._root, "prompts")
        nos = Nos(prompts_path)
        lst = nos.listdir(dirs_only=True)
        for _ in lst:
            _ = os.path.join(prompts_path, _)
            found = False
            for p in mani:
                if _ == p.get("prompt"):
                    found = True
                    continue
            if not found:
                nos = Nos(_).remove()
        #
        # clean up generations
        #
        gens_path = os.path.join(self._root, "generations")
        nos = Nos(gens_path)
        lst = nos.listdir(dirs_only=True)
        for _ in lst:
            _ = os.path.join(gens_path, _)
            found = False
            for p in mani:
                if _ == p.get("generation"):
                    found = True
                    continue
            if not found:
                nos = Nos(_).remove()


