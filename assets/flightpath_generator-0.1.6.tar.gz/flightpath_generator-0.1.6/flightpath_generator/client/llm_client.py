from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional
import litellm
from csvpath.util.config import Config as CsvPathConfig

class LLMClient(ABC):

    LLM_API_KEY = "LLM_API_KEY"

    def __init__(self, *, generator) -> None:
        if generator is None:
            raise ValueError("Generator cannot be None")
        self._generator = generator
        self._csvpath_config = generator.csvpath_config
        if self._csvpath_config is None:
            raise ValueError("CsvPath config cannot be None")
        self._model = self._csvpath_config.get(section="llm", name="model")
        if self._model is None:
            raise ValueError(f"LLM model cannot be None in {self._csvpath_config.configpath}")
        self._api_base = self._csvpath_config.get(section="llm", name="api_base")
        if self._api_base is None:
            raise ValueError(f"LLM API base cannot be None in {self._csvpath_config.configpath}")
        self._key = self._csvpath_config.get(section="llm", name="api_key", default=None)
        if self._key is None or self._key == LLMClient.LLM_API_KEY:
            #
            # try again to pull from the OS env or env.json
            #
            self._key = self._csvpath_config.get(section=None, name=LLMClient.LLM_API_KEY)
        #
        # if key is still None we either don't need a key or we're relying
        # on an OS env var, but which isn't available because we're using an
        # env.json file that doesn't have the key. if the latter we can't
        # fix it automatically, so let's hope it's the former.
        #
        self._tools = None
        generator.model = self.model
        generator.api_base = self.api_base

    @property
    def tools(self) -> dict:
        return self._tools

    @tools.setter
    def tools(self, t:dict) -> None:
        self._tools = t

    @property
    def api_key(self) -> str:
        return self._key

    @property
    def model(self) -> str:
        return self._model

    @property
    def api_base(self) -> str:
        return self._api_base

    @property
    def csvpath_config(self) -> CsvPathConfig:
        return self._csvpath_config

    @abstractmethod
    def completion(self, messages: List[Dict[str, str]], **kwargs: Any) -> Any:
        pass


class LiteLLMClient(LLMClient):

    def completion(self, messages: List[Dict[str, str]], **kwargs: Any) -> Any:
        litellm_kwargs = {
            "model": self.model,
            "messages": messages,
            "api_base": self.api_base,   # or "http://localhost:11434"
            **kwargs
        }
        #
        # if no key either we must not need one or we're relying on env
        # vars
        #
        print("")
        if self.api_key:
            litellm_kwargs["api_key"] = self.api_key
        if self.tools:
            litellm_kwargs["tools"] = self.tools
        return litellm.completion(**litellm_kwargs)


