import os
from flightpath_generator.prompts import Prompt
from flightpath_generator.util.exceptions import PromptException


class PromptManager:
    def __init__(self, generator):
        if generator is None:
            raise ValueError("Generator cannot be None")
        self._generator = generator
        self._my_root = None
        self.assure_prompt_root()

    def assure_prompt_root(self) -> None:
        path = self.prompt_root
        if not os.path.exists(path):
            os.makedirs(path)

    @property
    def prompt_root(self) -> str:
        if self._my_root is None and self._generator is not None:
            self._my_root = os.path.join(self._generator.root, "prompts")
        return self._my_root

    @property
    def prompt_template_root(self) -> str:
        return os.path.join(self._generator.root, "prompt_templates")

    @prompt_root.setter
    def prompt_root(self, root: str) -> None:
        self._my_root = root

    def create_prompt(self) -> Prompt:
        return Prompt(generator=self._generator)

    def get_prompt(self, name: str) -> Prompt:
        if name is None or name.strip() == "":
            raise PromptException("Prompt name cannot be None")
        p = os.path.join(self.prompt_root, name)
        dlist = os.listdir(p)
        if "example.txt" not in dlist:
            raise PromptException(f"An example.txt file must be in {p}")
        if "rules.txt" not in dlist:
            raise PromptException("rules.txt cannot be None")
        prompt = Prompt(generator=self._generator, name=name)
        prompt._example_path = os.path.join(p, prompt.EXAMPLE_NAME)
        prompt._rules_path = os.path.join(p, prompt.RULES_NAME)
        return prompt
