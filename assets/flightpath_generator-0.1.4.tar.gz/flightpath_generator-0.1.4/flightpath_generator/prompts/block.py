from typing import Self

class Block:

    def __init__(self) -> None:
        self._type = None
        self._text = None
        self._header = None
        self._source = {}



    def __dict__(self):
        return {
            "type": self._type,
            "text": self.text
            #
            # add header and source when needed
        }

    def _fixed_text(self) -> str:
        fixed = f"{self.text}".replace('"', r'\"')
        fixed = fixed.replace('\n', r'\n')
        return fixed

    def append(self, block:Self) -> None:
        if block is None:
            raise ValueError("Block cannot be None")
        t = f"{self.text}\n\n{block.text}"
        self.text = t

    #
    # only doing "text" type blocks atm.
    #
    def to_json(self):
        j = '{"type":"'
        j += self.block_type
        j += '", "text": "'
        j += self._fixed_text()
        j += '"}'
        return j

    @property
    def block_type(self) -> str:
        return self._type

    @block_type.setter
    def block_type(self, bt:str) -> str:
        self._type = bt

    @property
    def text(self) -> str:
        return self._text

    @text.setter
    def text(self, t:str) -> str:
        self._text = t

    @property
    def header(self) -> str:
        return _header._text

    @header.setter
    def header(self, cc:str) -> str:
        self._header = cc



