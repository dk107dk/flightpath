import sqlite3


class CounterUtility:
    """cheap and cheerful counter for reasonably stateful,
    reasonably threadsafe for very not-critical use. keeps its
    sqllite db in /tmp. will be lost/reset every release. atm
    that is fine.
    """

    @classmethod
    def increment(cls) -> int:
        return cls.next(identifier="increment")

    @classmethod
    def next(cls, *, dbid="increment", identifier: str) -> int:
        cls.assure_table(dbid=dbid, identifier=identifier)
        dbs = f"/tmp/{dbid}.db"
        sql = sqlite3.connect(dbs)
        sql.isolation_level = None
        c = sql.cursor()
        c.execute("begin exclusive transaction")
        try:
            i = 0
            c.execute(f" SELECT count FROM {identifier} where ROWID = 1")
            row = c.fetchone()
            if row is None:
                c.execute(f" INSERT INTO {identifier}(count) VALUES(0)")
            else:
                i = row[0]
            i += 1
            c.execute(f" UPDATE {identifier} SET count={i} WHERE rowid = 1")
            c.execute("commit")
            return i
        except sql.Error as e:
            c.execute("rollback")
            c.close()
            sql.close()
            raise e
        c.close()
        sql.close()

    @classmethod
    def assure_table(cls, *, dbid="increment", identifier: str) -> None:
        dbs = f"/tmp/{dbid}.db"
        sql = sqlite3.connect(dbs)
        sql.isolation_level = None
        c = sql.cursor()
        s = f"CREATE TABLE IF NOT EXISTS {identifier}( count INTEGER );"
        c.execute(s)
        c.close()
        sql.close()
